import { ClubApp } from "@/components/club-app";
import { db } from "@/db";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function ClubRoutePage() {
  await db.execute(sql`select 1`);
  return <ClubApp />;
}
