import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { db } from "@/db";
import { clubSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import "./globals.css";

const defaults = {
  siteName: "KULANANDAPUR FANTASTIC FC",
  shortName: "FANTASTIC FC",
  tagline: "Built by passion. United by football.",
  logo: "/logo.svg",
};

export async function generateMetadata(): Promise<Metadata> {
  try {
    const [row] = await db.select({ value: clubSettings.value }).from(clubSettings).where(eq(clubSettings.key, "branding")).limit(1);
    const stored = (row?.value || {}) as Partial<typeof defaults>;
    const branding = { ...defaults, ...stored };
    return {
      title: { default: branding.siteName, template: `%s • ${branding.shortName}` },
      description: `Official website, member portal and administration system of ${branding.siteName}.`,
      icons: { icon: branding.logo },
      openGraph: { title: branding.siteName, description: branding.tagline, type: "website", images: [branding.logo] },
    };
  } catch {
    return {
      title: defaults.siteName,
      description: `Official website of ${defaults.siteName}.`,
      icons: { icon: defaults.logo },
    };
  }
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#061b13",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
