import { db } from "@/db";
import { lineups, members } from "@/db/schema";
import { eq, inArray } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const [active] = await db.select().from(lineups).where(eq(lineups.isActive, true)).limit(1);
    if (!active) return NextResponse.json({ lineup: null });

    const memberIds = active.players.map(p => p.memberId).filter((id): id is string => !!id);
    const rows = memberIds.length
      ? await db.select({
          id: members.id, name: members.fullName, jersey: members.jerseyNumber, position: members.position,
          photo: members.profilePhoto, rating: members.rating,
        }).from(members).where(inArray(members.id, memberIds))
      : [];
    const byId = new Map(rows.map(r => [r.id, r]));

    const resolvedPlayers = active.players.map(p => ({
      slot: p.slot,
      member: p.memberId ? byId.get(p.memberId) || null : null,
    }));

    return NextResponse.json({
      lineup: { teamName: active.teamName, matchTitle: active.matchTitle, formation: active.formation, players: resolvedPlayers },
    }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load active lineup", error);
    return NextResponse.json({ lineup: null });
  }
}
