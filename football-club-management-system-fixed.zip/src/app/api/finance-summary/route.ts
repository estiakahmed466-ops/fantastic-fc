import { db } from "@/db";
import { financeEntries, payments } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const rows = await db.select({
      id: financeEntries.id, title: financeEntries.title, category: financeEntries.category,
      income: financeEntries.income, expense: financeEntries.expense, createdAt: financeEntries.createdAt,
    }).from(financeEntries).orderBy(desc(financeEntries.createdAt));

    const pendingDues = await db.select({ amount: payments.amount }).from(payments).where(eq(payments.status, "PENDING"));
    const pendingDuesTotal = pendingDues.reduce((sum, p) => sum + Number(p.amount), 0);

    return NextResponse.json({ entries: rows, pendingDuesTotal }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load finance summary", error);
    return NextResponse.json({ entries: [], pendingDuesTotal: 0 });
  }
}
