import { db } from "@/db";
import { matches } from "@/db/schema";
import { and, asc, eq, gte } from "drizzle-orm";
import { NextResponse } from "next/server";

// GET: the next upcoming match (soonest match with status UPCOMING and a future/today datetime).
export async function GET() {
  try {
    const now = new Date();
    now.setHours(0, 0, 0, 0); // include matches later today
    const [next] = await db.select().from(matches)
      .where(and(eq(matches.status, "UPCOMING"), gte(matches.matchDatetime, now)))
      .orderBy(asc(matches.matchDatetime))
      .limit(1);
    return NextResponse.json({ match: next || null }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load next match", error);
    return NextResponse.json({ match: null });
  }
}
