import { db } from "@/db";
import { tournamentApplications } from "@/db/schema";
import { NextResponse } from "next/server";
import { escapeHtml, getAdminNotifyEmail, sendEmail } from "@/lib/mailer";

const clean = (value: unknown, max = 180) =>
  typeof value === "string" ? value.trim().slice(0, max) : "";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const data = {
      teamName: clean(body.teamName, 160),
      clubName: clean(body.clubName, 160),
      managerName: clean(body.managerName, 160),
      mobile: clean(body.mobile, 30),
      email: clean(body.email, 180).toLowerCase(),
      playerCount: Number(body.playerCount),
      category: clean(body.category, 80),
      address: clean(body.address, 1000),
    };

    if (
      !data.teamName || !data.clubName || !data.managerName || !data.mobile || !data.email ||
      !data.category || !data.address || !Number.isInteger(data.playerCount) || data.playerCount < 5 ||
      data.playerCount > 40 || !/^\S+@\S+\.\S+$/.test(data.email)
    ) {
      return NextResponse.json({ message: "Please provide valid application details." }, { status: 400 });
    }
    await db.insert(tournamentApplications).values({ ...data, status: "PENDING" });

    const adminEmail = await getAdminNotifyEmail();
    await Promise.all([
      sendEmail({
        to: data.email,
        subject: "Application received — Fantastic FC Tournament",
        html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:28px;border:1px solid #dfe7df"><h2 style="color:#0d3a28">FANTASTIC FC</h2><p>Hello ${escapeHtml(data.managerName)},</p><p>We've received the tournament application for <strong>${escapeHtml(data.teamName)}</strong> (${escapeHtml(data.clubName)}). Our team will review it and get back to you soon.</p><p><strong>Category:</strong> ${escapeHtml(data.category)}<br/><strong>Players:</strong> ${data.playerCount}</p></div>`,
      }),
      sendEmail({
        to: adminEmail,
        subject: `New tournament application: ${data.teamName}`,
        html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:28px;border:1px solid #dfe7df"><h2 style="color:#0d3a28">New tournament application</h2><p><strong>Team:</strong> ${escapeHtml(data.teamName)} (${escapeHtml(data.clubName)})</p><p><strong>Manager:</strong> ${escapeHtml(data.managerName)} — ${escapeHtml(data.mobile)} — ${escapeHtml(data.email)}</p><p><strong>Category:</strong> ${escapeHtml(data.category)} • <strong>Players:</strong> ${data.playerCount}</p><p><strong>Address:</strong> ${escapeHtml(data.address)}</p></div>`,
      }),
    ]);

    return NextResponse.json({ message: "Application submitted for review." }, { status: 201 });
  } catch (error) {
    console.error("Tournament application failed", error);
    return NextResponse.json({ message: "Unable to submit the application." }, { status: 500 });
  }
}
