import { db } from "@/db";
import { banners } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const rows = await db.select().from(banners).where(eq(banners.isActive, true)).orderBy(asc(banners.displayOrder), asc(banners.createdAt));
    return NextResponse.json({ banners: rows }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load public banners", error);
    return NextResponse.json({ banners: [] }, { headers: { "Cache-Control": "no-store" } });
  }
}
