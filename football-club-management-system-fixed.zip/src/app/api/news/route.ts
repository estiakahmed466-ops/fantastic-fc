import { db } from "@/db";
import { posts } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const rows = await db.select().from(posts).where(eq(posts.status, "PUBLISHED")).orderBy(desc(posts.createdAt));
    return NextResponse.json({ posts: rows }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load news", error);
    return NextResponse.json({ posts: [] });
  }
}
