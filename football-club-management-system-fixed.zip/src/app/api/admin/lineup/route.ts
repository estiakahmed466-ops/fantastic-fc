import { db } from "@/db";
import { auditLogs, lineups } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";

const clean = (value: unknown, max: number, fallback: string) => {
  const s = typeof value === "string" ? value.trim().slice(0, max) : "";
  return s || fallback;
};

export async function GET(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const [active] = await db.select().from(lineups).where(eq(lineups.isActive, true)).limit(1);
    return NextResponse.json({ lineup: active || null });
  } catch (error) {
    console.error("Unable to load lineup", error);
    return NextResponse.json({ lineup: null });
  }
}

export async function PUT(request: Request) {
  const session = requireAdminSession(request);
  if (!session) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const teamName = clean(body.teamName, 120, "Fantastic FC");
    const matchTitle = clean(body.matchTitle, 180, "Starting XI");
    const formation = clean(body.formation, 20, "4-3-3");
    const rawPlayers = Array.isArray(body.players) ? body.players : [];
    const players = rawPlayers
      .filter((p): p is Record<string, unknown> => !!p && typeof p === "object")
      .map(p => ({
        slot: clean(p.slot, 20, "SLOT"),
        memberId: typeof p.memberId === "string" && p.memberId ? p.memberId : undefined,
      }))
      .slice(0, 15);

    const [existing] = await db.select({ id: lineups.id }).from(lineups).where(eq(lineups.isActive, true)).limit(1);
    if (existing) {
      await db.update(lineups).set({ teamName, matchTitle, formation, players }).where(eq(lineups.id, existing.id));
    } else {
      await db.insert(lineups).values({ teamName, matchTitle, formation, players, isActive: true });
    }
    await db.insert(auditLogs).values({
      actor: session.email, action: "Lineup published", entityType: "LINEUP", entityId: null,
      details: { teamName, matchTitle, formation, playerCount: players.filter(p => p.memberId).length },
    });
    return NextResponse.json({ message: "Lineup saved and published." });
  } catch (error) {
    console.error("Unable to save lineup", error);
    return NextResponse.json({ message: "Unable to save the lineup." }, { status: 500 });
  }
}
