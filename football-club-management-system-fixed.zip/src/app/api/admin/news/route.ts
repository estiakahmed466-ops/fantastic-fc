import { db } from "@/db";
import { auditLogs, posts } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";

const clean = (value: unknown, max: number) => typeof value === "string" ? value.trim().slice(0, max) : "";
function validImage(image: string) {
  return (image.startsWith("https://") || /^data:image\/(png|jpeg|jpg|webp|gif);base64,/i.test(image)) && image.length <= 4_200_000;
}

export async function GET(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const rows = await db.select().from(posts).orderBy(desc(posts.createdAt));
    return NextResponse.json({ posts: rows }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load news for admin", error);
    return NextResponse.json({ posts: [] });
  }
}

export async function POST(request: Request) {
  const session = requireAdminSession(request);
  if (!session) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const title = clean(body.title, 200);
    const category = clean(body.category, 60) || "Club News";
    const excerpt = clean(body.excerpt, 400);
    const article = clean(body.body, 20000);
    const coverImage = typeof body.coverImage === "string" ? body.coverImage : "";
    const status = body.status === "PUBLISHED" ? "PUBLISHED" : "DRAFT";
    if (!title || !excerpt) return NextResponse.json({ message: "Title and excerpt are required." }, { status: 400 });
    if (coverImage && !validImage(coverImage)) return NextResponse.json({ message: "Cover image must be a PNG/JPG/WebP/GIF under 4 MB, or an https:// URL." }, { status: 400 });

    const [created] = await db.insert(posts).values({ title, category, excerpt, body: article, coverImage: coverImage || null, status }).returning({ id: posts.id });
    await db.insert(auditLogs).values({ actor: session.email, action: "News post created", entityType: "POST", entityId: created.id, details: { title, status } });
    return NextResponse.json({ message: "Story saved.", id: created.id }, { status: 201 });
  } catch (error) {
    console.error("Unable to create news post", error);
    return NextResponse.json({ message: "Unable to save the story." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  const session = requireAdminSession(request);
  if (!session) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = typeof body.id === "string" ? body.id : "";
    if (!id) return NextResponse.json({ message: "Missing story id." }, { status: 400 });

    const patch: Record<string, unknown> = {};
    if ("title" in body) patch.title = clean(body.title, 200);
    if ("category" in body) patch.category = clean(body.category, 60) || "Club News";
    if ("excerpt" in body) patch.excerpt = clean(body.excerpt, 400);
    if ("body" in body) patch.body = clean(body.body, 20000);
    if ("status" in body) patch.status = body.status === "PUBLISHED" ? "PUBLISHED" : "DRAFT";
    if ("coverImage" in body) {
      const coverImage = typeof body.coverImage === "string" ? body.coverImage : "";
      if (coverImage && !validImage(coverImage)) return NextResponse.json({ message: "Cover image must be a PNG/JPG/WebP/GIF under 4 MB, or an https:// URL." }, { status: 400 });
      patch.coverImage = coverImage || null;
    }
    patch.updatedAt = new Date();

    const [updated] = await db.update(posts).set(patch).where(eq(posts.id, id)).returning({ id: posts.id, title: posts.title });
    if (!updated) return NextResponse.json({ message: "Story not found." }, { status: 404 });
    await db.insert(auditLogs).values({ actor: session.email, action: "News post updated", entityType: "POST", entityId: id, details: { title: updated.title } });
    return NextResponse.json({ message: "Story updated." });
  } catch (error) {
    console.error("Unable to update news post", error);
    return NextResponse.json({ message: "Unable to update the story." }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  const session = requireAdminSession(request);
  if (!session) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id") || "";
    if (!id) return NextResponse.json({ message: "Missing story id." }, { status: 400 });
    await db.delete(posts).where(eq(posts.id, id));
    await db.insert(auditLogs).values({ actor: session.email, action: "News post deleted", entityType: "POST", entityId: id, details: {} });
    return NextResponse.json({ message: "Story deleted." });
  } catch (error) {
    console.error("Unable to delete news post", error);
    return NextResponse.json({ message: "Unable to delete the story." }, { status: 500 });
  }
}
