import { db } from "@/db";
import { auditLogs, members, pinResetRequests } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { randomBytes, randomInt, scrypt as scryptCallback } from "node:crypto";
import { promisify } from "node:util";
import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";

const scrypt = promisify(scryptCallback);

function escapeHtml(value: string) {
  return value.replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;",
  })[character] || character);
}

export async function GET(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const requests = await db.select().from(pinResetRequests).orderBy(desc(pinResetRequests.requestedAt));
    return NextResponse.json({ requests });
  } catch (error) {
    console.error("Unable to load PIN resets", error);
    return NextResponse.json({ message: "Unable to load PIN reset requests." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as { id?: unknown; action?: unknown };
    const id = typeof body.id === "string" ? body.id : "";
    const action = body.action === "approve" || body.action === "reject" ? body.action : null;
    if (!id || !action) return NextResponse.json({ message: "Invalid admin action." }, { status: 400 });

    const [reset] = await db.select().from(pinResetRequests).where(eq(pinResetRequests.id, id)).limit(1);
    if (!reset) return NextResponse.json({ message: "PIN reset request not found." }, { status: 404 });
    if (reset.status !== "PENDING") return NextResponse.json({ message: "This request has already been resolved." }, { status: 409 });

    if (action === "reject") {
      await db.update(pinResetRequests).set({ status: "REJECTED", resolvedAt: new Date() }).where(eq(pinResetRequests.id, id));
      await db.insert(auditLogs).values({
        actor: "FANTASTIC FC ADMIN", action: "PIN reset rejected", entityType: "PIN_RESET", entityId: id,
        details: { memberCode: reset.memberCode },
      });
      return NextResponse.json({ message: "PIN reset request rejected.", status: "REJECTED" });
    }

    const pin = String(randomInt(100000, 1000000));
    const salt = randomBytes(16).toString("hex");
    const derived = (await scrypt(pin, salt, 64)) as Buffer;
    const pinHash = `${salt}:${derived.toString("hex")}`;
    await db.update(members).set({ pinHash, updatedAt: new Date() }).where(eq(members.id, reset.memberId));

    let emailStatus = "FAILED";
    let providerId: string | null = null;
    let emailMessage = "PIN created, but email delivery is not configured. Copy the one-time PIN and contact the member securely.";
    const resendKey = process.env.RESEND_API_KEY;
    const from = process.env.ADMIN_EMAIL_FROM || "Fantastic FC Admin <onboarding@resend.dev>";

    if (resendKey) {
      const response = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${resendKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from,
          to: [reset.email],
          subject: "Your new Fantastic FC Portal PIN",
          html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:28px;border:1px solid #dfe7df"><h2 style="color:#0d3a28">FANTASTIC FC PORTAL</h2><p>Hello ${escapeHtml(reset.requesterName)},</p><p>Your PIN reset was approved by the club admin.</p><div style="font-size:34px;letter-spacing:8px;font-weight:800;background:#eef6ef;padding:20px;text-align:center;color:#0d3a28">${pin}</div><p>Member ID: <strong>${escapeHtml(reset.memberCode)}</strong></p><p>Please sign in and keep this PIN private. If you did not request this reset, contact the club admin immediately.</p></div>`,
        }),
      });
      const result = (await response.json().catch(() => ({}))) as { id?: string; message?: string };
      if (response.ok) {
        emailStatus = "SENT";
        providerId = result.id || null;
        emailMessage = `New PIN emailed to ${reset.email}.`;
      } else {
        emailMessage = result.message || "Email delivery failed. Give the one-time PIN to the member securely.";
      }
    }

    await db.update(pinResetRequests).set({
      status: "APPROVED", emailStatus, emailProviderId: providerId, resolvedAt: new Date(),
    }).where(eq(pinResetRequests.id, id));
    await db.insert(auditLogs).values({
      actor: "FANTASTIC FC ADMIN", action: "PIN reset approved", entityType: "PIN_RESET", entityId: id,
      details: { memberCode: reset.memberCode, emailStatus, providerId },
    });

    return NextResponse.json({
      message: emailMessage,
      status: "APPROVED",
      emailStatus,
      generatedPin: pin,
    });
  } catch (error) {
    console.error("PIN reset admin action failed", error);
    return NextResponse.json({ message: "Unable to complete the PIN reset." }, { status: 500 });
  }
}
