import { db } from "@/db";
import { auditLogs, banners } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";

const clean = (value: unknown, max: number) => typeof value === "string" ? value.trim().slice(0, max) : "";
function validImage(image: string) {
  return (image.startsWith("https://") || /^data:image\/(png|jpeg|jpg|webp);base64,/i.test(image)) && image.length <= 2_100_000;
}

export async function GET(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const rows = await db.select().from(banners).orderBy(asc(banners.displayOrder), asc(banners.createdAt));
    return NextResponse.json({ banners: rows }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load banners", error);
    return NextResponse.json({ message: "Unable to load banners." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const imageUrl = clean(body.imageUrl, 2_100_000);
    const mobileImageUrlRaw = clean(body.mobileImageUrl, 2_100_000);
    const mobileImageUrl = mobileImageUrlRaw && validImage(mobileImageUrlRaw) ? mobileImageUrlRaw : null;
    const title = clean(body.title, 180);
    const subtitle = clean(body.subtitle, 1000);
    if (!title || !subtitle || !validImage(imageUrl)) return NextResponse.json({ message: "Add a title, subtitle and JPG/PNG/WebP image under 1.5 MB." }, { status: 400 });
    const [created] = await db.insert(banners).values({
      title,
      subtitle,
      eyebrow: clean(body.eyebrow, 120) || "KULANANDAPUR'S FOOTBALL LEGACY",
      imageUrl,
      imagePosition: clean(body.imagePosition, 20) || "center 40%",
      mobileImageUrl,
      mobileImagePosition: clean(body.mobileImagePosition, 20) || "65% center",
      buttonText: clean(body.buttonText, 80) || "Explore match centre",
      buttonLink: clean(body.buttonLink, 240) || "/matches",
      isActive: body.isActive !== false,
      displayOrder: Math.max(1, Number(body.displayOrder) || 1),
    }).returning();
    await db.insert(auditLogs).values({ actor: "FANTASTIC FC ADMIN", action: "Banner added", entityType: "BANNER", entityId: created.id, details: { title } });
    return NextResponse.json({ message: "Banner added and saved.", banner: created }, { status: 201 });
  } catch (error) {
    console.error("Unable to add banner", error);
    return NextResponse.json({ message: "Unable to add banner." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = clean(body.id, 80);
    if (!id) return NextResponse.json({ message: "Banner ID is required." }, { status: 400 });
    const imageUrl = clean(body.imageUrl, 2_100_000);
    const mobileImageUrlRaw = clean(body.mobileImageUrl, 2_100_000);
    const mobileImageUrl = mobileImageUrlRaw && validImage(mobileImageUrlRaw) ? mobileImageUrlRaw : null;
    const title = clean(body.title, 180);
    const subtitle = clean(body.subtitle, 1000);
    if (!title || !subtitle || !validImage(imageUrl)) return NextResponse.json({ message: "Banner details or image are invalid." }, { status: 400 });
    const [updated] = await db.update(banners).set({
      title, subtitle, imageUrl, mobileImageUrl,
      imagePosition: clean(body.imagePosition, 20) || "center 40%",
      mobileImagePosition: clean(body.mobileImagePosition, 20) || "65% center",
      eyebrow: clean(body.eyebrow, 120) || "KULANANDAPUR'S FOOTBALL LEGACY",
      buttonText: clean(body.buttonText, 80) || "Explore match centre",
      buttonLink: clean(body.buttonLink, 240) || "/matches",
      isActive: body.isActive !== false,
      displayOrder: Math.max(1, Number(body.displayOrder) || 1),
      updatedAt: new Date(),
    }).where(eq(banners.id, id)).returning();
    if (!updated) return NextResponse.json({ message: "Banner not found." }, { status: 404 });
    await db.insert(auditLogs).values({ actor: "FANTASTIC FC ADMIN", action: "Banner updated", entityType: "BANNER", entityId: id, details: { title, active: updated.isActive, order: updated.displayOrder } });
    return NextResponse.json({ message: "Banner updated.", banner: updated });
  } catch (error) {
    console.error("Unable to update banner", error);
    return NextResponse.json({ message: "Unable to update banner." }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as { id?: unknown };
    const id = clean(body.id, 80);
    const [deleted] = await db.delete(banners).where(eq(banners.id, id)).returning({ id: banners.id, title: banners.title });
    if (!deleted) return NextResponse.json({ message: "Banner not found." }, { status: 404 });
    await db.insert(auditLogs).values({ actor: "FANTASTIC FC ADMIN", action: "Banner deleted", entityType: "BANNER", entityId: id, details: { title: deleted.title } });
    return NextResponse.json({ message: "Banner deleted." });
  } catch (error) {
    console.error("Unable to delete banner", error);
    return NextResponse.json({ message: "Unable to delete banner." }, { status: 500 });
  }
}
