import { db } from "@/db";
import { auditLogs, paymentMethods } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";

const DEFAULTS = [
  { name: "bKash", accountNumber: "017•••••427", accountName: "Fantastic FC", instructions: "Send Money and enter the exact transaction ID.", warning: "Never share your portal PIN.", enabled: true, displayOrder: 1 },
  { name: "Nagad", accountNumber: "018•••••965", accountName: "Fantastic FC", instructions: "Send Money and enter the exact transaction ID.", warning: "Never share your portal PIN.", enabled: true, displayOrder: 2 },
  { name: "Upay", accountNumber: "016•••••582", accountName: "Fantastic FC", instructions: "Send Money and enter the exact transaction ID.", warning: "Never share your portal PIN.", enabled: true, displayOrder: 3 },
  { name: "Rocket", accountNumber: "019•••••318", accountName: "Fantastic FC", instructions: "Send Money and enter the exact transaction ID.", warning: "Never share your portal PIN.", enabled: true, displayOrder: 4 },
  { name: "Cash", accountNumber: "CASH-DESK", accountName: "Fantastic FC", instructions: "Pay at the club desk and keep your receipt.", warning: "Ask for a signed receipt.", enabled: true, displayOrder: 5 },
];

const clean = (value: unknown, max: number) => typeof value === "string" ? value.trim().slice(0, max) : "";

async function ensureSeeded() {
  const existing = await db.select({ id: paymentMethods.id }).from(paymentMethods).limit(1);
  if (existing.length === 0) await db.insert(paymentMethods).values(DEFAULTS);
}

export async function GET(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    await ensureSeeded();
    const rows = await db.select().from(paymentMethods).orderBy(asc(paymentMethods.displayOrder));
    return NextResponse.json({ methods: rows }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load payment methods", error);
    return NextResponse.json({ methods: [] });
  }
}

export async function POST(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const name = clean(body.name, 60);
    const accountNumber = clean(body.accountNumber, 40);
    const accountName = clean(body.accountName, 120) || "Fantastic FC";
    if (!name || !accountNumber) return NextResponse.json({ message: "Enter a method name and account number." }, { status: 400 });
    const [created] = await db.insert(paymentMethods).values({
      name, accountNumber, accountName,
      instructions: clean(body.instructions, 500) || "Send Money and enter the exact transaction ID.",
      warning: clean(body.warning, 300) || "Never share your portal PIN.",
      enabled: body.enabled !== false,
      displayOrder: Number(body.displayOrder) || 0,
    }).returning({ id: paymentMethods.id });
    await db.insert(auditLogs).values({ actor: "Club admin", action: "Payment method added", entityType: "PAYMENT_METHOD", entityId: created.id, details: { name } });
    return NextResponse.json({ message: "Payment method added.", id: created.id }, { status: 201 });
  } catch (error) {
    console.error("Unable to create payment method", error);
    return NextResponse.json({ message: "Unable to add payment method." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = clean(body.id, 60);
    if (!id) return NextResponse.json({ message: "Missing method id." }, { status: 400 });
    const updates: Record<string, unknown> = {};
    if (typeof body.name === "string") updates.name = clean(body.name, 60);
    if (typeof body.accountNumber === "string") updates.accountNumber = clean(body.accountNumber, 40);
    if (typeof body.accountName === "string") updates.accountName = clean(body.accountName, 120);
    if (typeof body.instructions === "string") updates.instructions = clean(body.instructions, 500);
    if (typeof body.warning === "string") updates.warning = clean(body.warning, 300);
    if (typeof body.enabled === "boolean") updates.enabled = body.enabled;
    if (typeof body.displayOrder === "number") updates.displayOrder = body.displayOrder;
    if (Object.keys(updates).length === 0) return NextResponse.json({ message: "Nothing to update." }, { status: 400 });
    await db.update(paymentMethods).set(updates).where(eq(paymentMethods.id, id));
    await db.insert(auditLogs).values({ actor: "Club admin", action: "Payment method updated", entityType: "PAYMENT_METHOD", entityId: id, details: updates });
    return NextResponse.json({ message: "Payment method updated." });
  } catch (error) {
    console.error("Unable to update payment method", error);
    return NextResponse.json({ message: "Unable to update payment method." }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id") || "";
    if (!id) return NextResponse.json({ message: "Missing method id." }, { status: 400 });
    await db.delete(paymentMethods).where(eq(paymentMethods.id, id));
    await db.insert(auditLogs).values({ actor: "Club admin", action: "Payment method removed", entityType: "PAYMENT_METHOD", entityId: id, details: {} });
    return NextResponse.json({ message: "Payment method removed." });
  } catch (error) {
    console.error("Unable to delete payment method", error);
    return NextResponse.json({ message: "Unable to delete payment method." }, { status: 500 });
  }
}
