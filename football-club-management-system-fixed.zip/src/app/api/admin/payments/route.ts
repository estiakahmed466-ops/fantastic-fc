import { db } from "@/db";
import { auditLogs, members, paymentMethods, payments } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";

export async function GET(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const rows = await db.select({
      databaseId: payments.id,
      transactionId: payments.transactionId,
      feeType: payments.feeType,
      amount: payments.amount,
      screenshotUrl: payments.screenshotUrl,
      status: payments.status,
      submittedAt: payments.createdAt,
      memberName: members.fullName,
      memberCode: members.memberId,
      memberImage: members.profilePhoto,
      method: paymentMethods.name,
      accountNumber: paymentMethods.accountNumber,
    }).from(payments)
      .leftJoin(members, eq(payments.memberId, members.id))
      .leftJoin(paymentMethods, eq(payments.paymentMethodId, paymentMethods.id))
      .orderBy(desc(payments.createdAt));
    return NextResponse.json({ payments: rows });
  } catch (error) {
    console.error("Unable to load payments", error);
    return NextResponse.json({ message: "Unable to load payments." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as { id?: unknown; status?: unknown };
    const id = typeof body.id === "string" ? body.id : "";
    const status = body.status === "PAID" || body.status === "REJECTED" ? body.status : null;
    if (!id || !status) return NextResponse.json({ message: "Invalid payment action." }, { status: 400 });

    const [updated] = await db.update(payments).set({ status, verifiedAt: new Date() }).where(eq(payments.id, id)).returning({
      id: payments.id, transactionId: payments.transactionId, memberId: payments.memberId,
    });
    if (!updated) return NextResponse.json({ message: "Payment not found." }, { status: 404 });
    await db.insert(auditLogs).values({
      actor: "FANTASTIC FC ADMIN",
      action: status === "PAID" ? "Payment approved" : "Payment rejected",
      entityType: "PAYMENT",
      entityId: updated.id,
      details: { transactionId: updated.transactionId, memberId: updated.memberId, status },
    });
    return NextResponse.json({ message: status === "PAID" ? "Payment verified." : "Payment rejected.", status });
  } catch (error) {
    console.error("Payment admin action failed", error);
    return NextResponse.json({ message: "Unable to update payment." }, { status: 500 });
  }
}
