import { db } from "@/db";
import { auditLogs } from "@/db/schema";
import { desc } from "drizzle-orm";
import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";

export async function GET(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const rows = await db.select({
      id: auditLogs.id, actor: auditLogs.actor, action: auditLogs.action,
      entityType: auditLogs.entityType, entityId: auditLogs.entityId,
      details: auditLogs.details, createdAt: auditLogs.createdAt,
    }).from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(50);
    return NextResponse.json({ logs: rows }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load audit log", error);
    return NextResponse.json({ logs: [] });
  }
}
