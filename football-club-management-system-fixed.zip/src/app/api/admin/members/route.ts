import { db } from "@/db";
import { auditLogs, members } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";

export async function GET(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const rows = await db.select({
      databaseId: members.id,
      id: members.memberId,
      name: members.fullName,
      mobile: members.mobile,
      email: members.email,
      dateOfBirth: members.dateOfBirth,
      address: members.address,
      emergencyContact: members.emergencyContact,
      jersey: members.jerseyNumber,
      position: members.position,
      isCaptain: members.isCaptain,
      matchesPlayed: members.matchesPlayed,
      goals: members.goals,
      assists: members.assists,
      rating: members.rating,
      joined: members.joiningDate,
      status: members.status,
      image: members.profilePhoto,
      createdAt: members.createdAt,
    }).from(members).orderBy(desc(members.createdAt));
    return NextResponse.json({ members: rows });
  } catch (error) {
    console.error("Unable to load members", error);
    return NextResponse.json({ message: "Unable to load member accounts." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = typeof body.id === "string" ? body.id : "";
    if (!id) return NextResponse.json({ message: "Invalid member action." }, { status: 400 });

    // Squad-assignment update: jersey number / position / captain / stats. Used by the
    // Players page and Field & Lineup builder — all backed by real member records now.
    if ("jerseyNumber" in body || "position" in body || "isCaptain" in body || "matchesPlayed" in body || "goals" in body || "assists" in body || "rating" in body) {
      const positions = ["GOALKEEPER", "DEFENDER", "MIDFIELDER", "FORWARD"] as const;
      const patch: Record<string, unknown> = {};
      if ("jerseyNumber" in body) patch.jerseyNumber = body.jerseyNumber === null ? null : Number(body.jerseyNumber) || null;
      if ("position" in body) patch.position = positions.includes(body.position as (typeof positions)[number]) ? body.position : null;
      if ("isCaptain" in body) patch.isCaptain = !!body.isCaptain;
      if ("matchesPlayed" in body) patch.matchesPlayed = Math.max(0, Number(body.matchesPlayed) || 0);
      if ("goals" in body) patch.goals = Math.max(0, Number(body.goals) || 0);
      if ("assists" in body) patch.assists = Math.max(0, Number(body.assists) || 0);
      if ("rating" in body) patch.rating = body.rating === null || body.rating === "" ? null : String(Math.min(10, Math.max(0, Number(body.rating) || 0)));
      const [updated] = await db.update(members).set({ ...patch, updatedAt: new Date() }).where(eq(members.id, id)).returning({ id: members.id, memberId: members.memberId, fullName: members.fullName });
      if (!updated) return NextResponse.json({ message: "Member account not found." }, { status: 404 });
      return NextResponse.json({ message: "Squad details updated." });
    }

    const allowed = ["ACTIVE", "INACTIVE", "BLACKLISTED", "REJECTED"] as const;
    const status = allowed.includes(body.status as (typeof allowed)[number])
      ? body.status as (typeof allowed)[number]
      : null;
    if (!status) return NextResponse.json({ message: "Invalid member action." }, { status: 400 });

    const [updated] = await db.update(members).set({ status, updatedAt: new Date() }).where(eq(members.id, id)).returning({
      id: members.id, memberId: members.memberId, fullName: members.fullName,
    });
    if (!updated) return NextResponse.json({ message: "Member account not found." }, { status: 404 });
    await db.insert(auditLogs).values({
      actor: "FANTASTIC FC ADMIN",
      action: status === "ACTIVE" ? "Member approved" : status === "REJECTED" ? "Member rejected" : `Member set to ${status.toLowerCase()}`,
      entityType: "MEMBER",
      entityId: updated.memberId,
      details: { databaseId: updated.id, fullName: updated.fullName, status },
    });
    return NextResponse.json({ message: "Member account updated.", status });
  } catch (error) {
    console.error("Member admin action failed", error);
    return NextResponse.json({ message: "Unable to update member account." }, { status: 500 });
  }
}
