import { db } from "@/db";
import { contactMessages } from "@/db/schema";
import { NextResponse } from "next/server";
import { escapeHtml, getAdminNotifyEmail, sendEmail } from "@/lib/mailer";

const clean = (value: unknown, max: number) =>
  typeof value === "string" ? value.trim().slice(0, max) : "";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const name = clean(body.name, 160);
    const email = clean(body.email, 180).toLowerCase();
    const mobile = clean(body.mobile, 30);
    const subject = clean(body.subject, 200);
    const message = clean(body.message, 3000);

    if (!name || !email || !subject || message.length < 10 || !/^\S+@\S+\.\S+$/.test(email)) {
      return NextResponse.json({ message: "Please complete all required fields." }, { status: 400 });
    }
    await db.insert(contactMessages).values({ name, email, mobile: mobile || null, subject, message });

    // Auto-reply to the sender + notify the admin inbox — best-effort, never blocks the response.
    const adminEmail = await getAdminNotifyEmail();
    await Promise.all([
      sendEmail({
        to: email,
        subject: "We received your message — Fantastic FC",
        html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:28px;border:1px solid #dfe7df"><h2 style="color:#0d3a28">FANTASTIC FC</h2><p>Hello ${escapeHtml(name)},</p><p>Thanks for contacting us. We've received your message about "<strong>${escapeHtml(subject)}</strong>" and will get back to you soon.</p><p style="color:#555">Your message:</p><blockquote style="margin:0;padding:12px 16px;background:#f4f8f4;border-left:3px solid #0d3a28;color:#333">${escapeHtml(message)}</blockquote></div>`,
      }),
      sendEmail({
        to: adminEmail,
        subject: `New contact message: ${subject}`,
        html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:28px;border:1px solid #dfe7df"><h2 style="color:#0d3a28">New contact message</h2><p><strong>From:</strong> ${escapeHtml(name)} (${escapeHtml(email)})</p><p><strong>Mobile:</strong> ${escapeHtml(mobile || "—")}</p><p><strong>Subject:</strong> ${escapeHtml(subject)}</p><blockquote style="margin:0;padding:12px 16px;background:#f4f8f4;border-left:3px solid #0d3a28;color:#333">${escapeHtml(message)}</blockquote></div>`,
      }),
    ]);

    return NextResponse.json({ message: "Message received. We will contact you soon." }, { status: 201 });
  } catch (error) {
    console.error("Contact form failed", error);
    return NextResponse.json({ message: "Unable to send your message." }, { status: 500 });
  }
}
