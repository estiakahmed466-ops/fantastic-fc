import { db } from "@/db";
import { members } from "@/db/schema";
import { eq, or } from "drizzle-orm";
import { NextResponse } from "next/server";
import { verifySecret } from "@/lib/hash";
import { MEMBER_SESSION_COOKIE, createMemberSessionToken, verifyMemberSessionToken } from "@/lib/member-session";

// GET: return the current member session (basic profile), if any.
export async function GET(request: Request) {
  try {
    const cookieHeader = request.headers.get("cookie") || "";
    const token = cookieHeader.split(";").map(part => part.trim()).find(part => part.startsWith(`${MEMBER_SESSION_COOKIE}=`))?.split("=")[1];
    const session = verifyMemberSessionToken(token);
    if (!session) return NextResponse.json({ authenticated: false });

    const [member] = await db.select({
      id: members.id, memberId: members.memberId, fullName: members.fullName, email: members.email,
      profilePhoto: members.profilePhoto, status: members.status, position: members.position, jerseyNumber: members.jerseyNumber,
    }).from(members).where(eq(members.id, session.memberId)).limit(1);

    if (!member || member.status !== "ACTIVE") return NextResponse.json({ authenticated: false });
    return NextResponse.json({ authenticated: true, member });
  } catch (error) {
    console.error("Unable to check member session", error);
    return NextResponse.json({ authenticated: false });
  }
}

// POST: sign in with mobile/email/member ID + password. Only ACTIVE accounts may sign in.
export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const identifier = typeof body.identifier === "string" ? body.identifier.trim() : "";
    const password = typeof body.password === "string" ? body.password : "";
    if (!identifier || !password) return NextResponse.json({ message: "Enter your mobile, email or member ID and password." }, { status: 400 });

    const [member] = await db
      .select()
      .from(members)
      .where(or(eq(members.memberId, identifier), eq(members.email, identifier.toLowerCase()), eq(members.mobile, identifier)))
      .limit(1);

    if (!member) return NextResponse.json({ message: "Account not found." }, { status: 404 });

    const valid = await verifySecret(member.passwordHash, password);
    if (!valid) return NextResponse.json({ message: "Incorrect password." }, { status: 401 });

    if (member.status === "PENDING") {
      return NextResponse.json({ message: "Your account is still awaiting admin approval. You'll be able to sign in once approved." }, { status: 403 });
    }
    if (member.status === "REJECTED") {
      return NextResponse.json({ message: "This account is not active. Contact the club admin." }, { status: 403 });
    }
    if (member.status !== "ACTIVE") {
      return NextResponse.json({ message: "This account cannot sign in right now." }, { status: 403 });
    }

    const token = createMemberSessionToken(member.id, member.memberId);
    const response = NextResponse.json({ message: "Signed in.", memberId: member.memberId });
    response.cookies.set(MEMBER_SESSION_COOKIE, token, {
      httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: 60 * 60 * 24 * 7,
    });
    return response;
  } catch (error) {
    console.error("Member login failed", error);
    return NextResponse.json({ message: "Unable to sign in right now." }, { status: 500 });
  }
}

// DELETE: sign out by clearing the session cookie.
export async function DELETE() {
  const response = NextResponse.json({ message: "Signed out." });
  response.cookies.set(MEMBER_SESSION_COOKIE, "", { path: "/", maxAge: 0 });
  return response;
}
