import { db } from "@/db";
import { clubSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

type JerseyOrderRow = { id: string; memberCode: string; memberName: string; size: string; jerseyNumber: number; printName: string; quantity: number; unitPrice: number; status: string; createdAt: string };

async function loadOrders(): Promise<JerseyOrderRow[]> {
  const [row] = await db.select({ value: clubSettings.value }).from(clubSettings).where(eq(clubSettings.key, "jersey_orders")).limit(1);
  return ((row?.value as { orders?: JerseyOrderRow[] })?.orders || []) as JerseyOrderRow[];
}

async function saveOrders(orders: JerseyOrderRow[]) {
  await db.insert(clubSettings).values({ key: "jersey_orders", value: { orders } }).onConflictDoUpdate({ target: clubSettings.key, set: { value: { orders }, updatedAt: new Date() } });
}

export async function GET() {
  try {
    return NextResponse.json({ orders: await loadOrders() }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Jersey load failed", error);
    return NextResponse.json({ orders: [] });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const memberCode = String(body.memberCode || "").trim().slice(0, 24);
    const memberName = String(body.memberName || "").trim().slice(0, 160);
    const size = String(body.size || "").trim().slice(0, 10);
    const jerseyNumber = Number(body.jerseyNumber) || 0;
    const printName = String(body.printName || "").trim().slice(0, 40).toUpperCase();
    const quantity = Math.max(1, Math.min(10, Number(body.quantity) || 1));
    const unitPrice = 850;
    const sizes = ["XS", "S", "M", "L", "XL", "XXL", "XXXL", "Custom"];
    if (!memberCode || !memberName || !sizes.includes(size) || !printName || jerseyNumber < 1 || jerseyNumber > 99) {
      return NextResponse.json({ message: "Select a valid size, jersey number and print name." }, { status: 400 });
    }
    const order: JerseyOrderRow = { id: `JO-${Date.now().toString(36).toUpperCase()}`, memberCode, memberName, size, jerseyNumber, printName, quantity, unitPrice, status: "PENDING", createdAt: new Date().toISOString() };
    const orders = await loadOrders();
    orders.unshift(order);
    await saveOrders(orders);
    return NextResponse.json({ message: "Jersey order submitted for admin review.", order }, { status: 201 });
  } catch (error) {
    console.error("Jersey order failed", error);
    return NextResponse.json({ message: "Unable to submit jersey order." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const body = (await request.json()) as { id?: string; status?: string };
    const id = body.id || "";
    const status = ["PENDING", "PAID", "PROCESSING", "DELIVERED"].includes(body.status || "") ? body.status! : null;
    if (!id || !status) return NextResponse.json({ message: "Invalid action." }, { status: 400 });
    const orders = await loadOrders();
    const index = orders.findIndex(o => o.id === id);
    if (index === -1) return NextResponse.json({ message: "Order not found." }, { status: 404 });
    orders[index] = { ...orders[index], status };
    await saveOrders(orders);
    return NextResponse.json({ message: "Order updated.", order: orders[index] });
  } catch (error) {
    console.error("Jersey update failed", error);
    return NextResponse.json({ message: "Unable to update order." }, { status: 500 });
  }
}
