import { db } from "@/db";
import { members } from "@/db/schema";
import { randomBytes, scrypt as scryptCallback } from "node:crypto";
import { promisify } from "node:util";
import { NextResponse } from "next/server";

const scrypt = promisify(scryptCallback);

function clean(value: unknown, max = 180) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

function cleanPhoto(value: unknown): string | null {
  if (typeof value !== "string" || !value) return null;
  if (!/^data:image\/(png|jpeg|webp|gif);base64,/.test(value)) return null;
  if (value.length > 2_100_000) return null; // roughly 1.5MB after base64 overhead
  return value;
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const fullName = clean(body.fullName, 160);
    const mobile = clean(body.mobile, 30);
    const email = clean(body.email).toLowerCase();
    const password = clean(body.password, 200);
    const confirmPassword = clean(body.confirmPassword, 200);
    const position = clean(body.position, 20);

    if (!fullName || !mobile || !email || !password) {
      return NextResponse.json({ message: "Required fields are missing." }, { status: 400 });
    }
    if (!/^\S+@\S+\.\S+$/.test(email) || !/^\+?[0-9-]{10,18}$/.test(mobile)) {
      return NextResponse.json({ message: "Enter a valid email and mobile number." }, { status: 400 });
    }
    if (password.length < 8 || password !== confirmPassword) {
      return NextResponse.json({ message: "Passwords must match and contain at least 8 characters." }, { status: 400 });
    }

    const salt = randomBytes(16).toString("hex");
    const derived = (await scrypt(password, salt, 64)) as Buffer;
    const passwordHash = `${salt}:${derived.toString("hex")}`;
    const memberId = `FFC-${new Date().getFullYear()}-${randomBytes(3).toString("hex").toUpperCase()}`;
    const parsedJersey = Number(body.jerseyNumber);
    const acceptedPositions = ["GOALKEEPER", "DEFENDER", "MIDFIELDER", "FORWARD"] as const;
    const safePosition = acceptedPositions.includes(position as (typeof acceptedPositions)[number])
      ? (position as (typeof acceptedPositions)[number])
      : null;

    await db.insert(members).values({
      memberId,
      fullName,
      mobile,
      email,
      dateOfBirth: clean(body.dateOfBirth, 10) || null,
      address: clean(body.address, 1000) || null,
      emergencyContact: clean(body.emergencyContact, 30) || null,
      jerseyNumber: Number.isInteger(parsedJersey) && parsedJersey > 0 && parsedJersey < 100 ? parsedJersey : null,
      position: safePosition,
      joiningDate: clean(body.joiningDate, 10) || null,
      profilePhoto: cleanPhoto(body.profilePhoto),
      passwordHash,
      status: "PENDING",
    });

    return NextResponse.json({ message: "Registration submitted for approval.", memberId }, { status: 201 });
  } catch (error) {
    const code = (error as { code?: string }).code;
    if (code === "23505") {
      return NextResponse.json({ message: "This email or mobile is already registered." }, { status: 409 });
    }
    console.error("Registration failed", error);
    return NextResponse.json({ message: "Unable to register right now." }, { status: 500 });
  }
}
