import { db } from "@/db";
import { auditLogs, clubSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

const defaults = {
  siteName: "KULANANDAPUR FANTASTIC FC",
  shortName: "FANTASTIC FC",
  adminName: "FANTASTIC FC ADMIN",
  portalName: "FANTASTIC FC PORTAL",
  tagline: "EST. 2012 • ONE CLUB, ONE FAMILY",
  logo: "/logo-crest.png",
};

type Branding = typeof defaults;

function clean(value: unknown, fallback: string, max: number) {
  return typeof value === "string" && value.trim() ? value.trim().slice(0, max) : fallback;
}

export async function GET() {
  try {
    const [row] = await db.select({ value: clubSettings.value }).from(clubSettings).where(eq(clubSettings.key, "branding")).limit(1);
    const stored = (row?.value || {}) as Partial<Branding>;
    return NextResponse.json({ branding: { ...defaults, ...stored } }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load branding", error);
    return NextResponse.json({ branding: defaults }, { headers: { "Cache-Control": "no-store" } });
  }
}

export async function PUT(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const logo = typeof body.logo === "string" ? body.logo.trim() : defaults.logo;
    const isBuiltIn = logo === "/logo.svg" || logo === "/logo-crest.png";
    const isImageData = /^data:image\/(png|jpeg|jpg|webp|svg\+xml);base64,/i.test(logo);
    if ((!isBuiltIn && !isImageData) || logo.length > 2_100_000) {
      return NextResponse.json({ message: "Upload a PNG, JPG, WebP or SVG logo under 1.5 MB." }, { status: 400 });
    }

    const branding: Branding = {
      siteName: clean(body.siteName, defaults.siteName, 100),
      shortName: clean(body.shortName, defaults.shortName, 50),
      adminName: clean(body.adminName, defaults.adminName, 70),
      portalName: clean(body.portalName, defaults.portalName, 70),
      tagline: clean(body.tagline, defaults.tagline, 100),
      logo,
    };

    await db.insert(clubSettings).values({ key: "branding", value: branding }).onConflictDoUpdate({
      target: clubSettings.key,
      set: { value: branding, updatedAt: new Date() },
    });
    await db.insert(auditLogs).values({
      actor: "FANTASTIC FC ADMIN",
      action: "Website branding updated",
      entityType: "CLUB_SETTINGS",
      entityId: "branding",
      details: { siteName: branding.siteName, shortName: branding.shortName, logoChanged: logo !== defaults.logo },
    });

    return NextResponse.json({ message: "Website name and logo updated successfully.", branding });
  } catch (error) {
    console.error("Unable to save branding", error);
    return NextResponse.json({ message: "Unable to save website branding." }, { status: 500 });
  }
}
