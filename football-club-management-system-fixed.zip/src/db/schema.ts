import {
  boolean,
  date,
  integer,
  jsonb,
  numeric,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";

export const memberStatus = pgEnum("member_status", [
  "PENDING",
  "ACTIVE",
  "INACTIVE",
  "BLACKLISTED",
  "REJECTED",
]);
export const paymentStatus = pgEnum("payment_status", [
  "PENDING",
  "PAID",
  "REJECTED",
]);
export const applicationStatus = pgEnum("application_status", [
  "PENDING",
  "APPROVED",
  "REJECTED",
]);
export const playerPosition = pgEnum("player_position", [
  "GOALKEEPER",
  "DEFENDER",
  "MIDFIELDER",
  "FORWARD",
]);

export const members = pgTable("members", {
  id: uuid("id").defaultRandom().primaryKey(),
  memberId: varchar("member_id", { length: 24 }).notNull().unique(),
  fullName: varchar("full_name", { length: 160 }).notNull(),
  mobile: varchar("mobile", { length: 30 }).notNull().unique(),
  email: varchar("email", { length: 180 }).notNull().unique(),
  dateOfBirth: date("date_of_birth"),
  address: text("address"),
  emergencyContact: varchar("emergency_contact", { length: 30 }),
  jerseyNumber: integer("jersey_number"),
  position: playerPosition("position"),
  matchesPlayed: integer("matches_played").notNull().default(0),
  goals: integer("goals").notNull().default(0),
  assists: integer("assists").notNull().default(0),
  rating: numeric("rating", { precision: 3, scale: 1 }),
  joiningDate: date("joining_date").defaultNow(),
  profilePhoto: text("profile_photo"),
  passwordHash: text("password_hash").notNull(),
  pinHash: text("pin_hash"),
  status: memberStatus("status").notNull().default("PENDING"),
  isCaptain: boolean("is_captain").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const pinResetRequests = pgTable("pin_reset_requests", {
  id: uuid("id").defaultRandom().primaryKey(),
  memberId: uuid("member_id").notNull().references(() => members.id, { onDelete: "cascade" }),
  memberCode: varchar("member_code", { length: 24 }).notNull(),
  requesterName: varchar("requester_name", { length: 160 }).notNull(),
  email: varchar("email", { length: 180 }).notNull(),
  mobile: varchar("mobile", { length: 30 }).notNull(),
  status: applicationStatus("status").notNull().default("PENDING"),
  emailStatus: varchar("email_status", { length: 24 }).notNull().default("NOT_SENT"),
  emailProviderId: varchar("email_provider_id", { length: 160 }),
  requestedAt: timestamp("requested_at", { withTimezone: true }).defaultNow().notNull(),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
});

export const paymentMethods = pgTable("payment_methods", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 60 }).notNull(),
  accountNumber: varchar("account_number", { length: 40 }).notNull(),
  accountName: varchar("account_name", { length: 120 }).notNull(),
  instructions: text("instructions"),
  warning: text("warning"),
  enabled: boolean("enabled").notNull().default(true),
  displayOrder: integer("display_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const payments = pgTable("payments", {
  id: uuid("id").defaultRandom().primaryKey(),
  memberId: uuid("member_id").references(() => members.id, { onDelete: "cascade" }),
  paymentMethodId: uuid("payment_method_id").references(() => paymentMethods.id),
  feeType: varchar("fee_type", { length: 80 }).notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  transactionId: varchar("transaction_id", { length: 120 }).unique(),
  screenshotUrl: text("screenshot_url"),
  note: text("note"),
  status: paymentStatus("status").notNull().default("PENDING"),
  verifiedAt: timestamp("verified_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const tournamentApplications = pgTable("tournament_applications", {
  id: uuid("id").defaultRandom().primaryKey(),
  teamName: varchar("team_name", { length: 160 }).notNull(),
  clubName: varchar("club_name", { length: 160 }).notNull(),
  managerName: varchar("manager_name", { length: 160 }).notNull(),
  mobile: varchar("mobile", { length: 30 }).notNull(),
  email: varchar("email", { length: 180 }).notNull(),
  playerCount: integer("player_count").notNull(),
  category: varchar("category", { length: 80 }).notNull(),
  address: text("address").notNull(),
  status: applicationStatus("status").notNull().default("PENDING"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const contactMessages = pgTable("contact_messages", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  mobile: varchar("mobile", { length: 30 }),
  email: varchar("email", { length: 180 }).notNull(),
  subject: varchar("subject", { length: 200 }).notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const banners = pgTable("banners", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: varchar("title", { length: 180 }).notNull(),
  subtitle: text("subtitle").notNull(),
  eyebrow: varchar("eyebrow", { length: 120 }).notNull().default("KULANANDAPUR'S FOOTBALL LEGACY"),
  imageUrl: text("image_url").notNull(),
  imagePosition: varchar("image_position", { length: 20 }).notNull().default("center 40%"),
  mobileImageUrl: text("mobile_image_url"),
  mobileImagePosition: varchar("mobile_image_position", { length: 20 }).notNull().default("65% center"),
  buttonText: varchar("button_text", { length: 80 }).notNull().default("Explore match centre"),
  buttonLink: varchar("button_link", { length: 240 }).notNull().default("/matches"),
  isActive: boolean("is_active").notNull().default(true),
  displayOrder: integer("display_order").notNull().default(1),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const lineups = pgTable("lineups", {
  id: uuid("id").defaultRandom().primaryKey(),
  teamName: varchar("team_name", { length: 120 }).notNull(),
  matchTitle: varchar("match_title", { length: 180 }).notNull(),
  formation: varchar("formation", { length: 20 }).notNull().default("4-3-3"),
  isActive: boolean("is_active").notNull().default(true),
  players: jsonb("players").$type<Array<{ slot: string; memberId?: string; name?: string; jersey?: number }>>().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const postStatus = pgEnum("post_status", [
  "DRAFT",
  "PUBLISHED",
]);
export const posts = pgTable("posts", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  category: varchar("category", { length: 60 }).notNull().default("Club News"),
  excerpt: varchar("excerpt", { length: 400 }).notNull(),
  body: text("body").notNull().default(""),
  coverImage: text("cover_image"),
  status: postStatus("status").notNull().default("DRAFT"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const financeCategory = pgEnum("finance_category", [
  "GENERAL",
  "EXPENSE",
  "PLAYER_PAYMENT",
]);
export const financeEntries = pgTable("finance_entries", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  category: financeCategory("category").notNull().default("GENERAL"),
  income: numeric("income", { precision: 12, scale: 2 }).notNull().default("0"),
  expense: numeric("expense", { precision: 12, scale: 2 }).notNull().default("0"),
  memberId: uuid("member_id").references(() => members.id, { onDelete: "set null" }),
  method: varchar("method", { length: 60 }),
  note: varchar("note", { length: 300 }),
  createdBy: varchar("created_by", { length: 180 }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const auditLogs = pgTable("audit_logs", {
  id: uuid("id").defaultRandom().primaryKey(),
  actor: varchar("actor", { length: 160 }).notNull(),
  action: varchar("action", { length: 180 }).notNull(),
  entityType: varchar("entity_type", { length: 80 }).notNull(),
  entityId: varchar("entity_id", { length: 100 }),
  details: jsonb("details").$type<Record<string, unknown>>().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const clubSettings = pgTable("club_settings", {
  id: uuid("id").defaultRandom().primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: jsonb("value").$type<Record<string, unknown>>().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const matches = pgTable("matches", {
  id: uuid("id").defaultRandom().primaryKey(),
  opponentName: varchar("opponent_name", { length: 120 }).notNull(),
  opponentLogoUrl: text("opponent_logo_url"),
  matchDatetime: timestamp("match_datetime", { withTimezone: true }).notNull(),
  competition: varchar("competition", { length: 120 }),
  groupName: varchar("group_name", { length: 60 }),
  venue: varchar("venue", { length: 160 }),
  matchType: varchar("match_type", { length: 40 }).notNull().default("LEAGUE"),
  homeAway: varchar("home_away", { length: 10 }).notNull().default("HOME"),
  status: varchar("status", { length: 20 }).notNull().default("UPCOMING"),
  homeScore: integer("home_score"),
  awayScore: integer("away_score"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});
