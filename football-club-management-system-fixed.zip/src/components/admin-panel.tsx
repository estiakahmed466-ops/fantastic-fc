"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Activity, AlertTriangle, ArrowDown, ArrowUp, BadgeCheck, Bell, CalendarDays, ChartNoAxesCombined, Check, CheckCircle2,
  ChevronDown, ChevronRight, CircleDollarSign, CircleUserRound, ClipboardList, Clock3, Coins,
  CreditCard, Download, Eye, FileText, FolderDown, Goal, HandCoins, History, ImagePlus, ImageUp,
  Images, KeyRound, Landmark, LayoutDashboard, LockKeyhole, LogOut, Mail, Menu, Megaphone,
  MoreHorizontal, Newspaper, PanelsTopLeft, Pencil, Plus, Receipt, RefreshCw, Search, Send,
  Settings, ShieldCheck, Shirt, Smartphone, Swords, Trash2, Trophy, Upload, UserCheck, UserRoundX,
  Users, WalletCards, X, XCircle, type LucideIcon,
} from "lucide-react";
import { useEffect, useMemo, useState, type ChangeEvent, type FormEvent } from "react";
import {
  adminMembers, adminNav, fixtures, images, paymentHistory,
  paymentMethods as initialMethods, playerImages,
  type Player,
} from "@/lib/club-data";
import { useI18n } from "@/lib/i18n";
import { defaultBranding, useBranding, type BrandingSettings } from "@/lib/branding";
import { playNotificationSound } from "@/lib/notification-sound";
import { fallbackBanner, type ClubBanner } from "@/lib/banner";
import { Avatar, Button, ClubLogo, FormMessage, LanguageSwitcher, Modal, Panel, PaymentLogo, StatCard, StatusPill } from "./ui";
import { AdminRecordModal, OneTimePin, type DetailField } from "./admin-record-modal";

const adminIcons: Record<string, LucideIcon> = {
  LayoutDashboard, Users, CircleUserRound, UserCheck, Shirt, Goal, KeyRound, ClipboardList,
  Bell, History, CreditCard, BadgeCheck, ChartNoAxesCombined, Landmark, Receipt, WalletCards,
  Swords, CalendarDays, Trophy, Newspaper, Images, Megaphone, Settings, PanelsTopLeft,
  ImageUp, FolderDown, ShieldCheck, Coins, LockKeyhole,
};

function timeAgo(iso: string, tr: (en: string, bn: string) => string) {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.max(0, Math.floor(diffMs / 60000));
  if (mins < 1) return tr("just now", "এইমাত্র");
  if (mins < 60) return `${mins} ${tr("min ago", "মিনিট আগে")}`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} ${tr("hour ago", "ঘণ্টা আগে")}`;
  const days = Math.floor(hours / 24);
  return `${days} ${tr("day ago", "দিন আগে")}`;
}

type AdminOverviewNotice = { title: string; subtitle: string; href: string; at: string };
type AdminOverview = {
  badges: Record<string, string>;
  notices: AdminOverviewNotice[];
  loaded: boolean;
};

// Single source of truth for admin badge counts + the notification feed, computed from live
// data (pending members, pending payments, pending tournament applications, PIN resets) —
// used by the sidebar badges, the header notification bell, and the Admin Notifications page.
function useAdminOverview(tr: (en: string, bn: string) => string): AdminOverview {
  const [badges, setBadges] = useState<Record<string, string>>({});
  const [notices, setNotices] = useState<AdminOverviewNotice[]>([]);
  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [mRes, pRes, tRes, prRes] = await Promise.all([
          fetch("/api/admin/members", { cache: "no-store" }),
          fetch("/api/admin/payments", { cache: "no-store" }),
          fetch("/api/admin/tournament-applications", { cache: "no-store" }),
          fetch("/api/admin/pin-resets", { cache: "no-store" }),
        ]);
        const mData = await mRes.json() as { members?: AdminMemberRow[] };
        const pData = await pRes.json() as { payments?: { transactionId: string; status: string; submittedAt: string; memberName: string | null }[] };
        const tData = await tRes.json() as { applications?: { id: string; teamName: string; status: string; createdAt: string }[] };
        const prData = await prRes.json() as { requests?: { status: string; requesterName: string; memberCode: string; resolvedAt?: string | null; emailStatus: string }[] };
        if (cancelled) return;

        const pendingMembers = (mData.members || []).filter(m => m.status === "PENDING");
        const pendingPayments = (pData.payments || []).filter(p => p.status === "PENDING");
        const pendingTournament = (tData.applications || []).filter(a => a.status === "PENDING");
        const pendingPinResets = (prData.requests || []).filter(r => r.status === "PENDING");

        setBadges({
          "/admin/approvals": pendingMembers.length ? String(pendingMembers.length) : "",
          "/admin/verification": pendingPayments.length ? String(pendingPayments.length) : "",
          "/admin/tournament-apps": pendingTournament.length ? String(pendingTournament.length) : "",
          "/admin/pin-resets": pendingPinResets.length ? String(pendingPinResets.length) : "",
        });

        const items: AdminOverviewNotice[] = [
          ...pendingMembers.slice(0, 3).map(m => ({ title: tr("New member application", "নতুন সদস্য আবেদন"), subtitle: `${m.name} • ${timeAgo(m.joined, tr)}`, href: "/admin/approvals", at: m.joined })),
          ...pendingPayments.slice(0, 3).map(p => ({ title: tr("Payment needs verification", "পেমেন্ট যাচাই প্রয়োজন"), subtitle: `${p.transactionId} • ${timeAgo(p.submittedAt, tr)}`, href: "/admin/verification", at: p.submittedAt })),
          ...pendingTournament.slice(0, 3).map(t => ({ title: tr("Tournament application", "টুর্নামেন্ট আবেদন"), subtitle: `${t.teamName} • ${timeAgo(t.createdAt, tr)}`, href: "/admin/tournament-apps", at: t.createdAt })),
        ].sort((a, b) => new Date(b.at).getTime() - new Date(a.at).getTime());

        setNotices(items);
      } catch { /* overview is best-effort */ }
      finally { if (!cancelled) setLoaded(true); }
    })();
    return () => { cancelled = true };
  }, [tr]);
  return { badges, notices, loaded };
}

function AdminSidebar({ open, close }: { open: boolean; close: () => void }) {
  const path = usePathname(); const { language, tr } = useI18n(); const { branding } = useBranding();
  const { badges: liveBadges } = useAdminOverview(tr);
  const sections=[
    {en:"OVERVIEW",bn:"সংক্ষিপ্ত চিত্র",items:adminNav.slice(0,1)},
    {en:"PEOPLE & ACCESS",bn:"সদস্য ও প্রবেশ",items:adminNav.slice(1,10)},
    {en:"FINANCE",bn:"অর্থ ব্যবস্থাপনা",items:adminNav.slice(10,17)},
    {en:"SPORTS",bn:"খেলা পরিচালনা",items:adminNav.slice(17,20)},
    {en:"CONTENT & SYSTEM",bn:"কনটেন্ট ও সিস্টেম",items:adminNav.slice(20)},
  ];
  const badges = liveBadges;
  return <aside className={`admin-sidebar ${open?"open":""}`}><div className="admin-brand"><ClubLogo compact inverse/><span><b>{branding.shortName}</b><small>{tr("ADMIN CONSOLE","অ্যাডমিন কনসোল")}</small></span><button onClick={close}><X/></button></div><nav>{sections.map(section=><div className="admin-nav-section" key={section.en}><small>{language==="bn"?section.bn:section.en}</small>{section.items.map(([href,en,bn,icon])=>{const Icon=adminIcons[icon]||Settings;const active=path===href;return <Link key={href} href={href} className={active?"active":""} onClick={close}><Icon/><span>{language==="bn"?bn:en}</span>{badges[href]&&<em>{badges[href]}</em>}</Link>})}</div>)}</nav><div className="admin-sidebar-foot"><div><ShieldCheck/><span><b>{tr("Secure console","নিরাপদ কনসোল")}</b><small>{tr("Protected admin session","সুরক্ষিত অ্যাডমিন সেশন")}</small></span><i/></div><Link href="/login" onClick={()=>{fetch("/api/admin/auth",{method:"DELETE"}).catch(()=>{})}}><LogOut/>{tr("Sign out","লগআউট")}</Link></div></aside>
}

function AdminHeader({ openMenu }: { openMenu: () => void }) {
  const { tr, language } = useI18n(); const { branding } = useBranding();
  const [show,setShow]=useState(false);const [quick,setQuick]=useState(false);const [query,setQuery]=useState("");const [adminReadIds,setAdminReadIds]=useState<Set<number>>(new Set());
  const [pinNotices,setPinNotices]=useState<[string,string,string][]>([]);
  const [adminEmail,setAdminEmail]=useState<string|null>(null);
  useEffect(()=>{(async()=>{try{const res=await fetch("/api/admin/pin-resets",{cache:"no-store"});const data=await res.json() as {requests?:{requesterName:string;memberCode:string;emailStatus:string;resolvedAt?:string|null;requestedAt:string}[]};const recent=(data.requests||[]).filter(r=>r.resolvedAt).slice(0,2).map(r=>[`PIN auto-reset — ${r.requesterName}`,`${r.memberCode} • ${r.emailStatus==="SENT"?tr("emailed","ইমেইল হয়েছে"):tr("could not email","ইমেইল ব্যর্থ")}`,"/admin/pin-resets"] as [string,string,string]);setPinNotices(recent)}catch{ /* notifications are best-effort */ }})()},[tr]);
  useEffect(()=>{(async()=>{try{const res=await fetch("/api/admin/auth",{cache:"no-store"});const data=await res.json() as {email?:string};setAdminEmail(data.email||null)}catch{ /* best-effort */ }})()},[]);
  const { notices: liveNotices } = useAdminOverview(tr);
  const adminNotices:[string,string,string][]=[...pinNotices,...liveNotices.map(n=>[n.title,n.subtitle,n.href] as [string,string,string])];
  const adminUnreadCount=adminNotices.length-adminReadIds.size;
  const results=adminNav.filter(([,en,bn])=>`${en} ${bn}`.toLowerCase().includes(query.toLowerCase())).slice(0,7);
  useEffect(()=>{const shortcut=(event:KeyboardEvent)=>{if((event.metaKey||event.ctrlKey)&&event.key.toLowerCase()==="k"){event.preventDefault();document.getElementById("admin-global-search")?.focus()}};window.addEventListener("keydown",shortcut);return()=>window.removeEventListener("keydown",shortcut)},[]);
  return <header className="admin-header"><button className="portal-menu" onClick={openMenu}><Menu/></button><div className="admin-header-title"><span>{tr("ADMINISTRATION","প্রশাসন")}</span><b>{branding.adminName}</b></div><div className="admin-header-actions"><div className="admin-search"><Search/><input id="admin-global-search" value={query} onChange={e=>setQuery(e.target.value)} placeholder={tr("Search admin tools...","অ্যাডমিন টুল খুঁজুন...")}/><kbd>⌘ K</kbd>{query&&<div className="admin-search-results"><small>{tr("QUICK NAVIGATION","দ্রুত নেভিগেশন")}</small>{results.length?results.map(([href,en,bn,icon])=>{const Icon=adminIcons[icon]||Settings;return <Link href={href} key={href} onClick={()=>setQuery("")}><span><Icon/></span><div><b>{language==="bn"?bn:en}</b><small>{href}</small></div><ChevronRight/></Link>}):<p>{tr("No admin option found.","কোনো অ্যাডমিন অপশন পাওয়া যায়নি।")}</p>}</div>}</div><div className="admin-quick-wrap"><button className="admin-quick-button" onClick={()=>setQuick(v=>!v)}><Plus/>{tr("Quick add","দ্রুত যোগ")}<ChevronDown/></button>{quick&&<div className="admin-quick-menu"><Link href="/admin/members" onClick={()=>setQuick(false)}><Users/><span><b>{tr("New member","নতুন সদস্য")}</b><small>{tr("Create member account","সদস্য অ্যাকাউন্ট তৈরি")}</small></span></Link><Link href="/admin/payments" onClick={()=>setQuick(false)}><CreditCard/><span><b>{tr("Verify payment","পেমেন্ট যাচাই")}</b><small>{tr("Find transaction ID","লেনদেন আইডি খুঁজুন")}</small></span></Link><Link href="/admin/banners" onClick={()=>setQuick(false)}><ImagePlus/><span><b>{tr("New banner","নতুন ব্যানার")}</b><small>{tr("Upload homepage image","হোমপেজ ছবি আপলোড")}</small></span></Link><Link href="/admin/news" onClick={()=>setQuick(false)}><Newspaper/><span><b>{tr("Publish news","সংবাদ প্রকাশ")}</b><small>{tr("Create club story","ক্লাব সংবাদ তৈরি")}</small></span></Link></div>}</div><LanguageSwitcher dark/><button className="header-bell" onClick={()=>{if(!show)playNotificationSound();setShow(v=>!v)}}><Bell/>{adminUnreadCount>0&&<i>{adminUnreadCount}</i>}</button><div className="header-profile admin"><Avatar name={adminEmail||"Admin"}/><span><b>{adminEmail||tr("Admin","অ্যাডমিন")}</b><small>SUPER ADMIN</small></span><ChevronDown/></div></div>{show&&<div className="notice-dropdown admin-drop"><div><b>{tr("Admin notifications","অ্যাডমিন নোটিফিকেশন")}</b><Link href="/admin/admin-notifications">{tr("View all","সব দেখুন")}</Link></div>{adminNotices.map((n,ni)=><Link href={n[2]} key={`${n[0]}-${ni}`} onClick={()=>{setAdminReadIds(prev=>new Set([...prev,ni]));setShow(false)}}><span className={adminReadIds.has(ni)?"":"unread"}><Bell/></span><p><b>{n[0]}</b><small>{n[1]}</small></p></Link>)}{adminNotices.length===0&&<p className="empty-inline" style={{padding:"16px 20px"}}>{tr("No new notifications.","নতুন কোনো নোটিফিকেশন নেই।")}</p>}</div>}</header>
}

function AdminTitle({ title, bn, body, bodyBn, action }: { title:string;bn:string;body?:string;bodyBn?:string;action?:React.ReactNode }){const {tr}=useI18n();return <div className="admin-page-title"><div><p>{tr("ADMIN CONSOLE","অ্যাডমিন কনসোল")}<ChevronRight/>{tr(title,bn)}</p><h1>{tr(title,bn)}</h1>{body&&<span>{tr(body,bodyBn||body)}</span>}</div>{action}</div>}

function AdminWelcome({pendingMembers=0,pendingPayments=0}:{pendingMembers?:number;pendingPayments?:number}) {
  const { tr } = useI18n(); const { branding } = useBranding();
  return <section className="admin-welcome"><div className="admin-welcome-copy"><span><i/>{tr("SYSTEM ONLINE • ALL SERVICES HEALTHY", "সিস্টেম সচল • সব সেবা ঠিক আছে")}</span><h2>{tr("WELCOME BACK.", "স্বাগতম।")}</h2><p>{tr(`Everything at ${branding.shortName} is under control. Choose a quick action or explore today's club activity.`, `${branding.shortName}-এর সবকিছু নিয়ন্ত্রণে আছে। দ্রুত কাজ বাছুন অথবা আজকের ক্লাব কার্যক্রম দেখুন।`)}</p></div><div className="admin-welcome-actions"><Link href="/" target="_blank"><Eye/><span><b>{tr("View website", "ওয়েবসাইট দেখুন")}</b><small>{tr("Open public home", "পাবলিক হোম খুলুন")}</small></span></Link><Link href="/admin/approvals"><UserCheck/><span><b>{tr("Approvals", "অনুমোদন")}</b><small>{pendingMembers} {tr("waiting", "অপেক্ষমাণ")}</small></span></Link><Link href="/admin/verification"><BadgeCheck/><span><b>{tr("Verify payments", "পেমেন্ট যাচাই")}</b><small>{pendingPayments} {tr("pending", "অপেক্ষমাণ")}</small></span></Link><Link href="/admin/banners"><ImagePlus/><span><b>{tr("Update banner", "ব্যানার আপডেট")}</b><small>{tr("Refresh homepage", "হোমপেজ সাজান")}</small></span></Link></div></section>;
}

type AdminMemberRow={databaseId?:string;id:string;name:string;mobile:string;email?:string;dateOfBirth?:string|null;address?:string|null;emergencyContact?:string|null;jersey:number;position:string;joined:string;status:string;image:string;isCaptain?:boolean;matchesPlayed?:number;goals?:number;assists?:number;rating?:string|null};

function AdminDashboard(){
  const {tr}=useI18n();
  const [members,setMembers]=useState<AdminMemberRow[]>([]);
  const [pays,setPays]=useState<{status:string;amount:string}[]>([]);
  const [pinPending,setPinPending]=useState(0);
  const [recentLogs,setRecentLogs]=useState<{id:string;actor:string;action:string;entityType:string;createdAt:string}[]>([]);
  const [loaded,setLoaded]=useState(false);
  useEffect(()=>{(async()=>{
    try{
      const [mRes,pRes,prRes,aRes]=await Promise.all([
        fetch("/api/admin/members",{cache:"no-store"}),
        fetch("/api/admin/payments",{cache:"no-store"}),
        fetch("/api/admin/pin-resets",{cache:"no-store"}),
        fetch("/api/admin/audit",{cache:"no-store"}),
      ]);
      const mData=await mRes.json() as {members?:AdminMemberRow[]};
      const pData=await pRes.json() as {payments?:{status:string;amount:string}[]};
      const prData=await prRes.json() as {requests?:{status:string}[]};
      const aData=await aRes.json() as {logs?:{id:string;actor:string;action:string;entityType:string;createdAt:string}[]};
      setMembers(mData.members||[]);
      setPays(pData.payments||[]);
      setPinPending((prData.requests||[]).filter(r=>r.status==="PENDING").length);
      setRecentLogs(aData.logs||[]);
    }catch{ /* dashboard is best-effort */ }
    finally{setLoaded(true)}
  })()},[]);
  const totalMembers=members.length;
  const activeMembers=members.filter(m=>m.status==="ACTIVE").length;
  const pendingMembers=members.filter(m=>m.status==="PENDING").length;
  const inactiveMembers=totalMembers-activeMembers-pendingMembers;
  const collection=pays.filter(p=>p.status==="PAID").reduce((sum,p)=>sum+Number(p.amount),0);
  const pendingPayments=pays.filter(p=>p.status==="PENDING").length;
  const expense=0;
  const balance=collection-expense;
  const toneFor=(entityType:string)=>entityType==="PAYMENT"?"green":entityType==="PIN_RESET"?"violet":entityType==="ADMIN_AUTH"?"blue":"amber";
  return <><AdminTitle title="Dashboard" bn="ড্যাশবোর্ড" body="Club performance and operations at a glance." bodyBn="এক নজরে ক্লাবের পারফরম্যান্স ও কার্যক্রম।" action={<div className="date-chip"><CalendarDays/> {new Intl.DateTimeFormat("en-GB",{day:"2-digit",month:"long",year:"numeric"}).format(new Date())}</div>}/><AdminWelcome pendingMembers={pendingMembers} pendingPayments={pendingPayments}/><div className="admin-kpis"><StatCard icon={Users} label={tr("Total members","মোট সদস্য")} value={loaded?String(totalMembers):"…"} href="/admin/members"/><StatCard icon={BadgeCheck} label={tr("Active members","সক্রিয় সদস্য")} value={loaded?String(activeMembers):"…"} tone="blue" href="/admin/members"/><StatCard icon={Clock3} label={tr("Pending members","অপেক্ষমাণ সদস্য")} value={loaded?String(pendingMembers):"…"} change={pendingMembers>0?tr("Needs review","যাচাই প্রয়োজন"):undefined} tone="orange" href="/admin/approvals"/><StatCard icon={CircleDollarSign} label={tr("Current balance","বর্তমান ব্যালেন্স")} value={loaded?`৳ ${balance.toLocaleString()}`:"…"} tone="violet" href="/admin/financial"/></div><div className="admin-kpis secondary"><StatCard icon={HandCoins} label={tr("Total collection","মোট সংগ্রহ")} value={loaded?`৳ ${collection.toLocaleString()}`:"…"} href="/admin/financial"/><StatCard icon={Receipt} label={tr("Total expense","মোট খরচ")} value={`৳ ${expense.toLocaleString()}`} tone="red" href="/admin/expenses"/><StatCard icon={CreditCard} label={tr("Pending payments","অপেক্ষমাণ পেমেন্ট")} value={loaded?String(pendingPayments):"…"} tone="orange" href="/admin/payments"/><StatCard icon={UserRoundX} label={tr("Pending PIN resets","অপেক্ষমাণ পিন রিসেট")} value={loaded?String(pinPending):"…"} tone="red" href="/admin/pin-resets"/></div><div className="admin-dashboard-grid"><Panel title={tr("Collection summary","সংগ্রহের সারাংশ")}>{collection===0?<p className="empty-inline">{tr("No verified collections yet. Numbers appear here as payments are approved.","এখনো কোনো যাচাইকৃত সংগ্রহ নেই। পেমেন্ট অনুমোদিত হলে এখানে দেখা যাবে।")}</p>:<div className="finance-equation compact"><span><b>৳ {collection.toLocaleString()}</b>{tr("VERIFIED COLLECTION","যাচাইকৃত সংগ্রহ")}</span><em>−</em><span><b>৳ {expense.toLocaleString()}</b>{tr("EXPENSE","খরচ")}</span><em>=</em><span className="result"><b>৳ {balance.toLocaleString()}</b>{tr("BALANCE","ব্যালেন্স")}</span></div>}</Panel><Panel title={tr("Members overview","সদস্য সংক্ষিপ্ত চিত্র")} action={<Link className="panel-link" href="/admin/members">{tr("Manage","পরিচালনা")}<ChevronRight/></Link>}><div className="donut-wrap"><div className="member-donut"><span><b>{totalMembers}</b><small>TOTAL</small></span></div><div className="donut-legend"><p><i className="active"/><span>{tr("Active","সক্রিয়")}</span><b>{activeMembers}</b></p><p><i className="pending"/><span>{tr("Pending","অপেক্ষমাণ")}</span><b>{pendingMembers}</b></p><p><i className="inactive"/><span>{tr("Inactive","নিষ্ক্রিয়")}</span><b>{Math.max(inactiveMembers,0)}</b></p></div></div></Panel></div><div className="admin-dashboard-grid lower"><Panel title={tr("Requires attention","মনোযোগ প্রয়োজন")}><div className="attention-grid"><Link href="/admin/approvals"><span className="orange"><UserCheck/></span><div><b>{pendingMembers}</b><small>{tr("Member approvals","সদস্য অনুমোদন")}</small></div><ChevronRight/></Link><Link href="/admin/payments"><span className="blue"><CreditCard/></span><div><b>{pendingPayments}</b><small>{tr("Payment verifications","পেমেন্ট যাচাই")}</small></div><ChevronRight/></Link><Link href="/admin/pin-resets"><span className="violet"><KeyRound/></span><div><b>{pinPending}</b><small>{tr("PIN reset requests","পিন রিসেট অনুরোধ")}</small></div><ChevronRight/></Link></div></Panel><Panel title={tr("Recent activity","সাম্প্রতিক কার্যক্রম")} action={<Link className="panel-link" href="/admin/audit">{tr("Audit log","অডিট লগ")}<ChevronRight/></Link>}><div className="activity-list">{recentLogs.length===0?<p className="empty-inline">{tr("No activity recorded yet.","এখনো কোনো কার্যক্রম রেকর্ড হয়নি।")}</p>:recentLogs.slice(0,3).map(a=><div key={a.id}><span className={toneFor(a.entityType)}><Activity/></span><div><b>{a.action}</b><p>{a.entityType}</p><small>{a.actor} • {new Date(a.createdAt).toLocaleString()}</small></div></div>)}</div></Panel></div></>
}
function MemberManagement({approvals=false}:{approvals?:boolean}) {
  const {tr}=useI18n();
  const [rows,setRows]=useState<AdminMemberRow[]>([]);
  const [loaded,setLoaded]=useState(false);
  const [search,setSearch]=useState("");
  const [statusFilter,setStatusFilter]=useState("ALL");
  const [positionFilter,setPositionFilter]=useState("ALL");
  const [selected,setSelected]=useState<AdminMemberRow|null>(null);
  const [adding,setAdding]=useState(false);
  const [passwordInfo,setPasswordInfo]=useState<{memberId:string;memberName:string;passwordNote:string;hashPreview:string}|null>(null);
  async function viewPassword(memberCode:string){try{const res=await fetch("/api/admin/member-password",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({memberId:memberCode})});const data=await res.json() as typeof passwordInfo;setPasswordInfo(data)}catch{/* error handled */}}
  useEffect(()=>{void (async()=>{try{const response=await fetch("/api/admin/members",{cache:"no-store"});const data=await response.json() as {members?:Array<Omit<AdminMemberRow,"jersey"|"image"|"joined"|"position">&{jersey:number|null;image:string|null;joined:string|null;position:string|null}>};if(response.ok)setRows((data.members||[]).map((member,index)=>({...member,jersey:member.jersey||0,image:member.image||playerImages[index%playerImages.length],joined:member.joined||"—",position:member.position?member.position.charAt(0)+member.position.slice(1).toLowerCase():"Not set"})))}catch{/* leave rows empty on failure */}finally{setLoaded(true)}})()},[]);
  const list=rows.filter(r=>(!approvals||r.status==="PENDING")&&(statusFilter==="ALL"||r.status===statusFilter)&&(positionFilter==="ALL"||r.position===positionFilter)&&`${r.name} ${r.id} ${r.mobile} ${r.email||""}`.toLowerCase().includes(search.toLowerCase()));
  async function status(id:string,next:string){const member=rows.find(x=>x.id===id);setRows(v=>v.map(x=>x.id===id?{...x,status:next}:x));setSelected(v=>v?.id===id?{...v,status:next}:v);if(member?.databaseId)await fetch("/api/admin/members",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:member.databaseId,status:next})})}
  function addMember(event:FormEvent<HTMLFormElement>){event.preventDefault();const data=new FormData(event.currentTarget);const next={id:`FFC-${String(rows.length+21).padStart(4,"0")}`,name:String(data.get("name")),mobile:String(data.get("mobile")),jersey:Number(data.get("jersey"))||0,position:String(data.get("position")),joined:new Date().toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"}),status:"PENDING",image:playerImages[0]};setRows(v=>[next,...v]);setAdding(false)}
  const fields:DetailField[]=selected?[
    {label:tr("Member ID","সদস্য আইডি"),value:selected.id},{label:tr("Full name","পূর্ণ নাম"),value:selected.name},
    {label:tr("Mobile","মোবাইল"),value:selected.mobile},{label:tr("Email","ইমেইল"),value:selected.email||tr("Not provided","দেওয়া হয়নি")},
    {label:tr("Jersey number","জার্সি নম্বর"),value:selected.jersey?`#${selected.jersey}`:tr("Not set","নির্ধারিত নয়")},{label:tr("Position","পজিশন"),value:selected.position},
    {label:tr("Joining date","যোগদানের তারিখ"),value:selected.joined},{label:tr("Account status","অ্যাকাউন্ট অবস্থা"),value:<StatusPill status={selected.status}/>},
    {label:tr("Date of birth","জন্মতারিখ"),value:selected.dateOfBirth||tr("Not provided","দেওয়া হয়নি")},{label:tr("Emergency contact","জরুরি যোগাযোগ"),value:selected.emergencyContact||tr("Not provided","দেওয়া হয়নি")},
    {label:tr("Address","ঠিকানা"),value:selected.address||tr("Not provided","দেওয়া হয়নি"),wide:true},
  ]:[];
  return <><AdminTitle title={approvals?"Member Approvals":"Members"} bn={approvals?"সদস্য অনুমোদন":"সদস্য"} body={approvals?"Review complete account information before portal access.":"Search, open and manage every club member account."} bodyBn={approvals?"পোর্টাল ব্যবহারের আগে সম্পূর্ণ অ্যাকাউন্ট তথ্য যাচাই করুন।":"ক্লাবের প্রতিটি সদস্য অ্যাকাউন্ট খুঁজুন, দেখুন ও পরিচালনা করুন।"} action={<Button onClick={()=>setAdding(true)} icon={false}><Plus/>{tr("Add member","সদস্য যোগ")}</Button>}/><Panel><div className="table-toolbar"><div className="search-box"><Search/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder={tr("Search name, ID or mobile...","নাম, আইডি বা মোবাইল খুঁজুন...")}/></div><div className="toolbar-filters"><select value={positionFilter} onChange={e=>setPositionFilter(e.target.value)}><option value="ALL">{tr("All positions","সব পজিশন")}</option><option>Forward</option><option>Midfielder</option><option>Defender</option></select><select value={statusFilter} onChange={e=>setStatusFilter(e.target.value)}><option value="ALL">{tr("All statuses","সব অবস্থা")}</option><option>ACTIVE</option><option>PENDING</option><option>INACTIVE</option><option>REJECTED</option></select></div></div><div className="table-scroll"><table className="data-table admin-table"><thead><tr><th>{tr("MEMBER","সদস্য")}</th><th>{tr("MEMBER ID","সদস্য আইডি")}</th><th>{tr("CONTACT","যোগাযোগ")}</th><th>{tr("PLAYING INFO","খেলার তথ্য")}</th><th>{tr("JOINED","যোগদান")}</th><th>{tr("STATUS","অবস্থা")}</th><th>{tr("ACTIONS","অ্যাকশন")}</th></tr></thead><tbody>{list.map(r=><tr key={r.id}><td><div className="table-person"><Avatar src={r.image} name={r.name}/><span><b>{r.name}</b><small>{r.position}</small></span></div></td><td><b>{r.id}</b></td><td>{r.mobile}</td><td>#{r.jersey} • {r.position}</td><td>{r.joined}</td><td><StatusPill status={r.status}/></td><td><div className="row-actions">{r.status==="PENDING"&&<><button className="approve" title="Approve" onClick={()=>status(r.id,"ACTIVE")}><Check/></button><button className="reject" title="Reject" onClick={()=>status(r.id,"REJECTED")}><X/></button></>}<button title="View complete account" onClick={()=>setSelected(r)}><Eye/></button><button title="More details" onClick={()=>setSelected(r)}><MoreHorizontal/></button></div></td></tr>)}</tbody></table></div>{list.length===0&&<div className="empty-table"><CheckCircle2/><b>{tr("No matching accounts","মিল পাওয়া যায়নি")}</b><p>{tr("Change the filters or search value.","ফিল্টার বা খোঁজার মান পরিবর্তন করুন।")}</p></div>}</Panel>
  <AdminRecordModal open={!!selected} onClose={()=>{setSelected(null);setPasswordInfo(null)}} title={selected?.name||""} subtitle={tr("MEMBER ACCOUNT / APPLICATION","সদস্য অ্যাকাউন্ট / আবেদন")} icon={CircleUserRound} image={selected?.image} status={selected?.status} fields={fields}>{selected&&<>{passwordInfo&&<div className="member-password-view"><LockKeyhole/><div><small>{tr("PASSWORD INFORMATION","পাসওয়ার্ড তথ্য")}</small><b>{passwordInfo.memberName} • {passwordInfo.memberId}</b><p>{passwordInfo.passwordNote}</p><code>{passwordInfo.hashPreview}</code></div></div>}<div className="record-action-bar"><Button icon={false} variant="outline" onClick={()=>void viewPassword(selected.id)}><Eye/>{tr("View password","পাসওয়ার্ড দেখুন")}</Button>{selected.status==="PENDING"&&<><Button icon={false} onClick={()=>status(selected.id,"ACTIVE")}><Check/>{tr("Approve","অনুমোদন")}</Button><Button icon={false} variant="danger" onClick={()=>status(selected.id,"REJECTED")}><X/>{tr("Reject","বাতিল")}</Button></>}</div></>}</AdminRecordModal>
  <Modal open={adding} onClose={()=>setAdding(false)}><form className="modal-form" onSubmit={addMember}><span className="modal-icon"><UserCheck/></span><h2>{tr("Add member account","সদস্য অ্যাকাউন্ট যোগ")}</h2><label>{tr("Full name","পূর্ণ নাম")}<input name="name" required/></label><label>{tr("Mobile","মোবাইল")}<input name="mobile" required/></label><div className="form-grid"><label>{tr("Jersey","জার্সি")}<input name="jersey" type="number" min="1" max="99"/></label><label>{tr("Position","পজিশন")}<select name="position"><option>Forward</option><option>Midfielder</option><option>Defender</option></select></label></div><div className="modal-actions"><Button type="button" variant="outline" icon={false} onClick={()=>setAdding(false)}>{tr("Cancel","বাতিল")}</Button><Button type="submit" icon={false}>{tr("Save account","সংরক্ষণ")}</Button></div></form></Modal></>;
}

function PlayerManagement() {
  const {tr}=useI18n();
  const [rows,setRows]=useState<AdminMemberRow[]>([]);const [loading,setLoading]=useState(true);const [search,setSearch]=useState("");
  const [editor,setEditor]=useState<AdminMemberRow|"new"|null>(null);const [selected,setSelected]=useState<AdminMemberRow|null>(null);const [busy,setBusy]=useState(false);
  async function load(){setLoading(true);try{const res=await fetch("/api/admin/members",{cache:"no-store"});const data=await res.json() as {members?:Array<Omit<AdminMemberRow,"jersey"|"image"|"joined"|"position">&{jersey:number|null;image:string|null;joined:string|null;position:string|null}>};if(res.ok)setRows((data.members||[]).map(m=>({...m,jersey:m.jersey||0,image:m.image||"",joined:m.joined||"—",position:m.position?m.position.charAt(0)+m.position.slice(1).toLowerCase():"Not set"})))}finally{setLoading(false)}}
  useEffect(()=>{void load()},[]);
  const squad=rows.filter(r=>r.status==="ACTIVE"&&r.jersey>0);
  const availableToAdd=rows.filter(r=>r.status==="ACTIVE"&&!r.jersey);
  async function save(event:FormEvent<HTMLFormElement>){
    event.preventDefault();const data=new FormData(event.currentTarget);const target=editor==="new"?null:editor;
    const memberDatabaseId=editor==="new"?String(data.get("memberDatabaseId")):target?.databaseId;
    if(!memberDatabaseId)return;
    setBusy(true);
    try{
      const res=await fetch("/api/admin/members",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:memberDatabaseId,jerseyNumber:Number(data.get("jersey"))||null,position:String(data.get("position")||"FORWARD")})});
      if(res.ok)await load();
    }finally{setBusy(false);setEditor(null)}
  }
  async function toggleCaptain(row:AdminMemberRow){if(!row.databaseId)return;setBusy(true);try{const res=await fetch("/api/admin/members",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:row.databaseId,isCaptain:!row.isCaptain})});if(res.ok){await load();setSelected(v=>v&&v.databaseId===row.databaseId?{...v,isCaptain:!v.isCaptain}:v)}}finally{setBusy(false)}}
  async function removeFromSquad(row:AdminMemberRow){if(!row.databaseId)return;if(!window.confirm(tr("Remove this player from the squad? Their member account stays intact.","এই খেলোয়াড়কে স্কোয়াড থেকে সরাবেন? সদস্য অ্যাকাউন্ট বহাল থাকবে।")))return;setBusy(true);try{const res=await fetch("/api/admin/members",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:row.databaseId,jerseyNumber:null,position:null,isCaptain:false})});if(res.ok){await load();setSelected(null)}}finally{setBusy(false)}}
  async function toggleBlacklist(row:AdminMemberRow){if(!row.databaseId)return;setBusy(true);try{const res=await fetch("/api/admin/members",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:row.databaseId,status:row.status==="BLACKLISTED"?"ACTIVE":"BLACKLISTED"})});if(res.ok)await load()}finally{setBusy(false)}}
  const fields:DetailField[]=selected?[{label:tr("Player name","খেলোয়াড়ের নাম"),value:selected.name},{label:tr("Jersey number","জার্সি নম্বর"),value:`#${selected.jersey}`},{label:tr("Position","পজিশন"),value:selected.position},{label:tr("Matches","ম্যাচ"),value:selected.matchesPlayed??0},{label:tr("Goals","গোল"),value:selected.goals??0},{label:tr("Assists","অ্যাসিস্ট"),value:selected.assists??0},{label:tr("Rating","রেটিং"),value:selected.rating||"—"},{label:tr("Role","ভূমিকা"),value:selected.isCaptain?tr("Club Captain","ক্লাব অধিনায়ক"):tr("Squad Player","স্কোয়াড খেলোয়াড়")},{label:tr("Account access","অ্যাকাউন্ট প্রবেশ"),value:<StatusPill status={selected.status}/>,wide:true}]:[];
  return <><AdminTitle title="Player Management" bn="খেলোয়াড় ব্যবস্থাপনা" body="Assign real active members to the squad, with jersey number, position and stats saved permanently." bodyBn="প্রকৃত সক্রিয় সদস্যদের স্কোয়াডে যুক্ত করুন, জার্সি নম্বর, পজিশন ও পরিসংখ্যান স্থায়ীভাবে সংরক্ষিত হবে।" action={<Button onClick={()=>setEditor("new")} icon={false} disabled={availableToAdd.length===0}><Plus/>{tr("Add player","খেলোয়াড় যোগ")}</Button>}/><Panel><div className="table-toolbar"><div className="search-box"><Search/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder={tr("Search name, position or jersey...","নাম, পজিশন বা জার্সি খুঁজুন...")}/></div><span>{squad.length} {tr("players","খেলোয়াড়")}</span></div>{loading?<div className="empty-table"><RefreshCw className="spin"/><b>{tr("Loading squad...","স্কোয়াড লোড হচ্ছে...")}</b></div>:squad.length===0?<div className="empty-table"><CircleUserRound/><b>{tr("No squad players yet","এখনো কোনো স্কোয়াড খেলোয়াড় নেই")}</b><p>{tr("Use Add player to assign a jersey to an active member.","একজন সক্রিয় সদস্যকে জার্সি দিতে Add player ব্যবহার করুন।")}</p></div>:<div className="table-scroll"><table className="data-table admin-table"><thead><tr><th>{tr("PLAYER","খেলোয়াড়")}</th><th>{tr("JERSEY","জার্সি")}</th><th>{tr("POSITION","পজিশন")}</th><th>{tr("MATCHES","ম্যাচ")}</th><th>{tr("STATUS","অবস্থা")}</th><th>{tr("ACTIONS","অ্যাকশন")}</th></tr></thead><tbody>{squad.filter(p=>`${p.name} ${p.position} ${p.jersey}`.toLowerCase().includes(search.toLowerCase())).map(p=><tr key={p.databaseId}><td><div className="table-person"><Avatar src={p.image} name={p.name}/><span><b>{p.name}</b><small>{p.isCaptain&&"CAPTAIN • "}{p.id}</small></span></div></td><td><b className="jersey-cell">{p.jersey}</b></td><td>{p.position}</td><td>{p.matchesPlayed??0}</td><td><StatusPill status={p.status}/></td><td><div className="row-actions"><button title="View complete player profile" onClick={()=>setSelected(p)}><Eye/></button><button title="Edit player" disabled={busy} onClick={()=>setEditor(p)}><Pencil/></button><button title={p.isCaptain?"Remove captain":"Mark captain"} className={p.isCaptain?"approve":""} disabled={busy} onClick={()=>void toggleCaptain(p)}><ShieldCheck/></button><button title={p.status==="BLACKLISTED"?"Unban":"Blacklist"} className={p.status==="BLACKLISTED"?"approve":"reject"} disabled={busy} onClick={()=>void toggleBlacklist(p)}>{p.status==="BLACKLISTED"?<RefreshCw/>:<LockKeyhole/>}</button><button title="Remove from squad" className="reject" disabled={busy} onClick={()=>void removeFromSquad(p)}><Trash2/></button></div></td></tr>)}</tbody></table></div>}</Panel><AdminRecordModal open={!!selected} onClose={()=>setSelected(null)} title={selected?.name||""} subtitle={tr("COMPLETE PLAYER PROFILE","সম্পূর্ণ খেলোয়াড় প্রোফাইল")} icon={CircleUserRound} image={selected?.image} status={selected?.status} fields={fields}>{selected&&<div className="record-action-bar"><Button icon={false} variant="outline" onClick={()=>{setEditor(selected);setSelected(null)}}><Pencil/>{tr("Edit player","খেলোয়াড় সম্পাদনা")}</Button><Button icon={false} disabled={busy} onClick={()=>void toggleCaptain(selected)}><ShieldCheck/>{selected.isCaptain?tr("Remove captain","অধিনায়ক সরান"):tr("Make captain","অধিনায়ক করুন")}</Button></div>}</AdminRecordModal><Modal open={editor!==null} onClose={()=>setEditor(null)}><form className="modal-form" onSubmit={save}><span className="modal-icon"><CircleUserRound/></span><h2>{editor==="new"?tr("Add squad player","স্কোয়াডে খেলোয়াড় যোগ"):tr("Edit squad player","স্কোয়াড খেলোয়াড় সম্পাদনা")}</h2><p>{tr("Only real, active member accounts can be assigned to the squad.","শুধুমাত্র প্রকৃত সক্রিয় সদস্য অ্যাকাউন্ট স্কোয়াডে যুক্ত করা যাবে।")}</p>{editor==="new"?<label>{tr("Select active member","সক্রিয় সদস্য বাছুন")}<select name="memberDatabaseId" required>{availableToAdd.map(m=><option key={m.databaseId} value={m.databaseId}>{m.name} ({m.id})</option>)}</select></label>:<label>{tr("Player name","খেলোয়াড়ের নাম")}<input disabled value={editor?.name||""}/></label>}<div className="form-grid"><label>{tr("Jersey number","জার্সি নম্বর")}<input name="jersey" type="number" min="1" max="99" required defaultValue={editor!=="new"&&editor?editor.jersey:""}/></label><label>{tr("Position","পজিশন")}<select name="position" defaultValue={editor!=="new"&&editor?editor.position.toUpperCase():"FORWARD"}><option>GOALKEEPER</option><option>DEFENDER</option><option>MIDFIELDER</option><option>FORWARD</option></select></label></div><div className="modal-actions"><Button type="button" variant="outline" onClick={()=>setEditor(null)} icon={false}>{tr("Cancel","বাতিল")}</Button><Button type="submit" disabled={busy} icon={false}>{tr("Save player","সংরক্ষণ")}</Button></div></form></Modal></>;
}

type SquadPickRow={id:string;name:string;jersey:number;position:string;image:string};

function AdminField(){
  const {tr}=useI18n();
  type Spot={pos:string;memberId?:string;name?:string;jersey?:number;image?:string};
  const base=["GK","LB","LCB","RCB","RB","LCM","CM","RCM","LW","ST","RW"];
  const coords=[[50,88],[18,67],[39,71],[61,71],[82,67],[27,45],[50,50],[73,45],[21,20],[50,14],[79,20]];
  const [squad,setSquad]=useState<SquadPickRow[]>([]);
  const [spots,setSpots]=useState<Spot[]>(base.map(pos=>({pos})));
  const [teamName,setTeamName]=useState("Fantastic FC");
  const [matchTitle,setMatchTitle]=useState("");
  const [formation,setFormation]=useState("4-3-3");
  const [pick,setPick]=useState<number|null>(null);
  const [pickSearch,setPickSearch]=useState("");
  const [saved,setSaved]=useState(false);
  const [saving,setSaving]=useState(false);
  const [loading,setLoading]=useState(true);

  useEffect(()=>{void (async()=>{
    setLoading(true);
    try{
      const [squadRes,lineupRes]=await Promise.all([
        fetch("/api/admin/members",{cache:"no-store"}),
        fetch("/api/admin/lineup",{cache:"no-store"}),
      ]);
      const squadData=await squadRes.json() as {members?:Array<{databaseId?:string;name:string;jersey:number|null;position:string|null;image:string|null;status:string}>};
      const activeSquad=(squadData.members||[]).filter(m=>m.status==="ACTIVE"&&m.jersey).map(m=>({id:m.databaseId||"",name:m.name,jersey:m.jersey||0,position:m.position||"",image:m.image||""}));
      setSquad(activeSquad);

      const lineupData=await lineupRes.json() as {lineup?:{teamName:string;matchTitle:string;formation:string;players:Array<{slot:string;memberId?:string}>}|null};
      if(lineupData.lineup){
        setTeamName(lineupData.lineup.teamName);setMatchTitle(lineupData.lineup.matchTitle);setFormation(lineupData.lineup.formation);
        setSpots(base.map(pos=>{
          const savedSlot=lineupData.lineup!.players.find(p=>p.slot===pos);
          const member=savedSlot?.memberId?activeSquad.find(m=>m.id===savedSlot.memberId):undefined;
          return member?{pos,memberId:member.id,name:member.name,jersey:member.jersey,image:member.image}:{pos};
        }));
      } else {
        setMatchTitle(tr("Fantastic FC vs Green Warriors","ফ্যান্টাস্টিক এফসি বনাম গ্রিন ওয়ারিয়র্স"));
      }
    }catch{ /* best-effort */ }
    finally{setLoading(false)}
  })()},[tr]);

  function setPlayer(p:SquadPickRow){if(pick===null)return;setSpots(v=>v.map((s,i)=>i===pick?{pos:s.pos,memberId:p.id,name:p.name,jersey:p.jersey,image:p.image}:s));setPick(null);setPickSearch("")}
  async function saveLineup(){
    setSaving(true);setSaved(false);
    try{
      const res=await fetch("/api/admin/lineup",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({teamName,matchTitle,formation,players:spots.filter(s=>s.memberId).map(s=>({slot:s.pos,memberId:s.memberId}))})});
      if(res.ok)setSaved(true);
    }finally{setSaving(false)}
  }
  const assignedIds=new Set(spots.map(s=>s.memberId).filter(Boolean));
  const pickerOptions=squad.filter(p=>!assignedIds.has(p.id)&&`${p.name} ${p.position} ${p.jersey}`.toLowerCase().includes(pickSearch.toLowerCase()));

  return <><AdminTitle title="Field & Lineup" bn="ফিল্ড ও লাইনআপ" body="Build the public matchday XI from real active squad members. Only admins can edit these positions." bodyBn="প্রকৃত সক্রিয় স্কোয়াড সদস্য দিয়ে পাবলিক ম্যাচডে একাদশ তৈরি করুন। শুধু অ্যাডমিন এই পজিশন সম্পাদনা করতে পারবেন।" action={<Button onClick={()=>void saveLineup()} disabled={saving} icon={false}><Check/>{saving?tr("Saving...","সংরক্ষণ হচ্ছে..."):tr("Save lineup","লাইনআপ সংরক্ষণ")}</Button>}/>
  {saved&&<div className="portal-alert success"><CheckCircle2/>{tr("Starting lineup saved and published.","শুরুর একাদশ সংরক্ষণ ও প্রকাশিত হয়েছে।")}</div>}
  {!loading&&squad.length===0&&<div className="portal-alert" style={{marginBottom:"16px"}}><CircleUserRound/>{tr("No active squad players yet. Assign jersey numbers on the Players page first.","এখনো কোনো সক্রিয় স্কোয়াড খেলোয়াড় নেই। প্রথমে Players পেজে জার্সি নম্বর দিন।")}</div>}
  <div className="field-admin-grid">
    <Panel title={tr("Lineup settings","লাইনআপ সেটিংস")}>
      <div className="lineup-settings">
        <label>{tr("Team name","দলের নাম")}<input value={teamName} onChange={e=>setTeamName(e.target.value)}/></label>
        <label>{tr("Match title","ম্যাচের শিরোনাম")}<input value={matchTitle} onChange={e=>setMatchTitle(e.target.value)}/></label>
        <label>{tr("Formation","ফরমেশন")}<select value={formation} onChange={e=>setFormation(e.target.value)}><option>4-3-3</option><option>4-4-2</option><option>3-5-2</option><option>4-2-3-1</option></select></label>
        <div className="lineup-note"><ShieldCheck/><span><b>{tr("Public visibility","পাবলিক দৃশ্যমানতা")}</b>{tr("This active lineup appears on the home page.","এই সক্রিয় লাইনআপ হোম পেজে দেখা যাবে।")}</span></div>
        <Button variant="danger" icon={false} onClick={()=>{setSpots(base.map(pos=>({pos})));setSaved(false)}}><Trash2/>{tr("Clear lineup","লাইনআপ মুছুন")}</Button>
      </div>
    </Panel>
    <Panel className="admin-pitch-panel">
      <div className="pitch-top"><span>{tr("LINEUP EDITOR - CLICK + TO ADD","লাইনআপ এডিটর - যোগ করতে + চাপুন")}</span><b>{formation.split("-").join(" - ")}</b></div>
      <div className="football-pitch admin-edit">
        <div className="pitch-lines"><i className="half"/><i className="circle"/><i className="box top"/><i className="box bottom"/></div>
        {spots.map((s,i)=><div className={`pitch-player ${s.memberId?"filled":"empty"}`} style={{left:`${coords[i][0]}%`,top:`${coords[i][1]}%`}} key={s.pos}>
          {s.memberId?<><button className="pitch-avatar" onClick={()=>setPick(i)}><img src={s.image} alt={s.name}/><b>{s.jersey}</b></button><strong>{s.name}</strong><button className="remove-player" onClick={()=>setSpots(v=>v.map((x,j)=>j===i?{pos:x.pos}:x))}>x</button></>
          :<><button className="pitch-empty" onClick={()=>setPick(i)}>+</button><strong>{s.pos}</strong></>}
        </div>)}
      </div>
    </Panel>
  </div>
  <Modal open={pick!==null} onClose={()=>{setPick(null);setPickSearch("")}}>
    <div className="player-picker">
      <h2>{tr("Select active member","সক্রিয় সদস্য বাছুন")}</h2>
      <p>{tr("Choose a player for this field position.","এই ফিল্ড পজিশনের জন্য খেলোয়াড় বাছুন।")}</p>
      <div className="search-box"><Search/><input value={pickSearch} onChange={e=>setPickSearch(e.target.value)} placeholder={tr("Search active members...","সক্রিয় সদস্য খুঁজুন...")}/></div>
      <div>{pickerOptions.length===0?<p style={{padding:"12px 4px",color:"var(--muted)"}}>{tr("No available squad members match.","কোনো উপলব্ধ স্কোয়াড সদস্য পাওয়া যায়নি।")}</p>:pickerOptions.map(p=><button onClick={()=>setPlayer(p)} key={p.id}><Avatar src={p.image} name={p.name}/><span><b>{p.name}</b><small>#{p.jersey} - {p.position}</small></span><Plus/></button>)}</div>
    </div>
  </Modal>
</>}

type PaymentAdminRow={databaseId?:string;id:string;date:string;type:string;method:string;amount:number;status:string;transactionId:string;memberName:string;memberCode:string;memberImage:string;submittedAt:string;accountNumber:string;screenshotUrl?:string|null};

function PaymentsAdmin({verify=false}:{verify?:boolean}) {
  const {tr}=useI18n();
  const [rows,setRows]=useState<PaymentAdminRow[]>([]);
  const [loaded,setLoaded]=useState(false);
  const [search,setSearch]=useState("");
  const [method,setMethod]=useState("ALL");
  const [selected,setSelected]=useState<PaymentAdminRow|null>(null);
  useEffect(()=>{void (async()=>{try{const response=await fetch("/api/admin/payments",{cache:"no-store"});const data=await response.json() as {payments?:Array<{databaseId:string;transactionId:string|null;feeType:string;amount:string;screenshotUrl:string|null;status:string;submittedAt:string;memberName:string|null;memberCode:string|null;memberImage:string|null;method:string|null;accountNumber:string|null}>};if(response.ok&&data.payments){const databaseRows:PaymentAdminRow[]=data.payments.map((payment,index)=>({databaseId:payment.databaseId,id:`PAY-${payment.databaseId.slice(0,8).toUpperCase()}`,date:new Date(payment.submittedAt).toLocaleDateString(),type:payment.feeType,method:payment.method||"Unknown",amount:Number(payment.amount),status:payment.status,transactionId:payment.transactionId||"—",memberName:payment.memberName||"Unknown member",memberCode:payment.memberCode||"—",memberImage:payment.memberImage||playerImages[index%playerImages.length],submittedAt:new Date(payment.submittedAt).toLocaleString(),accountNumber:payment.accountNumber||"—",screenshotUrl:payment.screenshotUrl}));setRows(databaseRows)}}catch{/* leave rows empty on failure */}finally{setLoaded(true)}})()},[]);
  const now=new Date();const thisMonthCollected=rows.filter(r=>r.status==="PAID"&&new Date(r.submittedAt).getMonth()===now.getMonth()&&new Date(r.submittedAt).getFullYear()===now.getFullYear()).reduce((a,r)=>a+r.amount,0);
  const awaiting=rows.filter(r=>r.status==="PENDING").reduce((a,r)=>a+r.amount,0);
  const rejected=rows.filter(r=>r.status==="REJECTED").reduce((a,r)=>a+r.amount,0);
  async function update(id:string,status:string){const payment=rows.find(x=>x.id===id);setRows(v=>v.map(x=>x.id===id?{...x,status}:x));setSelected(v=>v?.id===id?{...v,status}:v);if(payment?.databaseId)await fetch("/api/admin/payments",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:payment.databaseId,status})})}
  const list=rows.filter(row=>(!verify||row.status==="PENDING")&&(method==="ALL"||row.method===method)&&`${row.id} ${row.transactionId} ${row.memberName} ${row.memberCode}`.toLowerCase().includes(search.trim().toLowerCase()));
  function exportRows(){const csv=["Payment ID,Transaction ID,Member,Member ID,Method,Amount,Status",...list.map(r=>[r.id,r.transactionId,r.memberName,r.memberCode,r.method,r.amount,r.status].join(","))].join("\n");const url=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));const link=document.createElement("a");link.href=url;link.download="fantastic-fc-payments.csv";link.click();URL.revokeObjectURL(url)}
  const fields:DetailField[]=selected?[
    {label:tr("Payment ID","পেমেন্ট আইডি"),value:selected.id},{label:tr("Transaction ID","ট্রানজ্যাকশন আইডি"),value:selected.transactionId},
    {label:tr("Member","সদস্য"),value:selected.memberName},{label:tr("Member ID","সদস্য আইডি"),value:selected.memberCode},
    {label:tr("Fee type","ফি ধরন"),value:selected.type},{label:tr("Amount","পরিমাণ"),value:`৳ ${selected.amount.toLocaleString()}`},
    {label:tr("Payment method","পেমেন্ট মাধ্যম"),value:selected.method},{label:tr("Sender account","প্রেরকের অ্যাকাউন্ট"),value:selected.accountNumber},
    {label:tr("Submitted","জমা হয়েছে"),value:selected.submittedAt},{label:tr("Verification status","যাচাই অবস্থা"),value:<StatusPill status={selected.status}/>},
  ]:[];
  return <><AdminTitle title={verify?"Payment Verification":"Payments"} bn={verify?"পেমেন্ট যাচাই":"পেমেন্ট"} body="Type a transaction ID, open the private proof and verify the payment." bodyBn="ট্রানজ্যাকশন আইডি লিখে খুঁজুন, ব্যক্তিগত প্রমাণ দেখুন এবং পেমেন্ট যাচাই করুন।" action={<Button variant="outline" icon={false} onClick={exportRows}><Download/>{tr("Export CSV","CSV এক্সপোর্ট")}</Button>}/><div className="admin-kpis compact"><StatCard icon={HandCoins} label={tr("Collected this month","এ মাসের সংগ্রহ")} value={loaded?`৳ ${thisMonthCollected.toLocaleString()}`:"…"}/><StatCard icon={Clock3} label={tr("Awaiting verification","যাচাইয়ের অপেক্ষায়")} value={loaded?`৳ ${awaiting.toLocaleString()}`:"…"} tone="orange"/><StatCard icon={XCircle} label={tr("Rejected","বাতিল")} value={loaded?`৳ ${rejected.toLocaleString()}`:"…"} tone="red"/></div><Panel><div className="transaction-search-help"><Search/><div><b>{tr("Transaction ID verification","ট্রানজ্যাকশন আইডি যাচাই")}</b><span>{tr("Enter the exact or partial transaction ID below.","নিচে সম্পূর্ণ বা আংশিক ট্রানজ্যাকশন আইডি লিখুন।")}</span></div></div><div className="table-toolbar"><div className="search-box"><Search/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder={tr("Transaction ID / Payment ID / Member...","ট্রানজ্যাকশন আইডি / পেমেন্ট আইডি / সদস্য...")}/></div><select value={method} onChange={e=>setMethod(e.target.value)}><option value="ALL">{tr("All payment methods","সব পেমেন্ট মাধ্যম")}</option><option>bKash</option><option>Nagad</option><option>Rocket</option><option>Visa</option></select></div><div className="table-scroll"><table className="data-table admin-table"><thead><tr><th>{tr("PAYMENT","পেমেন্ট")}</th><th>{tr("MEMBER","সদস্য")}</th><th>{tr("TRANSACTION ID","ট্রানজ্যাকশন আইডি")}</th><th>{tr("METHOD","মাধ্যম")}</th><th>{tr("AMOUNT","পরিমাণ")}</th><th>{tr("STATUS","অবস্থা")}</th><th>{tr("ACTIONS","অ্যাকশন")}</th></tr></thead><tbody>{list.map(p=><tr key={p.id}><td><b>{p.id}</b><small className="table-sub">{p.date}</small></td><td><div className="table-person"><Avatar src={p.memberImage} name={p.memberName}/><span><b>{p.memberName}</b><small>{p.memberCode}</small></span></div></td><td><b className="transaction-code">{p.transactionId}</b></td><td><div className="table-payment-method"><PaymentLogo name={p.method} compact/><span><b>{p.method}</b><small className="table-sub">{p.accountNumber}</small></span></div></td><td><b>৳ {p.amount.toLocaleString()}</b></td><td><StatusPill status={p.status}/></td><td><div className="row-actions">{p.status==="PENDING"&&<><button className="approve" title="Verify payment" onClick={()=>update(p.id,"PAID")}><Check/></button><button className="reject" title="Reject payment" onClick={()=>update(p.id,"REJECTED")}><X/></button></>}<button title="View payment and private proof" onClick={()=>setSelected(p)}><Eye/></button></div></td></tr>)}</tbody></table></div>{list.length===0&&<div className="empty-table"><Search/><b>{tr("No transaction found","কোনো লেনদেন পাওয়া যায়নি")}</b><p>{tr("Check the transaction ID and try again.","ট্রানজ্যাকশন আইডি যাচাই করে আবার চেষ্টা করুন।")}</p></div>}</Panel>
  <AdminRecordModal open={!!selected} onClose={()=>setSelected(null)} title={selected?.id||""} subtitle={tr("PRIVATE PAYMENT VERIFICATION","ব্যক্তিগত পেমেন্ট যাচাই")} icon={CreditCard} status={selected?.status} fields={fields}>{selected&&<><div className="private-proof">{selected.screenshotUrl?<div className="actual-payment-proof"><span>{tr("UPLOADED PRIVATE SCREENSHOT","আপলোড করা ব্যক্তিগত স্ক্রিনশট")}</span><img src={selected.screenshotUrl} alt="Private uploaded payment proof"/></div>:<div className="proof-phone"><span>{tr("UPLOADED PAYMENT SCREENSHOT","আপলোড করা পেমেন্ট স্ক্রিনশট")}</span><PaymentLogo name={selected.method}/><small>{selected.method} PAYMENT</small><strong>৳ {selected.amount.toLocaleString()}</strong><p>{tr("Transaction ID","ট্রানজ্যাকশন আইডি")}<b>{selected.transactionId}</b></p><p>{tr("Sender","প্রেরক")}<b>{selected.accountNumber}</b></p><em>SUCCESSFUL</em></div>}<div><ShieldCheck/><b>{tr("Private proof","ব্যক্তিগত প্রমাণ")}</b><p>{tr("Only administrators can view this uploaded payment proof. Match the transaction ID, amount and sender account before approval.","শুধু অ্যাডমিন এই আপলোড করা পেমেন্ট প্রমাণ দেখতে পারবেন। অনুমোদনের আগে ট্রানজ্যাকশন আইডি, পরিমাণ ও প্রেরকের অ্যাকাউন্ট মিলিয়ে নিন।")}</p></div></div>{selected.status==="PENDING"&&<div className="record-action-bar"><Button icon={false} onClick={()=>update(selected.id,"PAID")}><Check/>{tr("Verify payment","পেমেন্ট যাচাই করুন")}</Button><Button icon={false} variant="danger" onClick={()=>update(selected.id,"REJECTED")}><X/>{tr("Reject payment","পেমেন্ট বাতিল করুন")}</Button></div>}</>}</AdminRecordModal></>;
}

type ManagedMethod={id:string;name:string;accountNumber:string;accountName:string;instructions:string|null;warning:string|null;enabled:boolean;displayOrder:number};

function PaymentMethodsAdmin(){
  const {tr}=useI18n();
  const [methods,setMethods]=useState<ManagedMethod[]>([]);
  const [loaded,setLoaded]=useState(false);
  const [editor,setEditor]=useState<string|"new"|null>(null);
  const [saving,setSaving]=useState(false);

  function load(){fetch("/api/admin/payment-methods",{cache:"no-store"}).then(r=>r.json()).then((d:{methods?:ManagedMethod[]})=>setMethods(d.methods||[])).catch(()=>{}).finally(()=>setLoaded(true))}
  useEffect(()=>{load()},[]);

  async function save(event:FormEvent<HTMLFormElement>){
    event.preventDefault();setSaving(true);
    const data=new FormData(event.currentTarget);
    const values={name:String(data.get("name")),accountNumber:String(data.get("number")),accountName:String(data.get("account")),instructions:String(data.get("instructions")),warning:String(data.get("warning")),displayOrder:Number(data.get("order"))||1};
    try{
      if(editor==="new")await fetch("/api/admin/payment-methods",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({...values,enabled:true})});
      else if(editor)await fetch("/api/admin/payment-methods",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:editor,...values})});
      load();
    }finally{setSaving(false);setEditor(null)}
  }
  async function toggle(id:string,enabled:boolean){setMethods(v=>v.map(x=>x.id===id?{...x,enabled}:x));await fetch("/api/admin/payment-methods",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({id,enabled})})}
  async function remove(id:string){if(!window.confirm(tr("Remove this payment method?","এই পেমেন্ট মাধ্যম মুছবেন?")))return;await fetch(`/api/admin/payment-methods?id=${id}`,{method:"DELETE"});load()}

  const current=typeof editor==="string"&&editor!=="new"?methods.find(m=>m.id===editor):null;
  return <><AdminTitle title="Payment Methods" bn="পেমেন্ট মাধ্যম" body="Control every number, instruction and payment channel shown to members." bodyBn="সদস্যদের দেখানো প্রতিটি নম্বর, নির্দেশনা ও পেমেন্ট চ্যানেল নিয়ন্ত্রণ করুন।" action={<Button onClick={()=>setEditor("new")} icon={false}><Plus/>{tr("Add method","মাধ্যম যোগ")}</Button>}/>{!loaded?<p className="empty-inline">{tr("Loading...","লোড হচ্ছে...")}</p>:<div className="method-admin-grid">{[...methods].sort((a,b)=>(a.displayOrder||0)-(b.displayOrder||0)).map((m,i)=><Panel key={m.id}><div className="method-admin-head"><PaymentLogo name={m.name}/><div><h3>{m.name}</h3><StatusPill status={m.enabled?"ENABLED":"DISABLED"}/></div><button title="Edit all details" onClick={()=>setEditor(m.id)}><MoreHorizontal/></button></div><div className="method-admin-info"><p><span>{tr("Account number","অ্যাকাউন্ট নম্বর")}</span><b>{m.accountNumber}</b></p><p><span>{tr("Account name","অ্যাকাউন্ট নাম")}</span><b>{m.accountName}</b></p><p><span>{tr("Display order","প্রদর্শন ক্রম")}</span><b>{String(m.displayOrder||i+1).padStart(2,"0")}</b></p><p><span>{tr("Instructions","নির্দেশনা")}</span><b>{m.instructions}</b></p></div><div className="method-admin-actions"><button onClick={()=>setEditor(m.id)}><Pencil/>{tr("Edit details","তথ্য সম্পাদনা")}</button><label title={m.enabled?"Disable":"Enable"}><input type="checkbox" checked={m.enabled} onChange={()=>toggle(m.id,!m.enabled)}/><span/></label><button title={tr("Remove","মুছুন")} className="reject" onClick={()=>remove(m.id)}><Trash2/></button></div></Panel>)}</div>}<div className="admin-info-banner"><ShieldCheck/><div><b>{tr("Admin-controlled payment information","অ্যাডমিন নিয়ন্ত্রিত পেমেন্ট তথ্য")}</b><p>{tr("Only enabled methods are visible in the member payment flow. Number, instructions, warning and order can be edited here.","শুধু সক্রিয় মাধ্যম সদস্য পেমেন্টে দেখা যায়। নম্বর, নির্দেশনা, সতর্কতা ও ক্রম এখান থেকে সম্পাদনা করা যায়।")}</p></div></div><Modal open={editor!==null} onClose={()=>setEditor(null)}><form className="modal-form" onSubmit={save}><span className="modal-icon"><WalletCards/></span><h2>{editor==="new"?tr("Add payment method","পেমেন্ট মাধ্যম যোগ"):tr("Edit payment method","পেমেন্ট মাধ্যম সম্পাদনা")}</h2><label>{tr("Method name","মাধ্যমের নাম")}<input name="name" defaultValue={current?.name||""} required/></label><label>{tr("Account number","অ্যাকাউন্ট নম্বর")}<input name="number" defaultValue={current?.accountNumber||""} required/></label><label>{tr("Account name","অ্যাকাউন্টের নাম")}<input name="account" defaultValue={current?.accountName||""} required/></label><label>{tr("Instructions","নির্দেশনা")}<textarea name="instructions" rows={3} defaultValue={current?.instructions||""}/></label><label>{tr("Warning message","সতর্কবার্তা")}<textarea name="warning" rows={2} defaultValue={current?.warning||""}/></label><label>{tr("Display order","প্রদর্শন ক্রম")}<input name="order" type="number" min="1" defaultValue={current?.displayOrder||methods.length+1}/></label><div className="modal-actions"><Button variant="outline" type="button" onClick={()=>setEditor(null)} icon={false}>{tr("Cancel","বাতিল")}</Button><Button type="submit" disabled={saving} icon={false}>{saving?tr("Saving...","সংরক্ষণ হচ্ছে..."):tr("Save method","সংরক্ষণ")}</Button></div></form></Modal></>;
}

type ClubFee={id:number;name:string;bn:string;amount:number;audience:"all"|"players"|"new";frequency:"monthly"|"one-time"|"per-event";status:"ACTIVE"|"INACTIVE";note:string};

function FeeStructureAdmin(){
  const {tr,language}=useI18n();
  const [fees,setFees]=useState<ClubFee[]>([
    {id:1,name:"Monthly membership fee",bn:"মাসিক সদস্য ফি",amount:500,audience:"all",frequency:"monthly",status:"ACTIVE",note:"Charged to every active member each month."},
    {id:2,name:"Tournament participation fee",bn:"টুর্নামেন্ট অংশগ্রহণ ফি",amount:1000,audience:"players",frequency:"per-event",status:"ACTIVE",note:"Applies when a player registers for a tournament."},
    {id:3,name:"Jersey payment",bn:"জার্সি পেমেন্ট",amount:850,audience:"players",frequency:"one-time",status:"ACTIVE",note:"One-time cost for a printed matchday jersey."},
    {id:4,name:"New member admission fee",bn:"নতুন সদস্য ভর্তি ফি",amount:300,audience:"new",frequency:"one-time",status:"INACTIVE",note:"Optional onboarding fee for first-time members."},
  ]);
  const [editing,setEditing]=useState<number|"new"|null>(null);
  const activeFees=fees.filter(f=>f.status==="ACTIVE");
  const allMembersFees=activeFees.filter(f=>f.audience==="all");
  const current=typeof editing==="number"?fees.find(f=>f.id===editing):null;
  const audienceLabel=(a:ClubFee["audience"])=>a==="all"?tr("Everyone","সবার জন্য"):a==="players"?tr("Players only","শুধু খেলোয়াড়"):tr("New members","নতুন সদস্য");
  const frequencyLabel=(f:ClubFee["frequency"])=>f==="monthly"?tr("Monthly","মাসিক"):f==="one-time"?tr("One-time","একবার"):tr("Per event","প্রতি ইভেন্ট");
  function save(event:FormEvent<HTMLFormElement>){
    event.preventDefault();const data=new FormData(event.currentTarget);
    const values:Omit<ClubFee,"id">={
      name:String(data.get("name")),bn:String(data.get("bn"))||String(data.get("name")),
      amount:Number(data.get("amount"))||0,
      audience:String(data.get("audience")) as ClubFee["audience"],
      frequency:String(data.get("frequency")) as ClubFee["frequency"],
      status:data.get("status")==="ACTIVE"?"ACTIVE":"INACTIVE",
      note:String(data.get("note")),
    };
    if(editing==="new")setFees(v=>[...v,{id:Date.now(),...values}]);
    else if(typeof editing==="number")setFees(v=>v.map(f=>f.id===editing?{...f,...values}:f));
    setEditing(null);
  }
  return <><AdminTitle title="Fee Structure" bn="ফি নির্ধারণ" body="Set every fee members and players are charged — including fees that apply to everyone club-wide." bodyBn="সদস্য ও খেলোয়াড়দের জন্য প্রতিটি ফি নির্ধারণ করুন — যার মধ্যে সবার জন্য প্রযোজ্য ফিও রয়েছে।" action={<Button onClick={()=>setEditing("new")} icon={false}><Plus/>{tr("Add fee","ফি যোগ")}</Button>}/><div className="manager-summary"><Coins/><div><b>{activeFees.length}</b><span>{tr("active fees","সক্রিয় ফি")}</span></div><p>{tr("Fees marked \"Everyone\" apply club-wide to every member, not just players.","\"সবার জন্য\" চিহ্নিত ফি প্রতিটি সদস্যের জন্য প্রযোজ্য, শুধু খেলোয়াড় নয়।")}</p></div>{allMembersFees.length>0&&<div className="fee-everyone-banner"><Users/><div><b>{tr("Currently charged to every member","বর্তমানে সবার জন্য প্রযোজ্য")}</b><div className="fee-everyone-chips">{allMembersFees.map(f=><span key={f.id}>{language==="bn"?f.bn:f.name} — ৳ {f.amount.toLocaleString()}</span>)}</div></div></div>}<Panel><div className="content-manager-list fee-list">{fees.map(fee=><div key={fee.id}><span className="manager-icon"><Coins/></span><div><b>{language==="bn"?fee.bn:fee.name}</b><p>{fee.note}</p><small className="fee-meta-row"><span className={`fee-audience-tag ${fee.audience}`}>{audienceLabel(fee.audience)}</span><span>{frequencyLabel(fee.frequency)}</span></small></div><div className="fee-amount-col"><b>৳ {fee.amount.toLocaleString()}</b><StatusPill status={fee.status}/></div><div className="row-actions"><button title="Edit" onClick={()=>setEditing(fee.id)}><Pencil/></button><button title="Delete" className="reject" onClick={()=>{if(window.confirm(tr("Delete this fee?","এই ফি মুছবেন?")))setFees(v=>v.filter(f=>f.id!==fee.id))}}><Trash2/></button></div></div>)}</div></Panel><Modal open={editing!==null} onClose={()=>setEditing(null)}><form className="modal-form" onSubmit={save}><span className="modal-icon"><Coins/></span><h2>{editing==="new"?tr("Add new fee","নতুন ফি যোগ"):tr("Edit fee","ফি সম্পাদনা")}</h2><label>{tr("Fee name (English)","ফি নাম (ইংরেজি)")}<input name="name" required defaultValue={current?.name||""} placeholder="e.g. Monthly membership fee"/></label><label>{tr("Fee name (Bangla)","ফি নাম (বাংলা)")}<input name="bn" defaultValue={current?.bn||""} placeholder="যেমন মাসিক সদস্য ফি"/></label><div className="form-grid"><label>{tr("Amount (৳)","পরিমাণ (৳)")}<input name="amount" type="number" min="0" required defaultValue={current?.amount??500}/></label><label>{tr("Who pays this","কারা দিবে")}<select name="audience" defaultValue={current?.audience||"all"}><option value="all">{tr("Everyone (all members)","সবার জন্য (সব সদস্য)")}</option><option value="players">{tr("Players only","শুধু খেলোয়াড়")}</option><option value="new">{tr("New members only","শুধু নতুন সদস্য")}</option></select></label></div><div className="form-grid"><label>{tr("Frequency","কতবার")}<select name="frequency" defaultValue={current?.frequency||"monthly"}><option value="monthly">{tr("Monthly","মাসিক")}</option><option value="one-time">{tr("One-time","একবার")}</option><option value="per-event">{tr("Per event","প্রতি ইভেন্ট")}</option></select></label><label>{tr("Status","অবস্থা")}<select name="status" defaultValue={current?.status||"ACTIVE"}><option value="ACTIVE">ACTIVE</option><option value="INACTIVE">INACTIVE</option></select></label></div><label>{tr("Note / description","নোট / বিবরণ")}<textarea name="note" rows={2} defaultValue={current?.note||""}/></label><div className="modal-actions"><Button type="button" variant="outline" icon={false} onClick={()=>setEditing(null)}>{tr("Cancel","বাতিল")}</Button><Button type="submit" icon={false}>{tr("Save fee","ফি সংরক্ষণ")}</Button></div></form></Modal></>;
}

type FinanceEntryRow={id:string;title:string;category:string;income:string;expense:string;method:string|null;note:string|null;createdAt:string;memberId:string|null;memberName:string|null;memberPhoto:string|null;memberJersey:number|null};

function FinancialAdmin({expense=false,fund=false}:{expense?:boolean;fund?:boolean}) {
  const {tr}=useI18n();
  const title=expense?"Expenses":fund?"Club Fund":"Financial Overview";
  const bn=expense?"খরচ":fund?"ক্লাব ফান্ড":"আর্থিক সংক্ষিপ্ত চিত্র";
  const [entries,setEntries]=useState<FinanceEntryRow[]>([]);
  const [pendingDuesTotal,setPendingDuesTotal]=useState(0);
  const [loading,setLoading]=useState(true);
  const [adding,setAdding]=useState(false);
  const [saving,setSaving]=useState(false);
  const [squad,setSquad]=useState<SquadPickRow[]>([]);
  const [paying,setPaying]=useState(false);
  const [payPlayerId,setPayPlayerId]=useState<string>("");

  async function load(){setLoading(true);try{const res=await fetch("/api/admin/finance",{cache:"no-store"});const data=await res.json() as {entries?:FinanceEntryRow[];pendingDuesTotal?:number};if(res.ok){setEntries(data.entries||[]);setPendingDuesTotal(data.pendingDuesTotal||0)}}finally{setLoading(false)}}
  useEffect(()=>{void load()},[]);
  useEffect(()=>{void (async()=>{try{const res=await fetch("/api/admin/members",{cache:"no-store"});const data=await res.json() as {members?:Array<{databaseId?:string;name:string;jersey:number|null;position:string|null;image:string|null;status:string}>};setSquad((data.members||[]).filter(m=>m.status==="ACTIVE"&&m.jersey).map(m=>({id:m.databaseId||"",name:m.name,jersey:m.jersey||0,position:m.position||"",image:m.image||""})))}catch{ /* best-effort */ }})()},[]);
  useEffect(()=>{if(!payPlayerId&&squad[0])setPayPlayerId(squad[0].id)},[squad,payPlayerId]);

  const income=entries.reduce((sum,row)=>sum+Number(row.income),0);
  const totalExpense=entries.reduce((sum,row)=>sum+Number(row.expense),0);
  const playerPayments=entries.filter(e=>e.category==="PLAYER_PAYMENT");
  const totalPlayerPaid=playerPayments.reduce((sum,p)=>sum+Number(p.expense),0);
  const showPlayerPay=fund||expense;

  async function add(event:FormEvent<HTMLFormElement>){
    event.preventDefault();const data=new FormData(event.currentTarget);
    setSaving(true);
    try{
      const res=await fetch("/api/admin/finance",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({title:String(data.get("period")),income:Number(data.get("collection"))||0,expense:Number(data.get("expense"))||0,category:expense?"EXPENSE":"GENERAL"})});
      if(res.ok){await load();setAdding(false)}
    }finally{setSaving(false)}
  }
  async function payPlayer(event:FormEvent<HTMLFormElement>){
    event.preventDefault();const data=new FormData(event.currentTarget);
    const player=squad.find(p=>p.id===payPlayerId)||squad[0];
    const amount=Number(data.get("amount"))||0;const method=String(data.get("method"));const note=String(data.get("note"))||tr("Player payment","খেলোয়াড় পেমেন্ট");
    if(!player||amount<=0)return;
    setSaving(true);
    try{
      const res=await fetch("/api/admin/finance",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({title:`${tr("Player payment","খেলোয়াড় পেমেন্ট")} — ${player.name}`,expense:amount,category:"PLAYER_PAYMENT",memberId:player.id,method,note})});
      if(res.ok){await load();setPaying(false)}
    }finally{setSaving(false)}
  }
  async function removeEntry(id:string){
    if(!window.confirm(tr("Remove this entry?","এই এন্ট্রিটি সরাবেন?")))return;
    setSaving(true);
    try{const res=await fetch(`/api/admin/finance?id=${id}`,{method:"DELETE"});if(res.ok)await load()}
    finally{setSaving(false)}
  }

  return <>
    <AdminTitle title={title} bn={bn} body="Every entry here is a real, saved club record." bodyBn="এখানে প্রতিটি এন্ট্রি প্রকৃত, সংরক্ষিত ক্লাব রেকর্ড।" action={<div style={{display:"flex",gap:"8px"}}>{showPlayerPay&&<Button variant="outline" onClick={()=>setPaying(true)} icon={false}><HandCoins/>{tr("Pay a player","খেলোয়াড়কে টাকা দিন")}</Button>}<Button onClick={()=>setAdding(true)} icon={false}><Plus/>{tr(expense?"Add expense":"Add entry",expense?"খরচ যোগ":"এন্ট্রি যোগ")}</Button></div>}/>
    <div className="admin-kpis"><StatCard icon={HandCoins} label={tr("Verified income","যাচাইকৃত আয়")} value={`৳ ${income.toLocaleString()}`}/><StatCard icon={Receipt} label={tr("Verified expense","যাচাইকৃত খরচ")} value={`৳ ${totalExpense.toLocaleString()}`} tone="red"/><StatCard icon={Landmark} label={tr("Current balance","বর্তমান ব্যালেন্স")} value={`৳ ${(income-totalExpense).toLocaleString()}`} tone="blue"/><StatCard icon={CircleDollarSign} label={tr("Pending dues","অপেক্ষমান পাওনা")} value={`৳ ${pendingDuesTotal.toLocaleString()}`} tone="orange"/></div>
    <div className="finance-equation"><span><b>৳ {income.toLocaleString()}</b>{tr("VERIFIED INCOME","যাচাইকৃত আয়")}</span><em>−</em><span><b>৳ {totalExpense.toLocaleString()}</b>{tr("VERIFIED EXPENSE","যাচাইকৃত খরচ")}</span><em>=</em><span className="result"><b>৳ {(income-totalExpense).toLocaleString()}</b>{tr("CURRENT BALANCE","বর্তমান ব্যালেন্স")}</span></div>
    {showPlayerPay&&<Panel title={tr("Player payments","খেলোয়াড় পেমেন্ট")} action={<span className="player-pay-total">{tr("Total paid","মোট প্রদান")} <b>৳ {totalPlayerPaid.toLocaleString()}</b></span>}>
      {playerPayments.length===0?<div className="empty-table"><HandCoins/><b>{tr("No player payments yet","এখনো কোনো খেলোয়াড় পেমেন্ট নেই")}</b><p>{tr('Use "Pay a player" to send club funds to any squad member.','কোনো খেলোয়াড়কে ক্লাব ফান্ড থেকে টাকা দিতে "খেলোয়াড়কে টাকা দিন" ব্যবহার করুন।')}</p></div>
      :<div className="player-pay-list">{playerPayments.map(p=><div key={p.id} className="player-pay-row"><Avatar src={p.memberPhoto||""} name={p.memberName||""}/><div><b>{p.memberName}</b><small>#{p.memberJersey} • {p.note}</small></div><div className="player-pay-method"><PaymentLogo name={p.method||"Cash"} compact/><span>{p.method}</span></div><div className="player-pay-amount"><b>৳ {Number(p.expense).toLocaleString()}</b><small>{new Date(p.createdAt).toLocaleDateString()}</small></div><button title={tr("Remove","মুছুন")} className="reject" disabled={saving} onClick={()=>void removeEntry(p.id)}><Trash2/></button></div>)}</div>}
    </Panel>}
    <Panel title={tr("Financial statement","আর্থিক বিবরণী")}>
      {loading?<div className="empty-table"><RefreshCw className="spin"/><b>{tr("Loading records...","রেকর্ড লোড হচ্ছে...")}</b></div>
      :entries.length===0?<div className="empty-table"><ChartNoAxesCombined/><b>{tr("No financial records yet","এখনো কোনো আর্থিক রেকর্ড নেই")}</b></div>
      :<div className="table-scroll"><table className="data-table"><thead><tr><th>{tr("TITLE","শিরোনাম")}</th><th>{tr("COLLECTION","সংগ্রহ")}</th><th>{tr("EXPENSE","খরচ")}</th><th>{tr("DATE","তারিখ")}</th><th>{tr("STATUS","অবস্থা")}</th></tr></thead><tbody>{entries.map(r=><tr key={r.id}><td><b>{r.title}</b></td><td className="money-in">{Number(r.income)>0?`+ ৳ ${Number(r.income).toLocaleString()}`:"—"}</td><td className="money-out">{Number(r.expense)>0?`− ৳ ${Number(r.expense).toLocaleString()}`:"—"}</td><td>{new Date(r.createdAt).toLocaleDateString()}</td><td><StatusPill status="VERIFIED"/></td></tr>)}</tbody></table></div>}
    </Panel>
    <Modal open={adding} onClose={()=>setAdding(false)}><form className="modal-form" onSubmit={add}><span className="modal-icon"><ChartNoAxesCombined/></span><h2>{tr(expense?"Add verified expense":"Add financial entry",expense?"যাচাইকৃত খরচ যোগ":"আর্থিক এন্ট্রি যোগ")}</h2><label>{tr("Period / title","সময়সীমা / শিরোনাম")}<input name="period" required placeholder={expense?"Field rent — June 2025":"July 2025"}/></label><label>{tr("Verified collection","যাচাইকৃত সংগ্রহ")}<input name="collection" type="number" min="0" defaultValue={0}/></label><label>{tr("Verified expense","যাচাইকৃত খরচ")}<input name="expense" type="number" min="0" required={expense}/></label><div className="modal-actions"><Button type="button" variant="outline" icon={false} onClick={()=>setAdding(false)}>{tr("Cancel","বাতিল")}</Button><Button type="submit" disabled={saving} icon={false}>{saving?tr("Saving...","সংরক্ষণ হচ্ছে..."):tr("Save verified entry","যাচাইকৃত এন্ট্রি সংরক্ষণ")}</Button></div></form></Modal>
    <Modal open={paying} onClose={()=>setPaying(false)}><form className="modal-form player-pay-form" onSubmit={payPlayer}><span className="modal-icon"><HandCoins/></span><h2>{tr("Pay a player","খেলোয়াড়কে টাকা দিন")}</h2><p>{tr("Send money from the club fund directly to a squad member.","ক্লাব ফান্ড থেকে সরাসরি একজন খেলোয়াড়কে টাকা পাঠান।")}</p><label>{tr("Select player","খেলোয়াড় বাছুন")}<select name="playerId" value={payPlayerId} onChange={e=>setPayPlayerId(e.target.value)}>{squad.map(p=><option key={p.id} value={p.id}>#{p.jersey} — {p.name}</option>)}</select></label><div className="player-pay-preview">{(()=>{const player=squad.find(p=>p.id===payPlayerId);return player?<><Avatar src={player.image} name={player.name} size="lg"/><div><b>{player.name}</b><small>{player.position} • #{player.jersey}</small></div></>:null})()}</div><div className="form-grid"><label>{tr("Amount (৳)","পরিমাণ (৳)")}<input name="amount" type="number" min="1" required placeholder="1000"/></label><label>{tr("Payment method","পেমেন্ট মাধ্যম")}<select name="method" defaultValue="Cash">{initialMethods.map(m=><option key={m.id}>{m.name}</option>)}<option>Cash</option></select></label></div><label>{tr("Purpose / note","কারণ / নোট")}<input name="note" placeholder={tr("Match fee, transport allowance, tournament bonus...","ম্যাচ ফি, যাতায়াত ভাতা, টুর্নামেন্ট বোনাস...")}/></label><div className="modal-actions"><Button type="button" variant="outline" icon={false} onClick={()=>setPaying(false)}>{tr("Cancel","বাতিল")}</Button><Button type="submit" disabled={saving} icon={false}><HandCoins/>{saving?tr("Sending...","পাঠানো হচ্ছে..."):tr("Send payment","পেমেন্ট পাঠান")}</Button></div></form></Modal>
  </>;
}

type JerseyOrderRow={id:string;memberCode:string;memberName:string;size:string;jerseyNumber:number;printName:string;quantity:number;unitPrice:number;status:string;createdAt:string};
function JerseyAdmin(){
  const {tr}=useI18n();const {branding}=useBranding();
  const [rows,setRows]=useState<JerseyOrderRow[]>([]);const [loading,setLoading]=useState(true);const [editor,setEditor]=useState<number|"new"|null>(null);
  async function load(){setLoading(true);try{const res=await fetch("/api/jersey-order",{cache:"no-store"});const data=await res.json() as {orders?:JerseyOrderRow[]};if(data.orders)setRows(data.orders)}finally{setLoading(false)}}
  useEffect(()=>{void load()},[]);
  function save(event:FormEvent<HTMLFormElement>){event.preventDefault();const data=new FormData(event.currentTarget);const next:JerseyOrderRow={id:`JO-${Date.now().toString(36).toUpperCase()}`,memberCode:String(data.get("memberCode")),memberName:String(data.get("member")),size:String(data.get("size")),jerseyNumber:Number(data.get("jersey")),printName:String(data.get("printName")).toUpperCase(),quantity:Number(data.get("quantity"))||1,unitPrice:Number(data.get("price"))||850,status:String(data.get("status")),createdAt:new Date().toISOString()};if(editor==="new")setRows(v=>[next,...v]);else if(typeof editor==="number")setRows(v=>v.map((row,index)=>index===editor?{...row,...next}:row));setEditor(null)}
  async function updateStatus(index:number,status:string){const order=rows[index];setRows(v=>v.map((r,i)=>i===index?{...r,status}:r));if(order?.id)await fetch("/api/jersey-order",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:order.id,status})})}
  function downloadSheet(){const date=new Date().toLocaleDateString("en-GB",{day:"2-digit",month:"long",year:"numeric"});const total=rows.reduce((sum,r)=>sum+r.quantity*r.unitPrice,0);const html=`<!DOCTYPE html><html><head><meta charset="utf-8"><title>Jersey Order Sheet</title><style>*{box-sizing:border-box;margin:0}body{font-family:Arial,sans-serif;padding:40px;color:#1a2b22}header{display:flex;align-items:center;gap:20px;border-bottom:3px solid #0d3a28;padding-bottom:22px;margin-bottom:30px}header img{width:72px;height:82px}header div h1{font-size:28px;color:#0d3a28}header div p{font-size:10px;color:#5a7068;margin-top:5px}header div small{font-size:8px;color:#8a9d93;display:block;margin-top:4px}.info{display:flex;justify-content:space-between;margin-bottom:24px;font-size:10px;color:#5a7068}.info b{color:#1a2b22}table{width:100%;border-collapse:collapse;font-size:10px}th{height:38px;background:#0d3a28;color:#fff;text-align:left;padding:0 12px;font-size:8px;letter-spacing:.08em}td{height:42px;padding:8px 12px;border-bottom:1px solid #e0e6e1}tr:nth-child(even) td{background:#f6f9f7}.size{background:#eef5ef;padding:4px 8px;border-radius:4px;font-weight:900}.total-row{margin-top:24px;text-align:right;font-size:12px;padding:14px;background:#f0f5f1;border:1px solid #d0ddd3}.total-row b{font-size:18px}footer{margin-top:35px;padding-top:16px;border-top:2px solid #e0e6e1;display:flex;justify-content:space-between;font-size:8px;color:#8a9d93}footer b{color:#0d3a28}@media print{body{padding:20px}}</style></head><body><header><img src="/logo.svg" alt="Club Logo"/><div><h1>${branding.siteName}</h1><p>OFFICIAL JERSEY ORDER SHEET</p><small>${branding.tagline}</small></div></header><div class="info"><span>Date: <b>${date}</b></span><span>Total orders: <b>${rows.length}</b></span><span>Prepared by: <b>${branding.adminName}</b></span></div><table><thead><tr><th>#</th><th>MEMBER</th><th>MEMBER ID</th><th>SIZE</th><th>JERSEY #</th><th>PRINT NAME</th><th>QTY</th><th>UNIT PRICE</th><th>TOTAL</th><th>STATUS</th></tr></thead><tbody>${rows.map((r,i)=>`<tr><td>${i+1}</td><td><b>${r.memberName}</b></td><td>${r.memberCode}</td><td><span class="size">${r.size}</span></td><td>#${r.jerseyNumber}</td><td><b>${r.printName}</b></td><td>${r.quantity}</td><td>৳ ${r.unitPrice.toLocaleString()}</td><td><b>৳ ${(r.quantity*r.unitPrice).toLocaleString()}</b></td><td>${r.status}</td></tr>`).join("")}</tbody></table><div class="total-row">Grand Total: <b>৳ ${total.toLocaleString()}</b></div><footer><span>© ${new Date().getFullYear()} <b>${branding.siteName}</b></span><span>This is an official club document. <b>Confidential.</b></span></footer></body></html>`;const blob=new Blob([html],{type:"text/html"});const url=URL.createObjectURL(blob);const link=document.createElement("a");link.href=url;link.download=`jersey-order-sheet-${Date.now()}.html`;link.click();URL.revokeObjectURL(url)}
  const current=typeof editor==="number"?rows[editor]:null;
  return <><AdminTitle title="Jersey Orders" bn="জার্সি অর্ডার" body="View member jersey orders, manage status and download the official order sheet." bodyBn="সদস্যদের জার্সি অর্ডার দেখুন, অবস্থা পরিচালনা করুন এবং অফিসিয়াল অর্ডার শিট ডাউনলোড করুন।" action={<div style={{display:"flex",gap:"8px"}}><Button variant="outline" icon={false} onClick={downloadSheet}><Download/>{tr("Download sheet","শিট ডাউনলোড")}</Button><Button onClick={()=>void load()} variant="outline" icon={false}><RefreshCw/>{tr("Refresh","রিফ্রেশ")}</Button><Button onClick={()=>setEditor("new")} icon={false}><Plus/>{tr("Manual order","ম্যানুয়াল অর্ডার")}</Button></div>}/><div className="admin-info-banner"><ShieldCheck/><div><b>{tr("Member self-service jersey orders","সদস্য স্বয়ংক্রিয় জার্সি অর্ডার")}</b><p>{tr("Players select their size, print name and quantity from the Member Portal. Orders appear here automatically.","খেলোয়াড়েরা মেম্বার পোর্টাল থেকে সাইজ, প্রিন্ট নাম ও পরিমাণ বাছাই করেন। অর্ডার স্বয়ংক্রিয়ভাবে এখানে আসে।")}</p></div></div>{loading?<div className="empty-table"><RefreshCw className="spin"/><b>{tr("Loading orders...","অর্ডার লোড হচ্ছে...")}</b></div>:rows.length===0?<div className="empty-table"><Shirt/><b>{tr("No jersey orders yet","এখনো কোনো জার্সি অর্ডার নেই")}</b><p>{tr("When players submit orders from the portal, they will appear here.","খেলোয়াড়েরা পোর্টাল থেকে অর্ডার দিলে সেগুলো এখানে দেখা যাবে।")}</p></div>:<Panel><div className="table-scroll"><table className="data-table admin-table"><thead><tr><th>{tr("ORDER","অর্ডার")}</th><th>{tr("MEMBER","সদস্য")}</th><th>{tr("SIZE","সাইজ")}</th><th>{tr("JERSEY #","জার্সি #")}</th><th>{tr("PRINT NAME","প্রিন্ট নাম")}</th><th>{tr("QTY","পরিমাণ")}</th><th>{tr("TOTAL","মোট")}</th><th>{tr("STATUS","অবস্থা")}</th><th>{tr("ACTIONS","অ্যাকশন")}</th></tr></thead><tbody>{rows.map((r,index)=><tr key={r.id}><td><b>{r.id}</b><small className="table-sub">{new Date(r.createdAt).toLocaleDateString()}</small></td><td><b>{r.memberName}</b><small className="table-sub">{r.memberCode}</small></td><td><span className="size-badge">{r.size}</span></td><td>#{r.jerseyNumber}</td><td><b>{r.printName}</b></td><td>{r.quantity}</td><td><b>৳ {(r.quantity*r.unitPrice).toLocaleString()}</b></td><td><StatusPill status={r.status}/></td><td><div className="row-actions">{r.status==="PENDING"&&<button className="approve" title="Mark Paid" onClick={()=>void updateStatus(index,"PAID")}><Check/></button>}{r.status==="PAID"&&<button className="approve" title="Processing" onClick={()=>void updateStatus(index,"PROCESSING")}><RefreshCw/></button>}{r.status==="PROCESSING"&&<button className="approve" title="Delivered" onClick={()=>void updateStatus(index,"DELIVERED")}><CheckCircle2/></button>}<button title="Edit" onClick={()=>setEditor(index)}><Pencil/></button></div></td></tr>)}</tbody></table></div></Panel>}<Modal open={editor!==null} onClose={()=>setEditor(null)}><form className="modal-form" onSubmit={save}><span className="modal-icon"><Shirt/></span><h2>{editor==="new"?tr("Manual jersey order","ম্যানুয়াল জার্সি অর্ডার"):tr("Edit jersey order","জার্সি অর্ডার সম্পাদনা")}</h2><label>{tr("Member name","সদস্যের নাম")}<input name="member" defaultValue={current?.memberName||""} required/></label><label>{tr("Member ID","সদস্য আইডি")}<input name="memberCode" defaultValue={current?.memberCode||""} required/></label><div className="form-grid"><label>{tr("Size","সাইজ")}<select name="size" defaultValue={current?.size||"M"}>{["XS","S","M","L","XL","XXL","XXXL","Custom"].map(size=><option key={size}>{size}</option>)}</select></label><label>{tr("Jersey number","জার্সি নম্বর")}<input name="jersey" type="number" min="1" max="99" defaultValue={current?.jerseyNumber||""} required/></label><label>{tr("Print name","প্রিন্ট নাম")}<input name="printName" defaultValue={current?.printName||""} required/></label><label>{tr("Quantity","পরিমাণ")}<input name="quantity" type="number" min="1" defaultValue={current?.quantity||1}/></label><label>{tr("Unit price","একক মূল্য")}<input name="price" type="number" min="0" defaultValue={current?.unitPrice||850}/></label><label>{tr("Status","অবস্থা")}<select name="status" defaultValue={current?.status||"PENDING"}><option>PENDING</option><option>PAID</option><option>PROCESSING</option><option>DELIVERED</option></select></label></div><div className="modal-actions"><Button type="button" variant="outline" icon={false} onClick={()=>setEditor(null)}>{tr("Cancel","বাতিল")}</Button><Button type="submit" icon={false}>{tr("Save order","অর্ডার সংরক্ষণ")}</Button></div></form></Modal></>;
}

type ManagedMatch={id:string;opponentName:string;opponentLogoUrl:string|null;matchDatetime:string;competition:string|null;groupName:string|null;venue:string|null;matchType:string;homeAway:string;status:string;homeScore:number|null;awayScore:number|null};

function MatchManagement(){
  const {tr}=useI18n();
  const [matchesList,setMatchesList]=useState<ManagedMatch[]>([]);
  const [loaded,setLoaded]=useState(false);
  const [editor,setEditor]=useState<string|"new"|null>(null);
  const [saving,setSaving]=useState(false);
  const [saveMsg,setSaveMsg]=useState<{type:"success"|"error";text:string}|null>(null);
  const [logoDraft,setLogoDraft]=useState<string|null>(null);
  const [logoError,setLogoError]=useState<string|null>(null);
  const [selected,setSelected]=useState<ManagedMatch|null>(null);

  function load(){fetch("/api/admin/matches",{cache:"no-store"}).then(r=>r.json()).then((d:{matches?:ManagedMatch[]})=>setMatchesList(d.matches||[])).catch(()=>{}).finally(()=>setLoaded(true))}
  useEffect(()=>{load()},[]);

  function openEditor(id:string|"new"){setEditor(id);setLogoDraft(null);setLogoError(null);setSaveMsg(null)}
  function onLogoChange(event:ChangeEvent<HTMLInputElement>){
    const file=event.target.files?.[0];setLogoError(null);
    if(!file)return;
    if(!file.type.match(/^image\/(png|jpeg|webp)$/)||file.size>1_500_000){setLogoError(tr("Use a PNG, JPG or WebP logo under 1.5 MB.","১.৫ এমবির কম PNG, JPG বা WebP লোগো ব্যবহার করুন।"));event.target.value="";return}
    const reader=new FileReader();
    reader.onload=()=>setLogoDraft(String(reader.result||""));
    reader.readAsDataURL(file);
  }

  async function save(event:FormEvent<HTMLFormElement>){
    event.preventDefault();setSaving(true);setSaveMsg(null);
    const data=new FormData(event.currentTarget);
    const current=typeof editor==="string"&&editor!=="new"?matchesList.find(m=>m.id===editor):null;
    const payload:Record<string,unknown>={
      opponentName:String(data.get("opponentName")),
      matchDate:String(data.get("matchDate")),
      matchTime:String(data.get("matchTime")),
      competition:String(data.get("competition")||""),
      groupName:String(data.get("groupName")||""),
      venue:String(data.get("venue")||""),
      matchType:String(data.get("matchType")),
      homeAway:String(data.get("homeAway")),
      status:String(data.get("status")),
    };
    if(logoDraft!==null)payload.opponentLogoUrl=logoDraft;
    try{
      const res=editor==="new"
        ?await fetch("/api/admin/matches",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)})
        :await fetch("/api/admin/matches",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:editor,...payload})});
      const result=await res.json() as {message:string};
      if(res.ok){setSaveMsg({type:"success",text:tr("Match saved successfully.","ম্যাচ সফলভাবে সংরক্ষিত হয়েছে।")});load();setTimeout(()=>{setEditor(null)},900)}
      else setSaveMsg({type:"error",text:result.message});
    }catch{setSaveMsg({type:"error",text:tr("Unable to save match.","ম্যাচ সংরক্ষণ করা যায়নি।")})}
    finally{setSaving(false)}
    void current;
  }
  async function remove(id:string){if(!window.confirm(tr("Delete this match?","এই ম্যাচটি মুছবেন?")))return;await fetch(`/api/admin/matches?id=${id}`,{method:"DELETE"});load()}

  const current=typeof editor==="string"&&editor!=="new"?matchesList.find(m=>m.id===editor):null;
  const currentLogo=logoDraft!==null?logoDraft:current?.opponentLogoUrl||null;
  const dt=current?new Date(current.matchDatetime):null;
  const defaultDate=dt?dt.toISOString().slice(0,10):"";
  const defaultTime=dt?`${String(dt.getHours()).padStart(2,"0")}:${String(dt.getMinutes()).padStart(2,"0")}`:"";

  return <><AdminTitle title="Matches" bn="ম্যাচ" body="Schedule matches and manage the opponent club shown on the homepage." bodyBn="ম্যাচ সময়সূচি করুন এবং হোমপেজে দেখানো প্রতিপক্ষ ক্লাব পরিচালনা করুন।" action={<Button onClick={()=>openEditor("new")} icon={false}><Plus/>{tr("Create match","ম্যাচ তৈরি")}</Button>}/>
    {!loaded?<p className="empty-inline">{tr("Loading...","লোড হচ্ছে...")}</p>:matchesList.length===0?<div className="empty-table"><Swords/><b>{tr("No matches scheduled yet","এখনো কোনো ম্যাচ নেই")}</b><p>{tr('Use "Create match" to schedule your first fixture.','প্রথম ম্যাচ যোগ করতে "ম্যাচ তৈরি" ব্যবহার করুন।')}</p></div>:
    <Panel><div className="content-manager-list match-admin-list">{matchesList.map(m=>{const d=new Date(m.matchDatetime);return <div key={m.id}>
      <span className="opponent-logo-box"><span className="manager-thumb-logo">{m.opponentLogoUrl?<img src={m.opponentLogoUrl} alt={m.opponentName}/>:<span className="opponent-mark small">{m.opponentName.slice(0,2).toUpperCase()}</span>}</span></span>
      <div><b>{m.homeAway==="AWAY"?`${m.opponentName} vs Fantastic FC`:`Fantastic FC vs ${m.opponentName}`}</b><p>{d.toLocaleDateString()} • {d.toLocaleTimeString("en-US",{hour:"numeric",minute:"2-digit",hour12:true})}{m.venue?` • ${m.venue}`:""}</p><small>{[m.competition,m.groupName].filter(Boolean).join(" • ")||tr("No competition set","প্রতিযোগিতা নির্ধারিত নয়")}</small></div>
      <StatusPill status={m.status}/>
      <div className="row-actions"><button title={tr("View","দেখুন")} onClick={()=>setSelected(m)}><Eye/></button><button title={tr("Edit","সম্পাদনা")} onClick={()=>openEditor(m.id)}><Pencil/></button><button title={tr("Delete","মুছুন")} className="reject" onClick={()=>remove(m.id)}><Trash2/></button></div>
    </div>})}</div></Panel>}

    <AdminRecordModal open={!!selected} onClose={()=>setSelected(null)} title={selected?`${selected.homeAway==="AWAY"?selected.opponentName+" vs Fantastic FC":"Fantastic FC vs "+selected.opponentName}`:""} subtitle={tr("MATCH DETAILS","ম্যাচের বিবরণ")} icon={Swords} status={selected?.status} fields={selected?[
      {label:tr("Opponent club","প্রতিপক্ষ ক্লাব"),value:selected.opponentName},
      {label:tr("Date & time","তারিখ ও সময়"),value:new Date(selected.matchDatetime).toLocaleString()},
      {label:tr("Venue","ভেন্যু"),value:selected.venue||"—"},
      {label:tr("Competition","প্রতিযোগিতা"),value:[selected.competition,selected.groupName].filter(Boolean).join(" • ")||"—"},
      {label:tr("Match type","ম্যাচের ধরন"),value:selected.matchType},
      {label:tr("Home / Away","হোম / অ্যাওয়ে"),value:selected.homeAway},
    ]:[]}>{selected&&<div className="record-preview-image match-logo-preview">{selected.opponentLogoUrl?<img src={selected.opponentLogoUrl} alt={selected.opponentName}/>:<div className="record-empty-preview"><Swords/><p>{tr("No opponent logo uploaded.","কোনো প্রতিপক্ষ লোগো আপলোড হয়নি।")}</p></div>}</div>}</AdminRecordModal>

    <Modal open={editor!==null} onClose={()=>setEditor(null)}>
      <form className="modal-form match-form" onSubmit={save}>
        <span className="modal-icon"><Swords/></span>
        <h2>{editor==="new"?tr("Create match","ম্যাচ তৈরি"):tr("Edit match","ম্যাচ সম্পাদনা")}</h2>
        <p className="match-form-section-label">{tr("MATCH INFORMATION","ম্যাচের তথ্য")}</p>
        <label>{tr("Opponent Club","প্রতিপক্ষ ক্লাব")}<input name="opponentName" required defaultValue={current?.opponentName||""} placeholder={tr("Enter club name","ক্লাবের নাম লিখুন")}/></label>
        <label className="upload-box match-logo-upload">
          {currentLogo?<img className="match-logo-preview-thumb" src={currentLogo} alt="Opponent logo preview"/>:<ImagePlus/>}
          <b>{currentLogo?tr("Change Logo","লোগো পরিবর্তন"):tr("+ Upload Club Logo","+ ক্লাব লোগো আপলোড")}</b>
          <span>{tr("PNG, JPG or WebP • max 1.5 MB","PNG, JPG বা WebP • সর্বোচ্চ ১.৫ এমবি")}</span>
          <input type="file" accept="image/png,image/jpeg,image/webp" onChange={onLogoChange}/>
          {currentLogo&&<button type="button" className="match-logo-remove" onClick={(e)=>{e.preventDefault();e.stopPropagation();setLogoDraft("")}}>{tr("Remove","মুছুন")}</button>}
        </label>
        {logoError&&<p className="upload-error">{logoError}</p>}
        <div className="form-grid">
          <label>{tr("Match Date","ম্যাচের তারিখ")}<input name="matchDate" type="date" required defaultValue={defaultDate}/></label>
          <label>{tr("Match Time","ম্যাচের সময়")}<input name="matchTime" type="time" required defaultValue={defaultTime}/></label>
        </div>
        <div className="form-grid">
          <label>{tr("Competition","প্রতিযোগিতা")}<input name="competition" defaultValue={current?.competition||""} placeholder="KPL"/></label>
          <label>{tr("Group","গ্রুপ")}<input name="groupName" defaultValue={current?.groupName||""} placeholder="Group A"/></label>
        </div>
        <label>{tr("Venue","ভেন্যু")}<input name="venue" defaultValue={current?.venue||""} placeholder={tr("Kulanandapur School Field","কুলানন্দপুর স্কুল মাঠ")}/></label>
        <div className="form-grid">
          <label>{tr("Match Type","ম্যাচের ধরন")}<select name="matchType" defaultValue={current?.matchType||"LEAGUE"}><option value="LEAGUE">{tr("League","লিগ")}</option><option value="FRIENDLY">{tr("Friendly","প্রীতি")}</option><option value="TOURNAMENT">{tr("Tournament","টুর্নামেন্ট")}</option><option value="CUP">{tr("Cup","কাপ")}</option></select></label>
          <label>{tr("Home / Away","হোম / অ্যাওয়ে")}<select name="homeAway" defaultValue={current?.homeAway||"HOME"}><option value="HOME">{tr("Home","হোম")}</option><option value="AWAY">{tr("Away","অ্যাওয়ে")}</option></select></label>
        </div>
        <label>{tr("Match Status","ম্যাচের অবস্থা")}<select name="status" defaultValue={current?.status||"UPCOMING"}><option value="UPCOMING">{tr("Upcoming","আসন্ন")}</option><option value="COMPLETED">{tr("Completed","সম্পন্ন")}</option><option value="POSTPONED">{tr("Postponed","স্থগিত")}</option><option value="CANCELLED">{tr("Cancelled","বাতিল")}</option></select></label>
        {saveMsg&&<FormMessage state={saveMsg}/>}
        <div className="modal-actions"><Button type="button" variant="outline" icon={false} onClick={()=>setEditor(null)}>{tr("Cancel","বাতিল")}</Button><Button type="submit" disabled={saving} icon={false}>{saving?tr("Saving...","সংরক্ষণ হচ্ছে..."):tr("Save Match","ম্যাচ সংরক্ষণ")}</Button></div>
      </form>
    </Modal>
  </>;
}

type PinResetRecord={id:string;memberId:string;memberCode:string;requesterName:string;email:string;mobile:string;status:string;emailStatus:string;emailProviderId:string|null;requestedAt:string;resolvedAt:string|null};

function PinResetAdmin(){
  const {tr}=useI18n();
  const [rows,setRows]=useState<PinResetRecord[]>([]);const [loading,setLoading]=useState(true);const [search,setSearch]=useState("");const [filter,setFilter]=useState("ALL");const [selected,setSelected]=useState<PinResetRecord|null>(null);const [busy,setBusy]=useState(false);const [result,setResult]=useState<{message:string;generatedPin?:string;emailStatus?:string}|null>(null);
  async function load(){setLoading(true);try{const response=await fetch("/api/admin/pin-resets",{cache:"no-store"});const data=await response.json() as {requests?:PinResetRecord[]};setRows(data.requests||[])}finally{setLoading(false)}}
  useEffect(()=>{void load()},[]);
  async function act(id:string,action:"approve"|"reject"){setBusy(true);setResult(null);try{const response=await fetch("/api/admin/pin-resets",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({id,action})});const data=await response.json() as {message:string;status?:string;emailStatus?:string;generatedPin?:string};setResult(data);if(response.ok){setRows(v=>v.map(x=>x.id===id?{...x,status:data.status||x.status,emailStatus:data.emailStatus||x.emailStatus,resolvedAt:new Date().toISOString()}:x));setSelected(v=>v?.id===id?{...v,status:data.status||v.status,emailStatus:data.emailStatus||v.emailStatus,resolvedAt:new Date().toISOString()}:v)}}catch{setResult({message:tr("Unable to complete this action.","কাজটি সম্পন্ন করা যায়নি।")})}finally{setBusy(false)}}
  const list=rows.filter(row=>(filter==="ALL"||row.status===filter)&&`${row.requesterName} ${row.memberCode} ${row.mobile} ${row.email}`.toLowerCase().includes(search.toLowerCase()));
  const fields:DetailField[]=selected?[{label:tr("Member name","সদস্যের নাম"),value:selected.requesterName},{label:tr("Member ID","সদস্য আইডি"),value:selected.memberCode},{label:tr("Registered email","নিবন্ধিত ইমেইল"),value:selected.email},{label:tr("Registered mobile","নিবন্ধিত মোবাইল"),value:selected.mobile},{label:tr("Requested at","অনুরোধের সময়"),value:new Date(selected.requestedAt).toLocaleString()},{label:tr("Request status","অনুরোধ অবস্থা"),value:<StatusPill status={selected.status}/>},{label:tr("Email delivery","ইমেইল ডেলিভারি"),value:<StatusPill status={selected.emailStatus}/>},{label:tr("Email message ID","ইমেইল মেসেজ আইডি"),value:selected.emailProviderId||tr("Not available","পাওয়া যায়নি"),wide:true}]:[];
  return <><AdminTitle title="PIN Reset History" bn="পিন রিসেট ইতিহাস" body="Member PIN resets are now automatic — a new PIN is generated and emailed the moment a member requests one. This is the history log for your awareness." bodyBn="সদস্যদের পিন রিসেট এখন স্বয়ংক্রিয় — কেউ অনুরোধ করার সাথে সাথেই নতুন পিন তৈরি হয়ে ইমেইল হয়ে যায়। এটি আপনার জানার জন্য ইতিহাস তালিকা।" action={<Button variant="outline" icon={false} onClick={()=>void load()}><RefreshCw/>{tr("Refresh","রিফ্রেশ")}</Button>}/><div className="admin-kpis compact"><StatCard icon={Clock3} label={tr("Pending requests","অপেক্ষমাণ অনুরোধ")} value={String(rows.filter(r=>r.status==="PENDING").length)} tone="orange"/><StatCard icon={CheckCircle2} label={tr("Approved resets","অনুমোদিত রিসেট")} value={String(rows.filter(r=>r.status==="APPROVED").length)}/><StatCard icon={Mail} label={tr("Emails sent","পাঠানো ইমেইল")} value={String(rows.filter(r=>r.emailStatus==="SENT").length)} tone="blue"/></div><Panel><div className="admin-info-banner"><ShieldCheck/><div><b>{tr("Secure PIN delivery","নিরাপদ পিন ডেলিভারি")}</b><p>{tr("Approval generates a random six-digit PIN, stores only its scrypt hash and emails the PIN from ADMIN_EMAIL_FROM through Resend.","অনুমোদনে একটি এলোমেলো ছয় সংখ্যার পিন তৈরি হয়, শুধু scrypt hash সংরক্ষিত হয় এবং Resend-এর মাধ্যমে ADMIN_EMAIL_FROM থেকে ইমেইল যায়।")}</p></div></div><div className="table-toolbar"><div className="search-box"><Search/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder={tr("Name / Member ID / Mobile / Email...","নাম / সদস্য আইডি / মোবাইল / ইমেইল...")}/></div><select value={filter} onChange={e=>setFilter(e.target.value)}><option value="ALL">{tr("All requests","সব অনুরোধ")}</option><option>PENDING</option><option>APPROVED</option><option>REJECTED</option></select></div>{loading?<div className="empty-table"><RefreshCw className="spin"/><b>{tr("Loading requests...","অনুরোধ লোড হচ্ছে...")}</b></div>:<div className="table-scroll"><table className="data-table admin-table"><thead><tr><th>{tr("MEMBER","সদস্য")}</th><th>{tr("MEMBER ID","সদস্য আইডি")}</th><th>{tr("CONTACT","যোগাযোগ")}</th><th>{tr("REQUESTED","অনুরোধ")}</th><th>{tr("STATUS","অবস্থা")}</th><th>{tr("EMAIL","ইমেইল")}</th><th>{tr("ACTIONS","অ্যাকশন")}</th></tr></thead><tbody>{list.map(row=><tr key={row.id}><td><b>{row.requesterName}</b><small className="table-sub">{row.email}</small></td><td><b>{row.memberCode}</b></td><td>{row.mobile}</td><td>{new Date(row.requestedAt).toLocaleDateString()}</td><td><StatusPill status={row.status}/></td><td><StatusPill status={row.emailStatus}/></td><td><div className="row-actions">{row.status==="PENDING"&&<><button className="approve" title="Generate PIN and email" onClick={()=>{setSelected(row);void act(row.id,"approve")}}><Send/></button><button className="reject" title="Reject request" onClick={()=>void act(row.id,"reject")}><X/></button></>}<button title="View complete request" onClick={()=>{setSelected(row);setResult(null)}}><Eye/></button></div></td></tr>)}</tbody></table></div>}{!loading&&list.length===0&&<div className="empty-table"><KeyRound/><b>{tr("No PIN reset requests found","কোনো পিন রিসেট অনুরোধ পাওয়া যায়নি")}</b><p>{tr("New member requests will appear here automatically.","নতুন সদস্য অনুরোধ স্বয়ংক্রিয়ভাবে এখানে দেখা যাবে।")}</p></div>}</Panel><AdminRecordModal open={!!selected} onClose={()=>{setSelected(null);setResult(null)}} title={selected?.requesterName||""} subtitle={tr("SECURE PIN RESET REQUEST","নিরাপদ পিন রিসেট অনুরোধ")} icon={KeyRound} status={selected?.status} fields={fields} notice={result?.message}>{result?.generatedPin&&<OneTimePin pin={result.generatedPin}/>} {selected?.status==="PENDING"&&<div className="record-action-bar"><Button disabled={busy} icon={false} onClick={()=>void act(selected.id,"approve")}><Send/>{busy?tr("Generating...","তৈরি হচ্ছে..."):tr("Generate PIN & email","পিন তৈরি ও ইমেইল")}</Button><Button disabled={busy} icon={false} variant="danger" onClick={()=>void act(selected.id,"reject")}><X/>{tr("Reject request","অনুরোধ বাতিল")}</Button></div>}</AdminRecordModal></>;
}

type TournamentAppRow={id:string;teamName:string;clubName:string;managerName:string;mobile:string;email:string;playerCount:number;category:string;address:string;status:string;createdAt:string};
type AuditRow={id:string;actor:string;action:string;entityType:string;entityId:string|null;details:Record<string,unknown>;createdAt:string};

function OpsPage({type}:{type:"pin"|"tournament"|"notifications"|"audit"}) {
  const {tr}=useI18n();
  const [selected,setSelected]=useState<{title:string;subtitle:string;status:string;fields:DetailField[];id:string}|null>(null);
  const [auditLogsData,setAuditLogsData]=useState<AuditRow[]>([]);
  const [auditLoading,setAuditLoading]=useState(true);
  const [apps,setApps]=useState<TournamentAppRow[]>([]);
  const [appsLoading,setAppsLoading]=useState(true);
  const [busy,setBusy]=useState(false);
  const {notices:liveNotices,loaded:noticesLoaded}=useAdminOverview(tr);

  useEffect(()=>{if(type!=="audit")return;(async()=>{setAuditLoading(true);try{const res=await fetch("/api/admin/audit",{cache:"no-store"});const data=await res.json() as {logs?:AuditRow[]};setAuditLogsData(data.logs||[])}catch{ /* best-effort */ }finally{setAuditLoading(false)}})()},[type]);
  useEffect(()=>{if(type!=="tournament")return;(async()=>{setAppsLoading(true);try{const res=await fetch("/api/admin/tournament-applications",{cache:"no-store"});const data=await res.json() as {applications?:TournamentAppRow[]};setApps(data.applications||[])}catch{ /* best-effort */ }finally{setAppsLoading(false)}})()},[type]);

  function exportAudit(){const url=URL.createObjectURL(new Blob([JSON.stringify(auditLogsData,null,2)],{type:"application/json"}));const link=document.createElement("a");link.href=url;link.download="fantastic-fc-audit-log.json";link.click();URL.revokeObjectURL(url)}
  async function actOnApplication(id:string,status:"APPROVED"|"REJECTED"){setBusy(true);try{const res=await fetch("/api/admin/tournament-applications",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({id,status})});if(res.ok){setApps(v=>v.map(a=>a.id===id?{...a,status}:a));setSelected(v=>v&&v.id===id?{...v,status}:v)}}catch{ /* best-effort */ }finally{setBusy(false)}}

  if(type==="audit"){
    const openAudit=(a:AuditRow)=>setSelected({title:a.action,subtitle:tr("AUDIT EVENT DETAILS","অডিট ইভেন্টের বিস্তারিত"),status:"VERIFIED",id:a.id,fields:[{label:tr("Performed by","সম্পাদনাকারী"),value:a.actor},{label:tr("Action","কাজ"),value:a.action},{label:tr("Target record","টার্গেট রেকর্ড"),value:a.entityType+(a.entityId?` • ${a.entityId}`:"")},{label:tr("Event time","ইভেন্ট সময়"),value:new Date(a.createdAt).toLocaleString()},{label:tr("Security state","নিরাপত্তা অবস্থা"),value:tr("Recorded and immutable","সংরক্ষিত ও অপরিবর্তনীয়"),wide:true}]});
    return <><AdminTitle title="Audit Log" bn="অডিট লগ" body="Open any event to see its complete immutable activity record." bodyBn="যেকোনো ইভেন্ট খুলে সম্পূর্ণ অপরিবর্তনীয় কার্যক্রমের তথ্য দেখুন।" action={<Button variant="outline" icon={false} onClick={exportAudit}><Download/>{tr("Export log","লগ এক্সপোর্ট")}</Button>}/><Panel>{auditLoading?<div className="empty-table"><RefreshCw className="spin"/><b>{tr("Loading audit log...","অডিট লগ লোড হচ্ছে...")}</b></div>:auditLogsData.length===0?<div className="empty-table"><History/><b>{tr("No activity recorded yet","এখনো কোনো কার্যক্রম রেকর্ড হয়নি")}</b><p>{tr("Admin actions will appear here automatically.","অ্যাডমিন কার্যক্রম স্বয়ংক্রিয়ভাবে এখানে দেখা যাবে।")}</p></div>:<div className="activity-log">{auditLogsData.map(a=><div key={a.id}><span className="blue"><History/></span><div><b>{a.action}</b><p>{a.entityType}</p><small>{a.actor} • {new Date(a.createdAt).toLocaleString()}</small></div><button title="View full audit event" onClick={()=>openAudit(a)}><Eye/></button></div>)}</div>}</Panel><AdminRecordModal open={!!selected} onClose={()=>setSelected(null)} title={selected?.title||""} subtitle={selected?.subtitle} icon={History} status={selected?.status} fields={selected?.fields||[]}/></>;
  }

  if(type==="tournament"){
    function openApp(a:TournamentAppRow){setSelected({title:a.teamName,subtitle:tr("TOURNAMENT APPLICATION","টুর্নামেন্ট আবেদন"),status:a.status,id:a.id,fields:[{label:tr("Team / Club","দল / ক্লাব"),value:`${a.teamName} (${a.clubName})`},{label:tr("Manager","ম্যানেজার"),value:a.managerName},{label:tr("Mobile","মোবাইল"),value:a.mobile},{label:tr("Email","ইমেইল"),value:a.email},{label:tr("Player count","খেলোয়াড় সংখ্যা"),value:String(a.playerCount)},{label:tr("Category","বিভাগ"),value:a.category},{label:tr("Address","ঠিকানা"),value:a.address,wide:true}]})}
    return <><AdminTitle title="Tournament Applications" bn="টুর্নামেন্ট আবেদন" body="Review team applications and approve or reject — the applicant is emailed automatically." bodyBn="দলের আবেদন পর্যালোচনা করে অনুমোদন বা বাতিল করুন — আবেদনকারীকে স্বয়ংক্রিয়ভাবে ইমেইল করা হবে।"/><Panel>{appsLoading?<div className="empty-table"><RefreshCw className="spin"/><b>{tr("Loading applications...","আবেদন লোড হচ্ছে...")}</b></div>:apps.length===0?<div className="empty-table"><Trophy/><b>{tr("No tournament applications yet","এখনো কোনো টুর্নামেন্ট আবেদন নেই")}</b><p>{tr("New applications from the public site will appear here.","পাবলিক সাইট থেকে নতুন আবেদন এখানে দেখা যাবে।")}</p></div>:<div className="ops-list">{apps.map((a,i)=><div key={a.id}><span className={`ops-icon o${i%4}`}><Trophy/></span><div><b>{a.teamName}</b><p>{tr("Manager","ম্যানেজার")}: {a.managerName} • {a.playerCount} {tr("players","খেলোয়াড়")}</p></div><StatusPill status={a.status}/><div className="row-actions">{a.status==="PENDING"&&<button className="approve" title="Approve" disabled={busy} onClick={()=>void actOnApplication(a.id,"APPROVED")}><Check/></button>}<button title="View complete details" onClick={()=>openApp(a)}><Eye/></button>{a.status==="PENDING"&&<button className="reject" title="Reject" disabled={busy} onClick={()=>void actOnApplication(a.id,"REJECTED")}><X/></button>}</div></div>)}</div>}</Panel><AdminRecordModal open={!!selected} onClose={()=>setSelected(null)} title={selected?.title||""} subtitle={selected?.subtitle} icon={Trophy} status={selected?.status} fields={selected?.fields||[]}>{selected?.status==="PENDING"&&<div className="record-action-bar"><Button disabled={busy} icon={false} onClick={()=>void actOnApplication(selected.id,"APPROVED")}><Check/>{tr("Approve application","আবেদন অনুমোদন")}</Button><Button disabled={busy} icon={false} variant="danger" onClick={()=>void actOnApplication(selected.id,"REJECTED")}><X/>{tr("Reject application","আবেদন বাতিল")}</Button></div>}</AdminRecordModal></>;
  }

  // type === "notifications": live feed built from real pending members/payments/tournament apps.
  function openNotice(n:AdminOverviewNotice,i:number){setSelected({title:n.title,subtitle:tr("ADMIN NOTIFICATION","অ্যাডমিন নোটিফিকেশন"),status:"UNREAD",id:String(i),fields:[{label:tr("Notification","নোটিফিকেশন"),value:n.title},{label:tr("Related record","সংশ্লিষ্ট রেকর্ড"),value:n.subtitle},{label:tr("Destination","গন্তব্য"),value:n.href}]})}
  return <><AdminTitle title="Admin Notifications" bn="অ্যাডমিন নোটিফিকেশন" body="Live feed of items that need your attention." bodyBn="আপনার মনোযোগ প্রয়োজন এমন বিষয়ের লাইভ তালিকা।"/><Panel>{!noticesLoaded?<div className="empty-table"><RefreshCw className="spin"/><b>{tr("Loading notifications...","নোটিফিকেশন লোড হচ্ছে...")}</b></div>:liveNotices.length===0?<div className="empty-table"><Bell/><b>{tr("No new notifications","নতুন কোনো নোটিফিকেশন নেই")}</b><p>{tr("You're all caught up.","সব কিছু আপ টু ডেট।")}</p></div>:<div className="ops-list">{liveNotices.map((n,i)=><Link href={n.href} key={`${n.title}-${i}`}><span className={`ops-icon o${i%4}`}><Bell/></span><div><b>{n.title}</b><p>{n.subtitle}</p></div><button title="View" onClick={(e)=>{e.preventDefault();openNotice(n,i)}}><Eye/></button></Link>)}</div>}</Panel><AdminRecordModal open={!!selected} onClose={()=>setSelected(null)} title={selected?.title||""} subtitle={selected?.subtitle} icon={Bell} status={selected?.status} fields={selected?.fields||[]}/></>;
}


function BannerManager() {
  const { tr } = useI18n();
  const imagePositionPresets=["center 40%","center top","center bottom","left center","right center"];
  const mobilePositionPresets=["65% center","center top","center bottom","left center","right center"];
  const [items, setItems] = useState<ClubBanner[]>([]);
  const [draft, setDraft] = useState<ClubBanner | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  async function load() {
    setLoading(true);
    try {
      const response = await fetch("/api/admin/banners", { cache: "no-store" });
      const data = await response.json() as { banners?: ClubBanner[]; message?: string };
      if (response.ok) setItems(data.banners || []);
      else setMessage({ type: "error", text: data.message || "Unable to load banners." });
    } catch { setMessage({ type: "error", text: tr("Unable to load banners.", "ব্যানার লোড করা যায়নি।") }); }
    finally { setLoading(false); }
  }
  useEffect(()=>{void load()},[]);

  function createBanner() {
    setIsNew(true); setMessage(null);
    setDraft({ ...fallbackBanner, id: "new", title: "YOUR BIG MATCHDAY STORY\nSTARTS HERE.", displayOrder: items.length + 1, imageUrl: "" });
  }
  function uploadImage(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file || !draft) return;
    if (!file.type.match(/^image\/(png|jpeg|webp)$/) || file.size > 1_500_000) {
      setMessage({ type: "error", text: tr("Use a JPG, PNG or WebP banner under 1.5 MB.", "১.৫ এমবির কম JPG, PNG বা WebP ব্যানার ব্যবহার করুন।") });
      event.target.value = ""; return;
    }
    const reader = new FileReader();
    reader.onload = () => setDraft(current => current ? { ...current, imageUrl: String(reader.result || "") } : current);
    reader.readAsDataURL(file);
  }
  function uploadMobileImage(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file || !draft) return;
    if (!file.type.match(/^image\/(png|jpeg|webp)$/) || file.size > 1_500_000) {
      setMessage({ type: "error", text: tr("Use a JPG, PNG or WebP banner under 1.5 MB.", "১.৫ এমবির কম JPG, PNG বা WebP ব্যানার ব্যবহার করুন।") });
      event.target.value = ""; return;
    }
    const reader = new FileReader();
    reader.onload = () => setDraft(current => current ? { ...current, mobileImageUrl: String(reader.result || "") } : current);
    reader.readAsDataURL(file);
  }
  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!draft) return; setSaving(true); setMessage(null);
    try {
      const response = await fetch("/api/admin/banners", { method: isNew ? "POST" : "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(draft) });
      const data = await response.json() as { message: string; banner?: ClubBanner };
      setMessage({ type: response.ok ? "success" : "error", text: data.message });
      if (response.ok) { setDraft(null); setIsNew(false); await load(); }
    } catch { setMessage({ type: "error", text: tr("Unable to save banner.", "ব্যানার সংরক্ষণ করা যায়নি।") }); }
    finally { setSaving(false); }
  }
  async function updateBanner(banner: ClubBanner) {
    setItems(current => current.map(item => item.id === banner.id ? banner : item));
    const response = await fetch("/api/admin/banners", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(banner) });
    if (!response.ok) await load();
  }
  async function move(index: number, direction: -1 | 1) {
    const target = index + direction; if (target < 0 || target >= items.length) return;
    const reordered = [...items]; [reordered[index], reordered[target]] = [reordered[target], reordered[index]];
    const normalized = reordered.map((item, position) => ({ ...item, displayOrder: position + 1 }));
    setItems(normalized);
    await Promise.all(normalized.map(item => fetch("/api/admin/banners", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(item) })));
  }
  async function remove(id: string) {
    if (!window.confirm(tr("Delete this banner permanently?", "এই ব্যানারটি স্থায়ীভাবে মুছবেন?"))) return;
    const response = await fetch("/api/admin/banners", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
    if (response.ok) setItems(current => current.filter(item => item.id !== id));
  }

  return <><AdminTitle title="Banner Management" bn="ব্যানার ব্যবস্থাপনা" body="Upload cinematic images and control exactly what visitors see in the homepage hero." bodyBn="সিনেম্যাটিক ছবি আপলোড করুন এবং হোমপেজ হিরোতে দর্শক কী দেখবে তা নিয়ন্ত্রণ করুন।" action={<Button onClick={createBanner} icon={false}><ImagePlus/>{tr("Add image banner", "ছবির ব্যানার যোগ")}</Button>}/><div className="banner-admin-summary"><div><PanelsTopLeft/><span><b>{items.length}</b>{tr("Total banners", "মোট ব্যানার")}</span></div><div><CheckCircle2/><span><b>{items.filter(item=>item.isActive).length}</b>{tr("Active banners", "সক্রিয় ব্যানার")}</span></div><p><ShieldCheck/>{tr("The first active banner is automatically used on the public homepage.", "প্রথম সক্রিয় ব্যানারটি স্বয়ংক্রিয়ভাবে পাবলিক হোমপেজে ব্যবহৃত হয়।")}</p></div><FormMessage state={message}/>{loading?<div className="empty-table"><RefreshCw className="spin"/><b>{tr("Loading banners...", "ব্যানার লোড হচ্ছে...")}</b></div>:items.length===0?<div className="banner-empty"><ImagePlus/><h2>{tr("Create your first homepage banner", "প্রথম হোমপেজ ব্যানার তৈরি করুন")}</h2><p>{tr("Upload a football image, write a headline and publish it in one click.", "ফুটবল ছবি আপলোড করুন, শিরোনাম লিখুন এবং এক ক্লিকে প্রকাশ করুন।")}</p><Button onClick={createBanner} icon={false}><Plus/>{tr("Create banner", "ব্যানার তৈরি")}</Button></div>:<div className="banner-admin-grid">{items.map((item,index)=><article className={`banner-admin-card ${item.isActive?"active":""}`} key={item.id}><div className="banner-admin-image" style={{backgroundImage:`linear-gradient(0deg,rgba(3,20,13,.85),rgba(3,20,13,.08)),url(${item.imageUrl})`}}><div><StatusPill status={item.isActive?"ACTIVE":"INACTIVE"}/><span>#{String(index+1).padStart(2,"0")}</span></div>{item.mobileImageUrl?<i className="mobile-ready-badge"><Smartphone/>{tr("Mobile ready","মোবাইল প্রস্তুত")}</i>:<i className="mobile-ready-badge missing"><Smartphone/>{tr("No mobile crop","মোবাইল ছবি নেই")}</i>}<section><small>{item.eyebrow}</small><h3>{item.title.replace("\n"," ")}</h3><p>{item.subtitle}</p></section></div><div className="banner-card-meta"><span><b>{item.buttonText}</b><small>{item.buttonLink}</small></span><label title={item.isActive?"Deactivate":"Activate"}><input type="checkbox" checked={item.isActive} onChange={()=>void updateBanner({...item,isActive:!item.isActive})}/><i/></label></div><div className="banner-card-actions"><button disabled={index===0} onClick={()=>void move(index,-1)}><ArrowUp/>{tr("Up", "উপরে")}</button><button disabled={index===items.length-1} onClick={()=>void move(index,1)}><ArrowDown/>{tr("Down", "নিচে")}</button><button onClick={()=>{setDraft(item);setIsNew(false);setMessage(null)}}><Pencil/>{tr("Edit", "সম্পাদনা")}</button><button className="danger" onClick={()=>void remove(item.id)}><Trash2/>{tr("Delete", "মুছুন")}</button></div></article>)}</div>}
  <Modal open={!!draft} onClose={()=>{setDraft(null);setIsNew(false)}} wide>{draft&&<form className="banner-editor" onSubmit={save}><div className="banner-editor-preview" style={{backgroundImage:`linear-gradient(90deg,rgba(2,18,12,.92),rgba(2,18,12,.22)),url(${draft.imageUrl||images.stadium})`}}><span>{draft.eyebrow}</span><h2>{draft.title.split("\n").map((line,index)=><span key={index}>{line}</span>)}</h2><p>{draft.subtitle}</p><b>{draft.buttonText}</b></div><div className="banner-editor-fields"><div><small>{isNew?tr("NEW HOMEPAGE BANNER", "নতুন হোমপেজ ব্যানার"):tr("EDIT HOMEPAGE BANNER", "হোমপেজ ব্যানার সম্পাদনা")}</small><h2>{tr("Design your hero story", "আপনার হিরো গল্প সাজান")}</h2></div><label className="banner-upload-zone"><ImagePlus/><b>{draft.imageUrl?tr("Change desktop banner image", "ডেস্কটপ ব্যানারের ছবি বদলান"):tr("Upload desktop banner image", "ডেস্কটপ ব্যানারের ছবি আপলোড")}</b><span>{tr("JPG, PNG, WebP • 1600×900 recommended • Max 1.5 MB","JPG, PNG, WebP • 1600×900 আদর্শ • সর্বোচ্চ ১.৫ এমবি")}</span><input type="file" accept="image/png,image/jpeg,image/webp" required={isNew&&!draft.imageUrl} onChange={uploadImage}/></label><label className="banner-upload-zone mobile-zone">{draft.mobileImageUrl?<img className="mobile-zone-preview" src={draft.mobileImageUrl} alt="Mobile banner preview"/>:<Smartphone/>}<b>{draft.mobileImageUrl?tr("Change mobile banner image", "মোবাইল ব্যানারের ছবি বদলান"):tr("Upload mobile banner image (optional)", "মোবাইল ব্যানারের ছবি আপলোড (ঐচ্ছিক)")}</b><span>{tr("A taller, phone-friendly crop • shown automatically on phones • Max 1.5 MB","লম্বা, ফোন-উপযোগী ছবি • ফোনে স্বয়ংক্রিয়ভাবে দেখাবে • সর্বোচ্চ ১.৫ এমবি")}</span><input type="file" accept="image/png,image/jpeg,image/webp" onChange={uploadMobileImage}/>{draft.mobileImageUrl&&<button type="button" className="mobile-zone-clear" onClick={(e)=>{e.preventDefault();e.stopPropagation();setDraft(current=>current?{...current,mobileImageUrl:""}:current)}}>{tr("Remove","মুছুন")}</button>}</label><div className="form-grid"><label>{tr("Desktop image position","ডেস্কটপ ছবির অবস্থান")}<select value={imagePositionPresets.includes(draft.imagePosition||"")?draft.imagePosition:"CUSTOM"} onChange={e=>setDraft({...draft,imagePosition:e.target.value==="CUSTOM"?(draft.imagePosition||"center center"):e.target.value})}><option value="center 40%">{tr("Center (default)","কেন্দ্র (ডিফল্ট)")}</option><option value="center top">{tr("Top","উপরে")}</option><option value="center bottom">{tr("Bottom","নিচে")}</option><option value="left center">{tr("Left","বামে")}</option><option value="right center">{tr("Right","ডানে")}</option><option value="CUSTOM">{tr("Custom","কাস্টম")}</option></select>{!imagePositionPresets.includes(draft.imagePosition||"")&&<input style={{marginTop:"8px"}} placeholder="e.g. 30% 60%" value={draft.imagePosition||""} onChange={e=>setDraft({...draft,imagePosition:e.target.value})}/>}</label><label>{tr("Mobile image position","মোবাইল ছবির অবস্থান")}<select value={mobilePositionPresets.includes(draft.mobileImagePosition||"")?draft.mobileImagePosition:"CUSTOM"} onChange={e=>setDraft({...draft,mobileImagePosition:e.target.value==="CUSTOM"?(draft.mobileImagePosition||"center center"):e.target.value})}><option value="65% center">{tr("Center (default)","কেন্দ্র (ডিফল্ট)")}</option><option value="center top">{tr("Top","উপরে")}</option><option value="center bottom">{tr("Bottom","নিচে")}</option><option value="left center">{tr("Left","বামে")}</option><option value="right center">{tr("Right","ডানে")}</option><option value="CUSTOM">{tr("Custom","কাস্টম")}</option></select>{!mobilePositionPresets.includes(draft.mobileImagePosition||"")&&<input style={{marginTop:"8px"}} placeholder="e.g. 30% 60%" value={draft.mobileImagePosition||""} onChange={e=>setDraft({...draft,mobileImagePosition:e.target.value})}/>}</label></div><div className="form-grid"><label>{tr("Eyebrow text", "উপরের ছোট লেখা")}<input value={draft.eyebrow} maxLength={120} onChange={e=>setDraft({...draft,eyebrow:e.target.value})}/></label><label>{tr("Display order", "প্রদর্শন ক্রম")}<input type="number" min="1" value={draft.displayOrder} onChange={e=>setDraft({...draft,displayOrder:Number(e.target.value)})}/></label><label className="full">{tr("Main title", "মূল শিরোনাম")}<textarea rows={2} required value={draft.title} onChange={e=>setDraft({...draft,title:e.target.value})}/><small>{tr("Use a new line to highlight the second line.", "দ্বিতীয় লাইন আলাদা দেখাতে নতুন লাইন ব্যবহার করুন।")}</small></label><label className="full">{tr("Subtitle", "উপশিরোনাম")}<textarea rows={3} required value={draft.subtitle} onChange={e=>setDraft({...draft,subtitle:e.target.value})}/></label><label>{tr("Button text", "বাটনের লেখা")}<input required value={draft.buttonText} onChange={e=>setDraft({...draft,buttonText:e.target.value})}/></label><label>{tr("Button link", "বাটনের লিংক")}<input required value={draft.buttonLink} onChange={e=>setDraft({...draft,buttonLink:e.target.value})}/></label></div><label className="banner-active-check"><input type="checkbox" checked={draft.isActive} onChange={e=>setDraft({...draft,isActive:e.target.checked})}/><span><b>{tr("Publish as active banner", "সক্রিয় ব্যানার হিসেবে প্রকাশ")}</b><small>{tr("Only active banners can appear on the homepage.", "শুধু সক্রিয় ব্যানার হোমপেজে দেখা যাবে।")}</small></span></label><div className="modal-actions"><Button type="button" variant="outline" icon={false} onClick={()=>setDraft(null)}>{tr("Cancel", "বাতিল")}</Button><Button type="submit" disabled={saving} icon={false}><Check/>{saving?tr("Saving...", "সংরক্ষণ হচ্ছে..."):tr("Save banner", "ব্যানার সংরক্ষণ")}</Button></div></div></form>}</Modal></>;
}

function BrandingManager() {
  const { tr } = useI18n();
  const { branding, apply } = useBranding();
  const [draft, setDraft] = useState<BrandingSettings>(branding);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => setDraft(branding), [branding]);

  function update(field: keyof BrandingSettings, value: string) {
    setDraft(current => ({ ...current, [field]: value }));
    setMessage(null);
  }

  function uploadLogo(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!file.type.match(/^image\/(png|jpeg|webp|svg\+xml)$/) || file.size > 1_500_000) {
      setMessage({ type: "error", text: tr("Use a PNG, JPG, WebP or SVG logo under 1.5 MB.", "১.৫ এমবির কম PNG, JPG, WebP বা SVG লোগো ব্যবহার করুন।") });
      event.target.value = "";
      return;
    }
    const reader = new FileReader();
    reader.onload = () => update("logo", String(reader.result || defaultBranding.logo));
    reader.readAsDataURL(file);
  }

  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setSaving(true); setMessage(null);
    try {
      const response = await fetch("/api/settings/branding", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(draft) });
      const data = await response.json() as { message: string; branding?: BrandingSettings };
      setMessage({ type: response.ok ? "success" : "error", text: data.message });
      if (response.ok && data.branding) { setDraft(data.branding); apply(data.branding); }
    } catch {
      setMessage({ type: "error", text: tr("Unable to save website branding.", "ওয়েবসাইট ব্র্যান্ডিং সংরক্ষণ করা যায়নি।") });
    } finally { setSaving(false); }
  }

  return <><AdminTitle title="Website Name & Logo" bn="ওয়েবসাইটের নাম ও লোগো" body="Change the identity used across the public website, member portal and admin panel." bodyBn="পাবলিক ওয়েবসাইট, সদস্য পোর্টাল ও অ্যাডমিন প্যানেলে ব্যবহৃত পরিচয় পরিবর্তন করুন।"/><form className="branding-manager" onSubmit={save}><Panel className="branding-preview-panel"><div className="branding-preview-dark"><img src={draft.logo} alt="New club logo preview"/><div><small>{draft.siteName}</small><strong>{draft.shortName}</strong><span>{draft.tagline}</span></div></div><div className="branding-logo-actions"><label className="btn btn-primary"><Upload/>{tr("Upload new logo", "নতুন লোগো আপলোড")}<input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" onChange={uploadLogo}/></label><Button type="button" variant="outline" icon={false} onClick={()=>update("logo",defaultBranding.logo)}><RefreshCw/>{tr("Use default logo", "ডিফল্ট লোগো")}</Button></div><div className="branding-file-help"><ShieldCheck/><span><b>{tr("One logo, everywhere", "এক লোগো, সব জায়গায়")}</b>{tr("PNG, JPG, WebP or SVG • transparent background recommended • maximum 1.5 MB", "PNG, JPG, WebP বা SVG • স্বচ্ছ ব্যাকগ্রাউন্ড ভালো • সর্বোচ্চ ১.৫ এমবি")}</span></div></Panel><Panel title={tr("Website identity", "ওয়েবসাইট পরিচয়")} className="branding-fields-panel"><div className="branding-fields"><label>{tr("Full website / club name", "সম্পূর্ণ ওয়েবসাইট / ক্লাবের নাম")}<input value={draft.siteName} maxLength={100} required onChange={e=>update("siteName",e.target.value)}/><small>{tr("Shown in the public header and browser title.", "পাবলিক হেডার ও ব্রাউজার টাইটেলে দেখা যাবে।")}</small></label><label>{tr("Short name", "সংক্ষিপ্ত নাম")}<input value={draft.shortName} maxLength={50} required onChange={e=>update("shortName",e.target.value)}/><small>{tr("Used on compact club displays.", "ছোট ক্লাব ডিসপ্লেতে ব্যবহৃত হবে।")}</small></label><label>{tr("Member portal name", "সদস্য পোর্টালের নাম")}<input value={draft.portalName} maxLength={70} required onChange={e=>update("portalName",e.target.value)}/></label><label>{tr("Admin panel name", "অ্যাডমিন প্যানেলের নাম")}<input value={draft.adminName} maxLength={70} required onChange={e=>update("adminName",e.target.value)}/></label><label className="full">{tr("Tagline", "ট্যাগলাইন")}<input value={draft.tagline} maxLength={100} required onChange={e=>update("tagline",e.target.value)}/></label></div><div className="branding-save-bar"><FormMessage state={message}/><div><Button type="button" variant="outline" icon={false} onClick={()=>{setDraft(defaultBranding);setMessage(null)}}>{tr("Restore all defaults", "সব ডিফল্ট ফিরিয়ে আনুন")}</Button><Button type="submit" disabled={saving} icon={false}><Check/>{saving?tr("Saving...", "সংরক্ষণ হচ্ছে..."):tr("Save name & logo", "নাম ও লোগো সংরক্ষণ")}</Button></div></div></Panel></form></>;
}

function AdminSecurityManager(){
  const {tr}=useI18n();
  const [currentEmail,setCurrentEmail]=useState<string|null>(null);
  const [loading,setLoading]=useState(true);
  const [saving,setSaving]=useState(false);
  const [message,setMessage]=useState<{type:"success"|"error";text:string}|null>(null);
  useEffect(()=>{(async()=>{try{const res=await fetch("/api/admin/auth",{cache:"no-store"});const data=await res.json() as {authenticated:boolean;email?:string};setCurrentEmail(data.email||null)}finally{setLoading(false)}})()},[]);
  async function save(event:FormEvent<HTMLFormElement>){
    event.preventDefault();setSaving(true);setMessage(null);
    const data=new FormData(event.currentTarget);
    const currentPin=String(data.get("currentPin")||"");
    const newEmail=String(data.get("newEmail")||"");
    const newPin=String(data.get("newPin")||"");
    const confirmPin=String(data.get("confirmPin")||"");
    if(newPin&&newPin!==confirmPin){setMessage({type:"error",text:tr("New PIN and confirmation do not match.","নতুন পিন ও নিশ্চিতকরণ মিলছে না।")});setSaving(false);return}
    try{
      const res=await fetch("/api/admin/auth",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({currentPin,newEmail,newPin})});
      const result=await res.json() as {message:string;email?:string};
      if(res.ok){setMessage({type:"success",text:result.message});setCurrentEmail(result.email||newEmail);(event.currentTarget as HTMLFormElement).reset()}
      else setMessage({type:"error",text:result.message});
    }catch{setMessage({type:"error",text:tr("Unable to connect.","সংযোগ করা যাচ্ছে না।")})}
    finally{setSaving(false)}
  }
  return <><AdminTitle title="Admin Login & Security" bn="অ্যাডমিন লগইন ও নিরাপত্তা" body="Change the email and PIN used to sign in to this admin panel." bodyBn="এই অ্যাডমিন প্যানেলে লগইন করতে ব্যবহৃত ইমেইল ও পিন পরিবর্তন করুন।"/><Panel><div className="admin-security-current"><ShieldCheck/><div><b>{tr("Current admin email","বর্তমান অ্যাডমিন ইমেইল")}</b><p>{loading?tr("Loading...","লোড হচ্ছে..."):currentEmail||tr("Not set","সেট করা হয়নি")}</p></div></div></Panel><Panel title={tr("Change email & PIN","ইমেইল ও পিন পরিবর্তন")}><form className="admin-security-form" onSubmit={save}><label>{tr("Current PIN (required to confirm)","বর্তমান পিন (নিশ্চিত করতে প্রয়োজন)")}<input name="currentPin" type="password" required autoComplete="current-password" placeholder="••••••••"/></label><div className="form-grid"><label>{tr("New admin email","নতুন অ্যাডমিন ইমেইল")}<input name="newEmail" type="email" required defaultValue={currentEmail||""} autoComplete="username"/></label><label>{tr("New PIN (leave blank to keep current)","নতুন পিন (একই রাখতে খালি রাখুন)")}<input name="newPin" type="password" minLength={6} autoComplete="new-password" placeholder="••••••••"/></label></div><label>{tr("Confirm new PIN","নতুন পিন নিশ্চিত করুন")}<input name="confirmPin" type="password" minLength={6} autoComplete="new-password" placeholder="••••••••"/></label><FormMessage state={message}/><div className="modal-actions"><Button type="submit" disabled={saving} icon={false}><Check/>{saving?tr("Saving...","সংরক্ষণ হচ্ছে..."):tr("Save changes","পরিবর্তন সংরক্ষণ")}</Button></div></form></Panel><Panel title={tr("About sign-in security","লগইন নিরাপত্তা সম্পর্কে")}><p className="admin-security-note">{tr("Only one admin account exists for this club panel. Anyone with this email and PIN can sign in — keep them private and change the PIN periodically.","এই ক্লাব প্যানেলের জন্য শুধুমাত্র একটি অ্যাডমিন অ্যাকাউন্ট আছে। এই ইমেইল ও পিন যার কাছে থাকবে সে লগইন করতে পারবে — এগুলো গোপন রাখুন এবং নিয়মিত পিন পরিবর্তন করুন।")}</p></Panel></>;
}

type ManagedItem={title:string;description:string;status:string;fileData?:string;fileName?:string;fileMime?:string};

type PostRow={id:string;title:string;category:string;excerpt:string;body:string;coverImage:string|null;status:string;createdAt:string};

function NewsAdmin(){
  const {tr}=useI18n();
  const [items,setItems]=useState<PostRow[]>([]);
  const [loading,setLoading]=useState(true);
  const [editor,setEditor]=useState<PostRow|"new"|null>(null);
  const [selected,setSelected]=useState<PostRow|null>(null);
  const [saving,setSaving]=useState(false);
  const [message,setMessage]=useState<{type:"success"|"error";text:string}|null>(null);
  const [imageDraft,setImageDraft]=useState<string>("");
  const [imageError,setImageError]=useState<string|null>(null);

  async function load(){setLoading(true);try{const res=await fetch("/api/admin/news",{cache:"no-store"});const data=await res.json() as {posts?:PostRow[]};if(res.ok)setItems(data.posts||[])}finally{setLoading(false)}}
  useEffect(()=>{void load()},[]);

  function openEditor(item:PostRow|"new"){setEditor(item);setImageDraft(item!=="new"?(item.coverImage||""):"");setImageError(null);setMessage(null)}
  function onImageChange(event:ChangeEvent<HTMLInputElement>){
    const file=event.target.files?.[0];setImageError(null);
    if(!file)return;
    if(!file.type.match(/^image\/(png|jpeg|webp|gif)$/)||file.size>4_000_000){setImageError(tr("Use a PNG, JPG, WebP or GIF image under 4 MB.","৪ এমবির কম PNG, JPG, WebP বা GIF ছবি ব্যবহার করুন।"));event.target.value="";return}
    const reader=new FileReader();
    reader.onload=()=>setImageDraft(String(reader.result||""));
    reader.readAsDataURL(file);
  }

  async function save(event:FormEvent<HTMLFormElement>){
    event.preventDefault();
    const data=new FormData(event.currentTarget);
    const payload={title:String(data.get("title")||""),category:String(data.get("category")||"Club News"),excerpt:String(data.get("excerpt")||""),body:String(data.get("body")||""),coverImage:imageDraft,status:String(data.get("status")||"DRAFT")};
    setSaving(true);setMessage(null);
    try{
      const res=editor==="new"
        ?await fetch("/api/admin/news",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)})
        :await fetch("/api/admin/news",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({...payload,id:(editor as PostRow).id})});
      const result=await res.json() as {message:string};
      if(res.ok){await load();setEditor(null)}
      else setMessage({type:"error",text:result.message});
    }catch{setMessage({type:"error",text:tr("Unable to save the story.","গল্পটি সংরক্ষণ করা যায়নি।")})}
    finally{setSaving(false)}
  }

  async function remove(id:string){
    if(!window.confirm(tr("Delete this story permanently?","এই গল্পটি স্থায়ীভাবে মুছবেন?")))return;
    setSaving(true);
    try{const res=await fetch(`/api/admin/news?id=${id}`,{method:"DELETE"});if(res.ok){await load();setSelected(null)}}
    finally{setSaving(false)}
  }
  async function togglePublish(item:PostRow){
    setSaving(true);
    try{const res=await fetch("/api/admin/news",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:item.id,status:item.status==="PUBLISHED"?"DRAFT":"PUBLISHED"})});if(res.ok)await load()}
    finally{setSaving(false)}
  }

  const fields:DetailField[]=selected?[{label:tr("Title","শিরোনাম"),value:selected.title},{label:tr("Category","বিভাগ"),value:selected.category},{label:tr("Status","অবস্থা"),value:<StatusPill status={selected.status}/>},{label:tr("Published","প্রকাশিত"),value:new Date(selected.createdAt).toLocaleDateString()},{label:tr("Excerpt","সংক্ষিপ্তসার"),value:selected.excerpt,wide:true},{label:tr("Full story","সম্পূর্ণ গল্প"),value:selected.body||"—",wide:true}]:[];

  return <><AdminTitle title="News Management" bn="সংবাদ ব্যবস্থাপনা" body="Publish club stories with a cover photo — visible instantly on the public site." bodyBn="কভার ছবিসহ ক্লাব সংবাদ প্রকাশ করুন — সাথে সাথে পাবলিক সাইটে দেখা যাবে।" action={<Button onClick={()=>openEditor("new")} icon={false}><Plus/>{tr("New story","নতুন সংবাদ")}</Button>}/>
  {message&&<div className={`portal-alert ${message.type==="error"?"error":"success"}`}>{message.type==="success"?<CheckCircle2/>:<AlertTriangle/>}{message.text}</div>}
  <Panel>
    {loading?<div className="empty-table"><RefreshCw className="spin"/><b>{tr("Loading stories...","গল্প লোড হচ্ছে...")}</b></div>
    :items.length===0?<div className="empty-table"><Newspaper/><b>{tr("No stories yet","এখনো কোনো গল্প নেই")}</b><p>{tr("Publish your first club story.","আপনার প্রথম ক্লাব সংবাদ প্রকাশ করুন।")}</p></div>
    :<div className="content-manager-list">{items.map(item=><div key={item.id}>
        {item.coverImage?<img src={item.coverImage} alt={item.title} style={{width:56,height:56,borderRadius:10,objectFit:"cover"}}/>:<span className="ops-icon o0"><Newspaper/></span>}
        <div><b>{item.title}</b><p>{item.category} • {new Date(item.createdAt).toLocaleDateString()}</p></div>
        <StatusPill status={item.status}/>
        <div className="row-actions">
          <button title="View" onClick={()=>setSelected(item)}><Eye/></button>
          <button title="Edit" onClick={()=>openEditor(item)}><Pencil/></button>
          <button title={item.status==="PUBLISHED"?"Unpublish":"Publish"} className={item.status==="PUBLISHED"?"":"approve"} disabled={saving} onClick={()=>void togglePublish(item)}>{item.status==="PUBLISHED"?<X/>:<Check/>}</button>
          <button title="Delete" className="reject" disabled={saving} onClick={()=>void remove(item.id)}><Trash2/></button>
        </div>
      </div>)}</div>}
  </Panel>
  <AdminRecordModal open={!!selected} onClose={()=>setSelected(null)} title={selected?.title||""} subtitle={tr("STORY DETAILS","গল্পের বিস্তারিত")} icon={Newspaper} image={selected?.coverImage||undefined} status={selected?.status} fields={fields}/>
  <Modal open={editor!==null} onClose={()=>setEditor(null)}>
    <form className="modal-form" onSubmit={save}>
      <span className="modal-icon"><Newspaper/></span>
      <h2>{editor==="new"?tr("Publish new story","নতুন গল্প প্রকাশ"):tr("Edit story","গল্প সম্পাদনা")}</h2>
      <label>{tr("Title","শিরোনাম")}<input name="title" required maxLength={200} defaultValue={editor!=="new"&&editor?editor.title:""}/></label>
      <div className="form-grid">
        <label>{tr("Category","বিভাগ")}<input name="category" maxLength={60} defaultValue={editor!=="new"&&editor?editor.category:"Club News"}/></label>
        <label>{tr("Status","অবস্থা")}<select name="status" defaultValue={editor!=="new"&&editor?editor.status:"DRAFT"}><option value="DRAFT">{tr("Draft","খসড়া")}</option><option value="PUBLISHED">{tr("Published","প্রকাশিত")}</option></select></label>
      </div>
      <label>{tr("Excerpt","সংক্ষিপ্তসার")}<textarea name="excerpt" required maxLength={400} rows={2} defaultValue={editor!=="new"&&editor?editor.excerpt:""}/></label>
      <label>{tr("Full story","সম্পূর্ণ গল্প")}<textarea name="body" maxLength={20000} rows={6} defaultValue={editor!=="new"&&editor?editor.body:""}/></label>
      <label className="upload-box">
        {imageDraft?<img src={imageDraft} alt="Cover preview" style={{width:"100%",maxHeight:160,objectFit:"cover",borderRadius:10}}/>:<><Upload/><b>{tr("Upload cover photo","কভার ছবি আপলোড")}</b></>}
        <input type="file" accept="image/*" onChange={onImageChange}/>
      </label>
      {imageError&&<p className="field-error">{imageError}</p>}
      <div className="modal-actions"><Button type="button" variant="outline" onClick={()=>setEditor(null)} icon={false}>{tr("Cancel","বাতিল")}</Button><Button type="submit" disabled={saving} icon={false}>{saving?tr("Saving...","সংরক্ষণ হচ্ছে..."):tr("Save story","সংরক্ষণ")}</Button></div>
    </form>
  </Modal>
</>;
}

function ContentManager({type}:{type:string}) {
  const {tr}=useI18n();
  const config:Record<string,[string,string,string,LucideIcon]>={matches:["Matches","ম্যাচ","Schedule and update club matches.",Swords],fixtures:["Fixtures","ফিক্সচার","Publish upcoming club fixtures.",CalendarDays],tournaments:["Tournaments","টুর্নামেন্ট","Create and manage competitions.",Trophy],news:["News Management","সংবাদ ব্যবস্থাপনা","Create, publish and manage club stories.",Newspaper],gallery:["Gallery Management","গ্যালারি ব্যবস্থাপনা","Upload and organize club moments.",Images],announcements:["Announcements","ঘোষণা","Send important messages to members.",Megaphone],banners:["Banner Management","ব্যানার ব্যবস্থাপনা","Control the active public homepage hero.",PanelsTopLeft],logos:["Logo & Media","লোগো ও মিডিয়া","Update logos, favicon and group photo.",ImageUp],documents:["Documents","ডকুমেন্ট","Manage private member files.",FolderDown],"admin-users":["Admin Users","অ্যাডমিন ইউজার","Manage privileged roles and access.",ShieldCheck],settings:["Club Settings","ক্লাব সেটিংস","Configure identity, contact and system preferences.",Settings]};
  const [en,bn,body,Icon]=config[type]||config.settings;
  const hasImageUpload=type==="gallery";
  const hasFileUpload=type==="documents";
  const fallbackThumb=(i:number)=>i===0?images.hero:i===1?images.action:images.family;
  const initial:ManagedItem[]=type==="logos"?[{title:"Website Logo",description:"Public header and footer",status:"ACTIVE"},{title:"Admin Logo",description:"Admin console",status:"ACTIVE"},{title:"Member Logo",description:"Member portal",status:"ACTIVE"},{title:"Favicon",description:"Browser icon",status:"ACTIVE"},{title:"Home Group Photo",description:"The Fantastic Family section",status:"ACTIVE"}]:type==="banners"?[{title:"Season 2025 Hero",description:"Built by passion. United by football.",status:"ACTIVE"},{title:"Tournament Campaign",description:"Register for KPL 2025",status:"INACTIVE"},{title:"Membership Campaign",description:"Join the Fantastic Family",status:"INACTIVE"}]:type==="documents"?[{title:"Club Constitution 2025",description:"Official • PDF • 1.8 MB",status:"MEMBERS ONLY"},{title:"KPL Tournament Rules",description:"Tournament • PDF • 820 KB",status:"MEMBERS ONLY"},{title:"Member Code of Conduct",description:"Member • DOCX • 340 KB",status:"MEMBERS ONLY"}]:[{title:`Fantastic FC ${en} item 01`,description:body,status:"PUBLISHED"},{title:`${en} item 02`,description:"Updated by Super Admin",status:"DRAFT"},{title:`${en} item 03`,description:"Last updated 12 June 2025",status:"ACTIVE"}];
  const [items,setItems]=useState<ManagedItem[]>(initial);const [selected,setSelected]=useState<number|null>(null);const [editing,setEditing]=useState<number|"new"|null>(null);
  const [draftFile,setDraftFile]=useState<{data:string;name:string;mime:string}|null>(null);
  const [fileError,setFileError]=useState<string|null>(null);
  function onFileChange(event:ChangeEvent<HTMLInputElement>){
    const file=event.target.files?.[0];setFileError(null);
    if(!file)return;
    if(hasImageUpload&&(!file.type.match(/^image\/(png|jpeg|webp|gif)$/)||file.size>4_000_000)){setFileError(tr("Use a PNG, JPG, WebP or GIF image under 4 MB.","৪ এমবির কম PNG, JPG, WebP বা GIF ছবি ব্যবহার করুন।"));event.target.value="";return}
    if(hasFileUpload&&(!file.type.match(/^(application\/pdf|application\/msword|application\/vnd\.openxmlformats-officedocument\.wordprocessingml\.document)$/)||file.size>8_000_000)){setFileError(tr("Use a PDF or Word file under 8 MB.","৮ এমবির কম PDF বা Word ফাইল ব্যবহার করুন।"));event.target.value="";return}
    const reader=new FileReader();
    reader.onload=()=>setDraftFile({data:String(reader.result||""),name:file.name,mime:file.type});
    reader.readAsDataURL(file);
  }
  function save(event:FormEvent<HTMLFormElement>){
    event.preventDefault();const data=new FormData(event.currentTarget);
    const existing=typeof editing==="number"?items[editing]:null;
    const next:ManagedItem={
      title:String(data.get("title")),
      description:(hasFileUpload&&draftFile)?`${draftFile.mime==="application/pdf"?"PDF":"DOCX"} • ${(draftFile.data.length*0.75/1024).toFixed(0)} KB`:String(data.get("description")),
      status:String(data.get("status")),
      fileData:draftFile?.data??existing?.fileData,
      fileName:draftFile?.name??existing?.fileName,
      fileMime:draftFile?.mime??existing?.fileMime,
    };
    if(editing==="new")setItems(v=>[next,...v]);else if(typeof editing==="number")setItems(v=>v.map((x,i)=>i===editing?next:x));
    setEditing(null);setDraftFile(null);setFileError(null);
  }
  const current=selected===null?null:items[selected];
  const fields:DetailField[]=current?[{label:tr("Title","শিরোনাম"),value:current.title},{label:tr("Description / value","বর্ণনা / মান"),value:current.description,wide:true},{label:tr("Status / visibility","অবস্থা / দৃশ্যমানতা"),value:<StatusPill status={current.status}/>},{label:tr("Management area","ব্যবস্থাপনা এলাকা"),value:en},{label:tr("Last updated","সর্বশেষ আপডেট"),value:tr("Club admin","ক্লাব অ্যাডমিন")},{label:tr("Audit tracking","অডিট ট্র্যাকিং"),value:tr("Enabled","সক্রিয়")}]:[];
  return <><AdminTitle title={en} bn={bn} body={body} bodyBn={body} action={<Button onClick={()=>{setEditing("new");setDraftFile(null);setFileError(null)}} icon={false}><Plus/>{tr("Add new","নতুন যোগ")}</Button>}/><div className="manager-summary"><Icon/><div><b>{items.length}</b><span>{tr("managed items","পরিচালিত আইটেম")}</span></div><p>{tr("Eye opens the complete preview. Changes are recorded in the audit log.","চোখে চাপলে সম্পূর্ণ প্রিভিউ খুলবে। পরিবর্তন অডিট লগে সংরক্ষিত হয়।")}</p></div><Panel><div className="content-manager-list">{items.map((item,i)=><div key={`${item.title}-${i}`}>{type==="logos"||type==="banners"?<div className="manager-thumb" style={{backgroundImage:`url(${fallbackThumb(i)})`}}/>:hasImageUpload?(item.fileData?<div className="manager-thumb" style={{backgroundImage:`url(${item.fileData})`}}/>:<span className="manager-icon"><Icon/></span>):hasFileUpload&&item.fileData?<span className="manager-icon file-ready"><FileText/></span>:<span className="manager-icon"><Icon/></span>}<div><b>{item.title}</b><p>{item.description}</p><small>{tr("Updated 18 June 2025","আপডেট ১৮ জুন ২০২৫")}</small></div><StatusPill status={item.status}/><div className="row-actions"><button title="View complete preview" onClick={()=>setSelected(i)}><Eye/></button><button title="Edit" onClick={()=>{setEditing(i);setDraftFile(null);setFileError(null)}}><Pencil/></button><button title="Delete" className="reject" onClick={()=>{if(window.confirm(tr("Delete this item?","আইটেমটি মুছবেন?")))setItems(v=>v.filter((_,index)=>index!==i))}}><Trash2/></button></div></div>)}</div></Panel><AdminRecordModal open={selected!==null} onClose={()=>setSelected(null)} title={current?.title||""} subtitle={`${en.toUpperCase()} • ${tr("COMPLETE PREVIEW","সম্পূর্ণ প্রিভিউ")}`} icon={Icon} status={current?.status} fields={fields}>{current&&(type==="banners"||type==="logos")&&<img className="record-preview-image" src={selected!==null?fallbackThumb(selected):images.hero} alt={current.title}/>}{current&&hasImageUpload&&(current.fileData?<img className="record-preview-image" src={current.fileData} alt={current.title}/>:<div className="record-empty-preview"><Images/><p>{tr("No photo uploaded yet. Edit this item to upload one.","এখনো কোনো ছবি আপলোড হয়নি। আপলোড করতে এডিট করুন।")}</p></div>)}{current&&hasFileUpload&&(current.fileData?(current.fileMime==="application/pdf"?<div className="pdf-preview-wrap"><iframe src={current.fileData} title={current.title} className="pdf-preview-frame"/><a className="btn btn-outline" href={current.fileData} download={current.fileName}><Download/>{tr("Download file","ফাইল ডাউনলোড")}</a></div>:<div className="record-empty-preview"><FileText/><p>{current.fileName}</p><a className="btn btn-primary" href={current.fileData} download={current.fileName}><Download/>{tr("Download file","ফাইল ডাউনলোড")}</a></div>):<div className="record-empty-preview"><FileText/><p>{tr("No file uploaded yet. Edit this item to upload a PDF or Word file.","এখনো কোনো ফাইল আপলোড হয়নি। PDF বা Word ফাইল আপলোড করতে এডিট করুন।")}</p></div>)}</AdminRecordModal><Modal open={editing!==null} onClose={()=>{setEditing(null);setDraftFile(null);setFileError(null)}}><form className="modal-form" onSubmit={save}><span className="modal-icon"><Icon/></span><h2>{editing==="new"?tr("Add new item","নতুন আইটেম যোগ"):tr("Edit item","আইটেম সম্পাদনা")}</h2><label>{tr("Title","শিরোনাম")}<input name="title" required defaultValue={typeof editing==="number"?items[editing]?.title:""}/></label>{(hasImageUpload||hasFileUpload)&&<label className="upload-box">{hasImageUpload?<ImagePlus/>:<FileText/>}<b>{draftFile?draftFile.name:(typeof editing==="number"&&items[editing]?.fileName)?tr("Replace uploaded file","আপলোড করা ফাইল পরিবর্তন"):tr(hasImageUpload?"Upload photo":"Upload PDF or Word file",hasImageUpload?"ছবি আপলোড করুন":"PDF বা Word ফাইল আপলোড করুন")}</b><span>{hasImageUpload?tr("JPG, PNG, WebP or GIF • max 4 MB","JPG, PNG, WebP বা GIF • সর্বোচ্চ ৪ এমবি"):tr("PDF or DOCX • max 8 MB","PDF বা DOCX • সর্বোচ্চ ৮ এমবি")}</span><input type="file" accept={hasImageUpload?"image/png,image/jpeg,image/webp,image/gif":"application/pdf,.doc,.docx"} onChange={onFileChange}/></label>}{fileError&&<p className="upload-error">{fileError}</p>}{!hasFileUpload&&<label>{tr("Description / value","বর্ণনা / মান")}<textarea name="description" rows={3} required defaultValue={typeof editing==="number"?items[editing]?.description:""}/></label>}<label>{tr("Status","অবস্থা")}<select name="status" defaultValue={typeof editing==="number"?items[editing]?.status:"ACTIVE"}><option>ACTIVE</option><option>INACTIVE</option><option>PUBLISHED</option><option>DRAFT</option><option>MEMBERS ONLY</option></select></label><div className="modal-actions"><Button type="button" variant="outline" icon={false} onClick={()=>{setEditing(null);setDraftFile(null);setFileError(null)}}>{tr("Cancel","বাতিল")}</Button><Button type="submit" icon={false}>{tr("Save changes","পরিবর্তন সংরক্ষণ")}</Button></div></form></Modal></>;
}
function AdminContent(){const p=usePathname();if(p==="/admin")return <AdminDashboard/>;if(p==="/admin/members")return <MemberManagement/>;if(p==="/admin/approvals")return <MemberManagement approvals/>;if(p==="/admin/players")return <PlayerManagement/>;if(p==="/admin/field")return <AdminField/>;if(p==="/admin/payments")return <PaymentsAdmin/>;if(p==="/admin/verification")return <PaymentsAdmin verify/>;if(p==="/admin/payment-methods")return <PaymentMethodsAdmin/>;if(p==="/admin/fees")return <FeeStructureAdmin/>;if(p==="/admin/financial")return <FinancialAdmin/>;if(p==="/admin/fund")return <FinancialAdmin fund/>;if(p==="/admin/expenses")return <FinancialAdmin expense/>;if(p==="/admin/jersey")return <JerseyAdmin/>;if(p==="/admin/matches")return <MatchManagement/>;if(p==="/admin/banners")return <BannerManager/>;if(p==="/admin/logos")return <BrandingManager/>;if(p==="/admin/security")return <AdminSecurityManager/>;if(p==="/admin/pin-resets")return <PinResetAdmin/>;if(p==="/admin/tournament-apps")return <OpsPage type="tournament"/>;if(p==="/admin/admin-notifications")return <OpsPage type="notifications"/>;if(p==="/admin/news")return <NewsAdmin/>;if(p==="/admin/audit")return <OpsPage type="audit"/>;return <ContentManager type={p.split("/").pop()||"settings"}/>}

export function AdminPanel(){const [open,setOpen]=useState(false);const {branding}=useBranding();return <div className="admin-shell"><AdminSidebar open={open} close={()=>setOpen(false)}/>{open&&<button className="sidebar-scrim" onClick={()=>setOpen(false)} aria-label="Close navigation"/>}<div className="admin-main"><AdminHeader openMenu={()=>setOpen(true)}/><main className="admin-content"><AdminContent/></main><footer className="portal-small-footer">© 2025 {branding.siteName} <span>•</span> SECURE ADMIN CONSOLE</footer></div></div>}
