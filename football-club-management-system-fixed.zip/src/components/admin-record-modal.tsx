"use client";

import { CheckCircle2, Copy, Eye, ShieldCheck, type LucideIcon } from "lucide-react";
import type { ReactNode } from "react";
import { useI18n } from "@/lib/i18n";
import { Avatar, Button, Modal, StatusPill } from "./ui";

export type DetailField = { label: string; value: ReactNode; wide?: boolean };

export function AdminRecordModal({
  open, onClose, title, subtitle, icon: Icon = Eye, image, status, fields, notice, children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  icon?: LucideIcon;
  image?: string;
  status?: string;
  fields: DetailField[];
  notice?: ReactNode;
  children?: ReactNode;
}) {
  const { tr } = useI18n();
  return <Modal open={open} onClose={onClose} wide><div className="admin-record-modal">
    <div className="record-modal-head"><span><Icon/></span><div>{subtitle&&<small>{subtitle}</small>}<h2>{title}</h2></div>{status&&<StatusPill status={status}/>}</div>
    {image&&<div className="record-person"><Avatar src={image} name={title} size="lg"/><div><b>{title}</b><span>{tr("Complete account information", "সম্পূর্ণ অ্যাকাউন্ট তথ্য")}</span></div><ShieldCheck/></div>}
    {notice&&<div className="record-notice"><CheckCircle2/>{notice}</div>}
    <div className="record-fields">{fields.map((field,index)=><div className={field.wide?"wide":""} key={`${field.label}-${index}`}><span>{field.label}</span><b>{field.value || "—"}</b></div>)}</div>
    {children&&<div className="record-modal-extra">{children}</div>}
  </div></Modal>;
}

export function OneTimePin({ pin }: { pin: string }) {
  const { tr } = useI18n();
  return <div className="one-time-pin"><div><small>{tr("ONE-TIME GENERATED PIN", "একবার প্রদর্শিত নতুন পিন")}</small><strong>{pin}</strong><span>{tr("This value is never stored as plain text.", "এই মানটি কখনো সাধারণ টেক্সট হিসেবে সংরক্ষিত হয় না।")}</span></div><Button variant="outline" icon={false} onClick={() => navigator.clipboard?.writeText(pin)}><Copy/>{tr("Copy PIN", "পিন কপি")}</Button></div>;
}
