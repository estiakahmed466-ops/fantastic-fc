"use client";

import { usePathname } from "next/navigation";
import { AdminPanel } from "./admin-panel";
import { MemberPortal } from "./member-portal";
import { PublicSite } from "./public-site";
import { I18nProvider } from "@/lib/i18n";
import { BrandingProvider } from "@/lib/branding";

function RouteView() {
  const pathname = usePathname();
  if (pathname.startsWith("/admin")) return <AdminPanel />;
  if (pathname.startsWith("/member")) return <MemberPortal />;
  return <PublicSite />;
}

export function ClubApp() {
  return <I18nProvider><BrandingProvider><RouteView /></BrandingProvider></I18nProvider>;
}
