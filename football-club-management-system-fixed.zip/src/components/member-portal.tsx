"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  ArrowLeft, BadgeCheck, Bell, CalendarCheck2, CalendarDays, ChartNoAxesCombined, CheckCircle2,
  ChevronDown, ChevronRight, CircleDollarSign, CircleUserRound, Clock3, CreditCard,
  Download, Dumbbell, Eye, EyeOff, FileText, FolderDown, Goal, HandCoins, House, Image as ImageIcon,
  KeyRound, Landmark, LayoutDashboard, Lock, LogOut, MapPin, Menu, Megaphone, Newspaper, ReceiptText,
  Search, RefreshCw, Settings, ShieldCheck, Shirt, Sparkles, Swords, Target, TrendingUp, Trophy, Upload,
  UserRound, Users, UsersRound, WalletCards, X, Zap, type LucideIcon,
} from "lucide-react";
import { createContext, useContext, useEffect, useMemo, useState, type ChangeEvent, type FormEvent } from "react";
import {
  documents, fixtures, images, memberNav,
} from "@/lib/club-data";
import { useI18n } from "@/lib/i18n";
import { useBranding } from "@/lib/branding";
import { playNotificationSound } from "@/lib/notification-sound";
import { Pitch } from "./public-site";
import { Avatar, Button, ClubLogo, ClubMark, FormMessage, LanguageSwitcher, Panel, PaymentLogo, StatCard, StatusPill } from "./ui";

type SessionMember = { id: string; memberId: string; fullName: string; email: string; profilePhoto: string | null; status: string; position: string | null; jerseyNumber: number | null };
const MemberSessionContext = createContext<{ member: SessionMember | null; loading: boolean }>({ member: null, loading: true });
function useMemberSession() { return useContext(MemberSessionContext); }

type MemberPayment = { id: string; feeType: string; amount: string; status: string; transactionId: string; method: string; createdAt: string; verifiedAt: string | null };
type MemberNotice = { id: string; title: string; titleBn: string; body: string; time: string; read: boolean };
function useMemberPayments() {
  const [payments, setPayments] = useState<MemberPayment[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => { (async () => {
    try { const res = await fetch("/api/payments", { cache: "no-store" }); const data = await res.json() as { payments?: MemberPayment[] }; setPayments(data.payments || []); }
    catch { /* best-effort */ }
    finally { setLoading(false); }
  })(); }, []);
  return { payments, loading };
}
function useMemberNotices(): MemberNotice[] {
  const { payments } = useMemberPayments();
  return useMemo(() => payments.filter(p => p.status !== "PENDING").map(p => ({
    id: p.id,
    title: p.status === "PAID" ? "Payment verified" : "Payment rejected",
    titleBn: p.status === "PAID" ? "পেমেন্ট যাচাই হয়েছে" : "পেমেন্ট প্রত্যাখ্যাত",
    body: `${p.feeType} • ৳ ${Number(p.amount).toLocaleString()} via ${p.method}`,
    time: new Date(p.verifiedAt || p.createdAt).toLocaleString(),
    read: false,
  })), [payments]);
}

const icons: Record<string, LucideIcon> = {
  LayoutDashboard, UserRound, UsersRound, Users, Swords, CalendarDays, Trophy,
  CreditCard, ReceiptText, ChartNoAxesCombined, HandCoins, Newspaper, Megaphone,
  Bell, FolderDown, Settings, Shirt,
};

function PortalSidebar({ open, close }: { open: boolean; close: () => void }) {
  const pathname = usePathname();
  const { language, tr } = useI18n();
  const { branding } = useBranding();
  const { member } = useMemberSession();
  const sections = [
    { en: "MY IDENTITY", bn: "আমার পরিচয়", items: memberNav.slice(1, 4) },
    { en: "FOOTBALL", bn: "ফুটবল", items: memberNav.slice(4, 7) },
    { en: "PAYMENTS & FINANCE", bn: "পেমেন্ট ও ফাইন্যান্স", items: memberNav.slice(7, 11) },
    { en: "CLUB UPDATES", bn: "ক্লাব আপডেট", items: memberNav.slice(11) },
  ];
  return <aside className={`portal-sidebar ${open ? "open" : ""}`}>
    <div className="portal-logo"><ClubLogo inverse/><button onClick={close}><X/></button></div>
    <Link className="portal-public-home" href="/" onClick={close}><House/><span><b>{tr("Public Home Page", "পাবলিক হোম পেজ")}</b><small>{tr("Back to the club website", "ক্লাব ওয়েবসাইটে ফিরে যান")}</small></span><ArrowLeft/></Link>
    <div className="sidebar-member"><div className="sidebar-member-photo"><Avatar src={member?.profilePhoto||undefined} name={member?.fullName||"Member"}/><i/></div><div><span className="member-role-chip"><Sparkles/>{tr("PLAYER / MEMBER", "খেলোয়াড় / সদস্য")}</span><b>{member?.fullName||tr("Loading...","লোড হচ্ছে...")}</b><small>{member?.memberId} {member?.jerseyNumber?`• #${member.jerseyNumber}`:""} {member?.position?`• ${member.position}`:""}</small></div><ShieldCheck/></div>
    <nav className="portal-nav">{sections.map(section=><div className="portal-nav-section" key={section.en}><small>{language === "bn" ? section.bn : section.en}</small>{section.items.map(([href,en,bn,icon]) => { const Icon=icons[icon]; const active=pathname===href; return <Link href={href} key={href} className={active?"active":""} onClick={close}><Icon/><span>{language==="bn"?bn:en}</span><ChevronRight/></Link>})}</div>)}</nav>
    <div className="sidebar-help"><ShieldCheck/><div><b>{tr("Portal protected", "পোর্টাল সুরক্ষিত")}</b><span>{tr("Your member data stays private", "আপনার সদস্য তথ্য ব্যক্তিগত")}</span></div><i/></div>
    <Link className="sidebar-logout" href="/login" onClick={()=>{fetch("/api/member/auth",{method:"DELETE"}).catch(()=>{})}}><LogOut/>{tr("Sign out safely", "নিরাপদে লগআউট")}</Link>
  </aside>
}

function PortalHeader({ openMenu }: { openMenu: () => void }) {
  const { language, tr } = useI18n();
  const { branding } = useBranding();
  const { member } = useMemberSession();
  const notices_data = useMemberNotices();
  const [notices, setNotices] = useState(false);
  const [profileMenu, setProfileMenu] = useState(false);
  const [readIds, setReadIds] = useState<Set<string>>(new Set());
  const unreadCount = notices_data.filter(n=>!readIds.has(n.id)).length;
  return <header className="portal-header"><button className="portal-menu" onClick={openMenu}><Menu/></button><div className="portal-header-brand"><span>{branding.portalName}</span><b><i/>{tr("PLAYER / MEMBER AREA", "খেলোয়াড় / সদস্য এলাকা")}</b></div><div className="portal-header-actions"><Link className="portal-home-button" href="/"><House/><span>{tr("Home Page", "হোম পেজ")}</span></Link><LanguageSwitcher dark/><button className="header-bell" onClick={()=>{if(!notices)playNotificationSound();setNotices(v=>!v);setProfileMenu(false)}}><Bell/>{unreadCount>0&&<i>{unreadCount}</i>}</button><button className="header-profile" onClick={()=>{setProfileMenu(v=>!v);setNotices(false)}}><Avatar src={member?.profilePhoto||undefined} name={member?.fullName||"Member"} size="sm"/><span><b>{member?.fullName||tr("Loading...","লোড হচ্ছে...")}</b><small>{tr("PLAYER / MEMBER", "খেলোয়াড় / সদস্য")}</small></span><ChevronDown/></button></div>{notices&&<div className="notice-dropdown"><div><b>{tr("Notifications","নোটিফিকেশন")}</b><Link href="/member/notifications">{tr("View all","সব দেখুন")}</Link></div>{notices_data.length===0?<p className="notice-empty">{tr("No notifications yet.","এখনো কোনো নোটিফিকেশন নেই।")}</p>:notices_data.map(n=><Link href="/member/payment-history" key={n.id} onClick={()=>{setReadIds(prev=>new Set([...prev,n.id]));setNotices(false)}}><span className={readIds.has(n.id)?"":"unread"}><Bell/></span><p><b>{tr(n.title,n.titleBn)}</b><small>{n.body} • {n.time}</small></p></Link>)}</div>}{profileMenu&&<div className="member-profile-menu"><div><Avatar src={member?.profilePhoto||undefined} name={member?.fullName||"Member"}/><span><b>{member?.fullName||tr("Loading...","লোড হচ্ছে...")}</b><small>{member?.memberId} • {tr("ACTIVE", "সক্রিয়")}</small></span></div><Link href="/member/profile" onClick={()=>setProfileMenu(false)}><UserRound/>{tr("My profile", "আমার প্রোফাইল")}<ChevronRight/></Link><Link href="/member/settings" onClick={()=>setProfileMenu(false)}><Settings/>{tr("Portal settings", "পোর্টাল সেটিংস")}<ChevronRight/></Link><Link href="/" onClick={()=>setProfileMenu(false)}><House/>{tr("Public home page", "পাবলিক হোম পেজ")}<ChevronRight/></Link><Link href="/login" onClick={()=>{fetch("/api/member/auth",{method:"DELETE"}).catch(()=>{})}}><LogOut/>{tr("Sign out", "লগআউট")}<ChevronRight/></Link></div>}</header>
}
function PortalTitle({ title, bn, body, bodyBn, action }: { title: string; bn: string; body?: string; bodyBn?: string; action?: React.ReactNode }) {
  const { tr }=useI18n(); const { branding }=useBranding(); return <div className="portal-title"><div><p><Link href="/member"><LayoutDashboard/>{branding.portalName}</Link><ChevronRight/>{tr(title,bn)}</p><h1>{tr(title,bn)}</h1>{body&&<span>{tr(body,bodyBn||body)}</span>}</div>{action}</div>
}

function MemberQuickActions() {
  const { tr } = useI18n();
  const actions = [
    { href: "/member/payments", icon: CreditCard, label: tr("Pay club fee", "ক্লাব ফি দিন"), note: tr("৳500 due", "৳৫০০ বকেয়া"), tone: "lime" },
    { href: "/member/team", icon: Goal, label: tr("View lineup", "লাইনআপ দেখুন"), note: "4-3-3 • KPL", tone: "blue" },
    { href: "/member/fixtures", icon: CalendarDays, label: tr("Next fixture", "পরবর্তী ফিক্সচার"), note: tr("28 June • 4:30 PM", "২৮ জুন • ৪:৩০"), tone: "orange" },
    { href: "/", icon: House, label: tr("Public home", "পাবলিক হোম"), note: tr("Visit club website", "ক্লাব ওয়েবসাইট"), tone: "violet" },
  ];
  return <div className="member-quick-actions">{actions.map(action=>{const Icon=action.icon;return <Link href={action.href} key={action.href}><span className={action.tone}><Icon/></span><div><b>{action.label}</b><small>{action.note}</small></div><ChevronRight/></Link>})}</div>;
}

function PlayerSeasonPulse() {
  const { tr } = useI18n();
  return <Panel className="player-season-pulse"><div className="season-pulse-head"><div><small>{tr("MY 2025 SEASON", "আমার ২০২৫ মৌসুম")}</small><h3>{tr("Player performance", "খেলোয়াড় পারফরম্যান্স")}</h3></div><span><TrendingUp/> +12%</span></div><div className="season-number-grid"><div><strong>18</strong><span>{tr("Matches", "ম্যাচ")}</span></div><div><strong>06</strong><span>{tr("Goals", "গোল")}</span></div><div><strong>11</strong><span>{tr("Assists", "অ্যাসিস্ট")}</span></div><div><strong>8.7</strong><span>{tr("Rating", "রেটিং")}</span></div></div><div className="attendance-progress"><div><span><Dumbbell/>{tr("Training attendance", "অনুশীলন উপস্থিতি")}</span><b>92%</b></div><i><span/></i><small>{tr("Excellent consistency — keep it going!", "দারুণ ধারাবাহিকতা—এভাবেই এগিয়ে যান!")}</small></div></Panel>;
}

function MemberWeekPlan() {
  const { tr } = useI18n();
  const plan = [
    { day: tr("THU", "বৃহঃ"), date: "20", title: tr("Team training", "দলীয় অনুশীলন"), time: "5:00 PM", icon: Dumbbell, active: true },
    { day: tr("FRI", "শুক্র"), date: "21", title: tr("Recovery session", "রিকভারি সেশন"), time: "4:30 PM", icon: Zap, active: false },
    { day: tr("SAT", "শনি"), date: "22", title: tr("Tactical meeting", "ট্যাকটিক্যাল মিটিং"), time: "7:00 PM", icon: Target, active: false },
  ];
  return <Panel title={tr("My week", "আমার সপ্তাহ")} action={<Link className="panel-link" href="/member/fixtures">{tr("Full calendar", "সম্পূর্ণ ক্যালেন্ডার")}<ChevronRight/></Link>} className="member-week-plan"><div>{plan.map(item=>{const Icon=item.icon;return <article className={item.active?"active":""} key={item.title}><time><small>{item.day}</small><b>{item.date}</b></time><span><Icon/></span><div><b>{item.title}</b><small><Clock3/>{item.time}</small></div>{item.active&&<em>{tr("NEXT", "পরবর্তী")}</em>}</article>})}</div></Panel>;
}

function MemberHome() {
  const { tr } = useI18n();
  const { branding } = useBranding();
  const { member } = useMemberSession();
  const homeNotices = useMemberNotices();
  const firstName = (member?.fullName || "").split(" ")[0] || tr("Member","সদস্য");
  return <><PortalTitle title="Dashboard" bn="ড্যাশবোর্ড" body={`Welcome back${member?", "+firstName+".":"."} Here is what is happening at your club.`} bodyBn={`স্বাগতম${member?", "+firstName+"।":"।"} আপনার ক্লাবের সর্বশেষ অবস্থা দেখুন।`}/>
    <section className="member-welcome" style={{backgroundImage:`linear-gradient(90deg,rgba(3,30,20,.98),rgba(3,30,20,.6),rgba(3,30,20,.25)),url(${images.action})`}}><div className="member-welcome-copy"><span><i/> {tr("ACTIVE PLAYER / MEMBER","সক্রিয় খেলোয়াড় / সদস্য")}</span><h2>{tr("WELCOME,","স্বাগতম,")}<br/>{firstName.toUpperCase()}!</h2><p>{tr("Stay ready, stay Fantastic.","প্রস্তুত থাকুন, ফ্যান্টাস্টিক থাকুন।")}</p><div><Button href="/member/team">{tr("View team lineup","দলের লাইনআপ দেখুন")}</Button><Button href="/" variant="ghost"><House/>{tr("Club home page","ক্লাব হোম পেজ")}</Button></div></div><div className="member-welcome-side"><div className="member-card-mini"><Avatar src={member?.profilePhoto||undefined} name={member?.fullName||"Member"}/><div><small>{tr("PLAYER / MEMBER ID", "খেলোয়াড় / সদস্য আইডি")}</small><b>{member?.memberId||"—"}</b><span>{member?.jerseyNumber?`#${member.jerseyNumber} • `:""}{member?.position||""}</span></div><ShieldCheck/></div></div></section>
    <MemberQuickActions/>
    <div className="portal-stat-grid"><StatCard icon={BadgeCheck} label={tr("My membership","আমার সদস্যপদ")} value={member?.status==="ACTIVE"?tr("Active","সক্রিয়"):(member?.status||"—")} href="/member/profile"/><StatCard icon={CircleDollarSign} label={tr("My dues","আমার বকেয়া")} value="৳ 0" tone="orange" href="/member/payments"/><StatCard icon={Users} label={tr("Active members","সক্রিয় সদস্য")} value="—" tone="blue" href="/member/members"/><StatCard icon={Trophy} label={tr("Current tournament","চলমান টুর্নামেন্ট")} value="—" tone="violet" href="/member/tournaments"/></div>
    <div className="member-dashboard-feature-grid"><PlayerSeasonPulse/><MemberWeekPlan/></div>
    <div className="portal-two-col"><Panel title={tr("Next match","পরবর্তী ম্যাচ")} action={<Link className="panel-link" href="/member/fixtures">{tr("All fixtures","সব ফিক্সচার")}<ArrowMini/></Link>}><div className="member-next-match"><p className="empty-inline">{tr("No upcoming match scheduled yet.","এখনো কোনো ম্যাচ নির্ধারিত হয়নি।")}</p></div></Panel><Panel title={tr("My payment summary","আমার পেমেন্ট সারাংশ")} action={<Link className="panel-link" href="/member/payment-history">{tr("History","ইতিহাস")}<ArrowMini/></Link>}><div className="payment-summary"><div><p><span className="green-dot"/>{tr("Paid this year","এ বছর পরিশোধ")}<b>৳ 0</b></p><p><span className="orange-dot"/>{tr("Outstanding","বকেয়া")}<b>৳ 0</b></p><Button href="/member/payments" variant="dark">{tr("Pay now","এখন পরিশোধ")}</Button></div></div></Panel></div>
    <div className="portal-two-col lower"><Panel title={tr("Latest updates","সর্বশেষ আপডেট")} action={<Link className="panel-link" href="/member/notifications">{tr("View all","সব দেখুন")}<ArrowMini/></Link>}><div className="announcement-list">{homeNotices.length===0?<p className="notice-empty">{tr("No updates yet — this fills in as things happen on your account.","এখনো কোনো আপডেট নেই — আপনার অ্যাকাউন্টে কিছু ঘটলে এখানে দেখা যাবে।")}</p>:homeNotices.map((n,i)=><Link href="/member/payment-history" key={n.id}><span className={`notice-icon n${i%3}`}><Megaphone/></span><div><b>{tr(n.title,n.titleBn)}</b><p>{n.body}</p><small>{n.time}</small></div><ChevronRight/></Link>)}</div></Panel><Panel title={tr("Club at a glance","এক নজরে ক্লাব")}><div className="glance-grid"><Link href="/member/finance"><ChartNoAxesCombined/><span><b>৳ 0</b>{tr("Current balance","বর্তমান ব্যালেন্স")}</span></Link><Link href="/member/fund"><Landmark/><span><b>৳ 0</b>{tr("Total fund","মোট তহবিল")}</span></Link><Link href="/member/matches"><Swords/><span><b>0</b>{tr("Matches played","ম্যাচ খেলা")}</span></Link><Link href="/member/news"><Newspaper/><span><b>0</b>{tr("Club stories","ক্লাব সংবাদ")}</span></Link></div></Panel></div>
  </>;
}
function ArrowMini(){return <ChevronRight size={15}/>}

function ProfilePage(){
  const {tr}=useI18n();
  const {member}=useMemberSession();
  const [edit,setEdit]=useState(false);
  const [saved,setSaved]=useState(false);
  const [localPhoto,setLocalPhoto]=useState<string|null>(null);
  function upload(e:ChangeEvent<HTMLInputElement>){const file=e.target.files?.[0];if(file){const reader=new FileReader();reader.onload=()=>setLocalPhoto(String(reader.result||""));reader.readAsDataURL(file)}}
  const photo=localPhoto||member?.profilePhoto||undefined;
  const fields:[string,string,string][]=[["Full name","পূর্ণ নাম",member?.fullName||"—"],["Member ID","সদস্য আইডি",member?.memberId||"—"],["Email","ইমেইল",member?.email||"—"],["Jersey number","জার্সি নম্বর",member?.jerseyNumber?String(member.jerseyNumber):"—"],["Position","পজিশন",member?.position||"—"]];
  return <><PortalTitle title="My Profile" bn="আমার প্রোফাইল" body="Manage your personal and playing information." bodyBn="ব্যক্তিগত ও খেলার তথ্য পরিচালনা করুন।" action={<Button onClick={()=>{if(edit)setSaved(true);setEdit(!edit)}} icon={false}>{edit?tr("Save changes","পরিবর্তন সংরক্ষণ"):tr("Edit profile","প্রোফাইল সম্পাদনা")}</Button>}/>{saved&&<div className="portal-alert success"><CheckCircle2/>{tr("Profile changes saved successfully.","প্রোফাইলের পরিবর্তন সফলভাবে সংরক্ষিত হয়েছে।")}</div>}<div className="profile-layout"><Panel className="profile-photo-panel"><div className="profile-cover"/><div className="profile-photo">{photo?<img src={photo} alt="Profile"/>:<Avatar name={member?.fullName||"Member"} size="lg"/>}<label><Upload/><input type="file" accept="image/*" onChange={upload}/></label></div><h2>{member?.fullName||tr("Loading...","লোড হচ্ছে...")}</h2><span>{member?.memberId}</span><StatusPill status={member?.status||"ACTIVE"}/><div className="profile-actions"><label className="btn btn-outline"><ImageIcon/>{tr("Change photo","ছবি বদলান")}<input type="file" accept="image/*" onChange={upload}/></label><button onClick={()=>setLocalPhoto("")}>{tr("Remove","মুছুন")}</button></div><small>{tr("JPG or PNG. Maximum 5 MB.","JPG বা PNG। সর্বোচ্চ ৫ এমবি।")}</small></Panel><Panel title={tr("Personal information","ব্যক্তিগত তথ্য")} className="profile-details"><div className="profile-field-grid">{fields.map((f)=><label key={f[0]}>{tr(f[0],f[1])}{edit?<input defaultValue={f[2]}/>:<span>{f[2]}</span>}</label>)}</div><div className="profile-meta"><div><ShieldCheck/><span><b>{tr("Verified member","যাচাইকৃত সদস্য")}</b>{tr("Approved by club admin","ক্লাব অ্যাডমিন কর্তৃক অনুমোদিত")}</span></div></div></Panel></div></>
}
function TeamPage(){
  const {tr}=useI18n();
  const [squad,setSquad]=useState<Array<{id:string;name:string;jersey:number;position:string;photo:string|null}>>([]);
  const [lineupTitle,setLineupTitle]=useState("");
  useEffect(()=>{void (async()=>{
    try{
      const [squadRes,lineupRes]=await Promise.all([fetch("/api/squad",{cache:"no-store"}),fetch("/api/lineup",{cache:"no-store"})]);
      const squadData=await squadRes.json() as {squad?:Array<{id:string;name:string;jersey:number;position:string;photo:string|null}>};
      setSquad(squadData.squad||[]);
      const lineupData=await lineupRes.json() as {lineup?:{matchTitle:string;formation:string}|null};
      if(lineupData.lineup)setLineupTitle(`${lineupData.lineup.matchTitle} • ${lineupData.lineup.formation}`);
    }catch{ /* best-effort */ }
  })()},[]);
  return <><PortalTitle title="Our Team" bn="আমাদের দল" body="Official matchday lineup and active squad." bodyBn="অফিসিয়াল ম্যাচডে লাইনআপ ও সক্রিয় স্কোয়াড।"/><div className="member-lineup"><Panel><div className="lineup-info"><span>{tr("STARTING XI","প্রথম একাদশ")}</span><h2>{lineupTitle||tr("Lineup not published yet","লাইনআপ এখনো প্রকাশিত হয়নি")}</h2></div><Pitch/></Panel><Panel title={tr("Squad list","স্কোয়াড তালিকা")} className="squad-panel">{squad.length===0?<p style={{padding:"12px 4px",color:"var(--muted)"}}>{tr("No squad players published yet.","এখনো কোনো স্কোয়াড খেলোয়াড় প্রকাশিত হয়নি।")}</p>:<div className="squad-list">{squad.map(p=><div key={p.id}><Avatar src={p.photo||""} name={p.name}/><span><b>{p.name}</b><small>{p.position}</small></span><strong>#{p.jersey}</strong></div>)}</div>}</Panel></div></>;
}
function MembersPage(){
  const {tr}=useI18n();const [search,setSearch]=useState("");
  const [squad,setSquad]=useState<Array<{id:string;memberCode:string;name:string;jersey:number;position:string;photo:string|null}>>([]);
  useEffect(()=>{void (async()=>{try{const res=await fetch("/api/squad",{cache:"no-store"});const data=await res.json() as {squad?:typeof squad};setSquad(data.squad||[])}catch{ /* best-effort */ }})()},[]);
  const list=squad.filter(p=>p.name.toLowerCase().includes(search.toLowerCase()));
  return <><PortalTitle title="Members" bn="সদস্যবৃন্দ" body="Connect with the active Fantastic FC family." bodyBn="ফ্যান্টাস্টিক এফসির সক্রিয় পরিবারের সঙ্গে যুক্ত থাকুন।"/><div className="toolbar"><div className="search-box"><Search/><input placeholder={tr("Search members...","সদস্য খুঁজুন...")} value={search} onChange={e=>setSearch(e.target.value)}/></div><span>{list.length} {tr("active members","সক্রিয় সদস্য")}</span></div>{list.length===0?<p style={{padding:"12px 4px",color:"var(--muted)"}}>{tr("No squad players published yet.","এখনো কোনো স্কোয়াড খেলোয়াড় প্রকাশিত হয়নি।")}</p>:<div className="member-directory">{list.map(p=><Panel key={p.id}><Avatar src={p.photo||""} name={p.name} size="lg"/><StatusPill status="ACTIVE"/><h3>{p.name}</h3><p>{p.memberCode}</p><div><span>#{p.jersey}<small>{tr("JERSEY","জার্সি")}</small></span><span>{p.position.slice(0,3)}<small>{tr("POSITION","পজিশন")}</small></span></div></Panel>)}</div>}</>;
}

function SportsPage({kind}:{kind:"matches"|"fixtures"|"tournaments"}){const {tr}=useI18n();if(kind==="tournaments")return <><PortalTitle title="Tournaments" bn="টুর্নামেন্ট" body="Competition progress and tournament information." bodyBn="প্রতিযোগিতার অগ্রগতি ও টুর্নামেন্ট তথ্য।"/><Panel><div className="tournament-member-banner" style={{backgroundImage:`linear-gradient(90deg,rgba(3,27,18,.95),rgba(3,27,18,.3)),url(${images.action})`}}><Trophy/><span>ACTIVE TOURNAMENT</span><h2>KULANANDAPUR PREMIER LEAGUE 2025</h2><p>Group A • Matchday 03 • Fantastic FC currently 2nd</p></div></Panel><Panel title={tr("Group A standings","গ্রুপ এ পয়েন্ট টেবিল")}><table className="data-table"><thead><tr><th>#</th><th>{tr("CLUB","ক্লাব")}</th><th>P</th><th>W</th><th>D</th><th>L</th><th>GD</th><th>PTS</th></tr></thead><tbody>{[["Unity Club",3,2,1,0,4,7],["Fantastic FC",2,2,0,0,4,6],["Green Warriors",2,1,0,1,1,3],["Thunder Eleven",3,0,1,2,-4,1]].map((r,i)=><tr className={i===1?"highlight":""} key={String(r[0])}><td>{i+1}</td><td><b>{r[0]}</b></td>{r.slice(1).map((x,j)=><td key={j}>{x}</td>)}</tr>)}</tbody></table></Panel></>;return <><PortalTitle title={kind==="matches"?"Matches":"Fixtures"} bn={kind==="matches"?"ম্যাচ":"ফিক্সচার"} body="Official fixtures and match information." bodyBn="অফিসিয়াল ফিক্সচার ও ম্যাচের তথ্য।"/><div className="member-fixtures">{fixtures.map(f=><Panel key={f.date}><div className="fixture-date"><b>{f.date}</b><span>{f.month}</span></div><div><small>{f.competition}</small><h3>{f.home} <em>VS</em> {f.away}</h3><p><Clock3/> {f.time} <MapPin/> {f.venue}</p></div><StatusPill status="UPCOMING"/></Panel>)}</div></>}

function PaymentPage(){
  const {tr}=useI18n();
  const {member}=useMemberSession();
  const fees=[{name:"Monthly fee — June",bn:"মাসিক ফি — জুন",amount:500,icon:CalendarDays,jersey:false},{name:"Tournament fee",bn:"টুর্নামেন্ট ফি",amount:1000,icon:Trophy,jersey:false},{name:"Jersey payment",bn:"জার্সি পেমেন্ট",amount:850,icon:Shirt,jersey:true}];
  const [fee,setFee]=useState(fees[0]);const [methods,setMethods]=useState<{id:string;name:string;accountNumber:string;accountName:string}[]>([]);const [method,setMethod]=useState<{id:string;name:string;accountNumber:string;accountName:string}|null>(null);useEffect(()=>{fetch("/api/payment-methods",{cache:"no-store"}).then(r=>r.json()).then((d:{methods?:typeof methods})=>{const list=d.methods||[];setMethods(list);setMethod(list[0]||null)}).catch(()=>{})},[]);const [copied,setCopied]=useState(false);const [screenshot,setScreenshot]=useState("");const [loading,setLoading]=useState(false);const [message,setMessage]=useState<{type:"success"|"error";text:string}|null>(null);
  const [jerseySize,setJerseySize]=useState("M");const [printName,setPrintName]=useState("");const [jerseyNum,setJerseyNum]=useState(member?.jerseyNumber||1);
  const sizes=["XS","S","M","L","XL","XXL","XXXL","Custom"];
  function selectProof(event:ChangeEvent<HTMLInputElement>){const file=event.target.files?.[0];setMessage(null);if(!file)return;if(file.size>1_500_000){setMessage({type:"error",text:tr("Image must be under 1.5 MB.","ছবি ১.৫ এমবির কম হতে হবে।")});event.target.value="";return}const reader=new FileReader();reader.onload=()=>setScreenshot(String(reader.result||""));reader.readAsDataURL(file)}
  async function submit(event:FormEvent<HTMLFormElement>){event.preventDefault();if(!screenshot){setMessage({type:"error",text:tr("Upload the payment screenshot.","পেমেন্ট স্ক্রিনশট আপলোড করুন।")});return}if(!member){setMessage({type:"error",text:tr("Please sign in again.","আবার সাইন ইন করুন।")});return}if(!method){setMessage({type:"error",text:tr("Select a payment method.","পেমেন্ট মাধ্যম বাছুন।")});return}setLoading(true);setMessage(null);const form=event.currentTarget;const data=new FormData(form);const feeType=fee.jersey?`Jersey: ${printName} #${jerseyNum} (${jerseySize})`:fee.name;try{if(fee.jersey){await fetch("/api/jersey-order",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({memberCode:member.memberId,memberName:member.fullName,size:jerseySize,jerseyNumber:jerseyNum,printName,quantity:1})})}const response=await fetch("/api/payments",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({memberCode:member.memberId,feeType,amount:Number(data.get("amount")),methodName:method.name,transactionId:String(data.get("transactionId")),screenshot})});const result=await response.json() as {message:string;paymentId?:string};setMessage({type:response.ok?"success":"error",text:response.ok?`${result.message} ID: ${result.paymentId?.slice(0,8).toUpperCase()}`:result.message});if(response.ok){form.reset();setScreenshot("")}}catch{setMessage({type:"error",text:tr("Unable to submit payment.","পেমেন্ট জমা দেওয়া যায়নি।")})}finally{setLoading(false)}}
  return <><PortalTitle title="Make Payment" bn="পেমেন্ট করুন" body="Submit club fees securely. Select Jersey payment to configure your size and print name." bodyBn="নিরাপদে ক্লাব ফি জমা দিন। জার্সি পেমেন্ট বাছলে সাইজ ও প্রিন্ট নাম দিতে পারবেন।"/><div className="payment-layout"><Panel title={tr("1. Select fee","১. ফি বাছুন")}><div className="fee-options">{fees.map(item=>{const Icon=item.icon;return <label key={item.name}><input type="radio" name="fee-choice" checked={fee.name===item.name} onChange={()=>setFee(item)}/><span><Icon/><b>{tr(item.name,item.bn)}</b><strong>৳ {item.amount.toLocaleString()}</strong></span></label>})}</div>{fee.jersey&&<div className="jersey-inline-config"><div className="jersey-inline-preview"><Shirt/><span className="jersey-inline-num">{jerseyNum}</span><span className="jersey-inline-name">{printName}</span></div><div className="jersey-inline-fields"><label>{tr("Jersey size","জার্সি সাইজ")}<div className="size-grid">{sizes.map(sz=><button type="button" key={sz} className={jerseySize===sz?"active":""} onClick={()=>setJerseySize(sz)}>{sz}</button>)}</div></label><label>{tr("Print name","প্রিন্ট নাম")}<input value={printName} maxLength={18} onChange={e=>setPrintName(e.target.value.toUpperCase())} placeholder="e.g. SHAKIL"/></label><label>{tr("Jersey number","জার্সি নম্বর")}<input type="number" min={1} max={99} value={jerseyNum} onChange={e=>setJerseyNum(Number(e.target.value))}/></label></div></div>}</Panel><Panel title={tr("2. Select payment method","২. পেমেন্ট মাধ্যম বাছুন")}>{methods.length===0?<p className="empty-inline">{tr("No payment methods available yet.","এখনো কোনো পেমেন্ট মাধ্যম নেই।")}</p>:<><div className="method-options">{methods.map(m=><button className={method?.id===m.id?"active":""} key={m.id} onClick={()=>setMethod(m)}><PaymentLogo name={m.name}/><b>{m.name}</b>{method?.id===m.id&&<CheckCircle2/>}</button>)}</div>{method&&<div className="method-detail"><PaymentLogo name={method.name} compact/><div><span>{tr("Send money to","এই নম্বরে সেন্ড মানি করুন")}</span><b>{method.accountNumber}</b><small>{tr("Account","অ্যাকাউন্ট")}: {method.accountName}</small></div><button onClick={()=>{navigator.clipboard?.writeText(method.accountNumber);setCopied(true)}}>{copied?tr("Copied","কপি হয়েছে"):tr("Copy","কপি")}</button></div>}</>}</Panel><Panel title={tr("3. Submit payment proof","৩. পেমেন্ট প্রমাণ জমা দিন")}><form className="payment-proof" onSubmit={submit}><label>{tr("Transaction ID","ট্রানজ্যাকশন আইডি")}<input name="transactionId" required minLength={5} placeholder="e.g. 9A7B2KLP"/></label><label>{tr("Amount","পরিমাণ")}<input name="amount" required type="number" min="1" value={fee.amount} onChange={event=>setFee({...fee,amount:Number(event.target.value)})}/></label><label className="full upload-box"><Upload/><b>{tr("Upload payment screenshot","পেমেন্ট স্ক্রিনশট আপলোড")}</b><span>{screenshot?tr("Proof selected and ready","প্রমাণ নির্বাচন হয়েছে"):"PNG, JPG • Max 1.5 MB"}</span><input type="file" accept="image/png,image/jpeg" onChange={selectProof} required={!screenshot}/></label>{screenshot&&<img className="payment-proof-preview full" src={screenshot} alt="Private payment proof preview"/>}<div className="full"><FormMessage state={message}/></div><Button type="submit" disabled={loading}>{loading?tr("Submitting...","জমা হচ্ছে..."):tr("Submit for verification","যাচাইয়ের জন্য জমা দিন")}</Button></form></Panel></div></>;
}

function PaymentHistory(){
  const {tr}=useI18n();
  const {payments,loading}=useMemberPayments();
  const [filter,setFilter]=useState("ALL");
  const rows=filter==="ALL"?payments:payments.filter(p=>p.status===filter);
  const totalPaid=payments.filter(p=>p.status==="PAID").reduce((a,p)=>a+Number(p.amount),0);
  const totalPending=payments.filter(p=>p.status==="PENDING").reduce((a,p)=>a+Number(p.amount),0);
  return <><PortalTitle title="Payment History" bn="পেমেন্ট ইতিহাস" body="Track all submitted and verified club payments." bodyBn="সব জমাকৃত ও যাচাইকৃত ক্লাব পেমেন্ট দেখুন।"/><div className="portal-stat-grid compact"><StatCard icon={CheckCircle2} label={tr("Total paid","মোট পরিশোধ")} value={`৳ ${totalPaid.toLocaleString()}`} tone="green"/><StatCard icon={Clock3} label={tr("Pending","অপেক্ষমাণ")} value={`৳ ${totalPending.toLocaleString()}`} tone="orange"/><StatCard icon={ReceiptText} label={tr("Transactions","লেনদেন")} value={String(payments.length)} tone="blue"/></div><Panel><div className="table-toolbar"><div className="filter-row small">{["ALL","PAID","PENDING","REJECTED"].map(x=><button className={filter===x?"active":""} onClick={()=>setFilter(x)} key={x}>{x}</button>)}</div><Button href="/member/payments" icon={false}>{tr("New payment","নতুন পেমেন্ট")}</Button></div>{loading?<p className="empty-inline">{tr("Loading...","লোড হচ্ছে...")}</p>:rows.length===0?<p className="empty-inline">{tr("No payments yet.","এখনো কোনো পেমেন্ট নেই।")}</p>:<table className="data-table"><thead><tr><th>{tr("DATE","তারিখ")}</th><th>{tr("FEE TYPE","ফি ধরন")}</th><th>{tr("METHOD","মাধ্যম")}</th><th>{tr("TRANSACTION ID","লেনদেন আইডি")}</th><th>{tr("AMOUNT","পরিমাণ")}</th><th>{tr("STATUS","অবস্থা")}</th></tr></thead><tbody>{rows.map(r=><tr key={r.id}><td>{new Date(r.createdAt).toLocaleDateString()}</td><td>{r.feeType}</td><td>{r.method}</td><td><b>{r.transactionId}</b></td><td><b>৳ {Number(r.amount).toLocaleString()}</b></td><td><StatusPill status={r.status}/></td></tr>)}</tbody></table>}</Panel></>
}

function FinancePage({fund=false}:{fund?:boolean}){
  const {tr}=useI18n();
  const [entries,setEntries]=useState<Array<{id:string;title:string;category:string;income:string;expense:string;createdAt:string}>>([]);
  const [pendingDuesTotal,setPendingDuesTotal]=useState(0);
  const [loading,setLoading]=useState(true);
  useEffect(()=>{void (async()=>{setLoading(true);try{const res=await fetch("/api/finance-summary",{cache:"no-store"});const data=await res.json() as {entries?:typeof entries;pendingDuesTotal?:number};setEntries(data.entries||[]);setPendingDuesTotal(data.pendingDuesTotal||0)}catch{ /* best-effort */ }finally{setLoading(false)}})()},[]);
  const total=entries.reduce((a,x)=>a+Number(x.income),0),expense=entries.reduce((a,x)=>a+Number(x.expense),0);
  return <><PortalTitle title={fund?"Club Fund":"Club Finance"} bn={fund?"ক্লাব ফান্ড":"ক্লাব ফাইন্যান্স"} body="Transparent, verified financial information for club members." bodyBn="ক্লাব সদস্যদের জন্য স্বচ্ছ ও যাচাইকৃত আর্থিক তথ্য।"/><div className="portal-stat-grid"><StatCard icon={HandCoins} label={tr("Verified collection","যাচাইকৃত সংগ্রহ")} value={`৳ ${total.toLocaleString()}`} tone="green"/><StatCard icon={ReceiptText} label={tr("Verified expense","যাচাইকৃত খরচ")} value={`৳ ${expense.toLocaleString()}`} tone="red"/><StatCard icon={Landmark} label={tr("Current balance","বর্তমান ব্যালেন্স")} value={`৳ ${(total-expense).toLocaleString()}`} tone="blue"/><StatCard icon={CircleDollarSign} label={tr("Pending dues","অপেক্ষমান বকেয়া")} value={`৳ ${pendingDuesTotal.toLocaleString()}`} tone="orange"/></div><div className="finance-rule"><ShieldCheck/><div><b>{tr("How balance is calculated","ব্যালেন্স কীভাবে হিসাব হয়")}</b><span>{tr("Verified Income − Verified Expense = Current Balance","যাচাইকৃত আয় − যাচাইকৃত খরচ = বর্তমান ব্যালেন্স")}</span></div></div><Panel title={tr(fund?"Fund statement":"Monthly financial statement",fund?"তহবিল বিবরণী":"মাসিক আর্থিক বিবরণী")}>{loading?<div className="empty-table"><RefreshCw className="spin"/><b>{tr("Loading...","লোড হচ্ছে...")}</b></div>:entries.length===0?<div className="empty-table"><Landmark/><b>{tr("No records yet","এখনো কোনো রেকর্ড নেই")}</b></div>:<table className="data-table"><thead><tr><th>{tr("TITLE","শিরোনাম")}</th><th>{tr("COLLECTION","সংগ্রহ")}</th><th>{tr("EXPENSE","খরচ")}</th><th>{tr("NET BALANCE","নিট ব্যালেন্স")}</th><th>{tr("VERIFICATION","যাচাই")}</th></tr></thead><tbody>{entries.map(r=><tr key={r.id}><td><b>{r.title}</b></td><td className="money-in">{Number(r.income)>0?`+ ৳ ${Number(r.income).toLocaleString()}`:"—"}</td><td className="money-out">{Number(r.expense)>0?`− ৳ ${Number(r.expense).toLocaleString()}`:"—"}</td><td><b>৳ {(Number(r.income)-Number(r.expense)).toLocaleString()}</b></td><td><StatusPill status="VERIFIED"/></td></tr>)}</tbody></table>}</Panel></>;
}

function MemberJerseyOrder() {
  const { tr } = useI18n();
  const { member } = useMemberSession();
  const [size, setSize] = useState("M");
  const [printName, setPrintName] = useState("");
  const [jerseyNum, setJerseyNum] = useState(1);
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [orders, setOrders] = useState<Array<{ id: string; memberCode?: string; size: string; printName: string; jerseyNumber: number; quantity: number; unitPrice: number; status: string; createdAt: string }>>([]);
  const unitPrice = 850;
  const sizes = ["XS", "S", "M", "L", "XL", "XXL", "XXXL", "Custom"];

  useEffect(() => { if (member?.jerseyNumber) setJerseyNum(member.jerseyNumber); }, [member]);

  function loadOrders() { if (!member) return; fetch("/api/jersey-order", { cache: "no-store" }).then(r => r.json()).then((d: { orders?: typeof orders }) => { if (d.orders) setOrders(d.orders.filter(o => o.memberCode === member.memberId)); }).catch(() => { /* keep empty */ }); }
  useEffect(() => { loadOrders(); }, [member]);

  async function submit(e: FormEvent) {
    e.preventDefault(); setLoading(true); setMessage(null);
    if (!member) { setMessage({ type: "error", text: tr("Please sign in again.","আবার সাইন ইন করুন।") }); setLoading(false); return; }
    try {
      const res = await fetch("/api/jersey-order", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ memberCode: member.memberId, memberName: member.fullName, size, jerseyNumber: jerseyNum, printName, quantity }) });
      const data = await res.json() as { message: string };
      setMessage({ type: res.ok ? "success" : "error", text: data.message });
      if (res.ok) loadOrders();
    } catch { setMessage({ type: "error", text: tr("Unable to submit order.", "অর্ডার দেওয়া যায়নি।") }); }
    finally { setLoading(false); }
  }

  return <><PortalTitle title="Jersey Order" bn="জার্সি অর্ডার" body="Select your size, print name and quantity. Admin will review and confirm." bodyBn="আপনার সাইজ, প্রিন্ট নাম ও পরিমাণ বাছুন। অ্যাডমিন যাচাই করে নিশ্চিত করবেন।"/>
    <div className="jersey-order-layout">
      <Panel className="jersey-preview-panel">
        <div className="jersey-preview">
          <div className="jersey-shirt"><Shirt/><span className="jersey-number-display">{jerseyNum}</span><span className="jersey-name-display">{printName}</span></div>
          <div className="jersey-summary"><h3>{printName} <em>#{jerseyNum}</em></h3><p>{tr("Size","সাইজ")}: <b>{size}</b> • {tr("Qty","পরিমাণ")}: <b>{quantity}</b></p><div className="jersey-total"><span>{tr("TOTAL","মোট")}</span><strong>৳ {(unitPrice * quantity).toLocaleString()}</strong></div></div>
        </div>
      </Panel>
      <Panel title={tr("Configure your jersey","আপনার জার্সি কনফিগার করুন")}>
        <form className="jersey-form" onSubmit={submit}>
          <label>{tr("Select size","সাইজ বাছুন")}<div className="size-grid">{sizes.map(s=><button type="button" key={s} className={size===s?"active":""} onClick={()=>setSize(s)}>{s}</button>)}</div></label>
          <label>{tr("Name to print on jersey","জার্সিতে প্রিন্ট করার নাম")}<input value={printName} maxLength={18} required onChange={e=>setPrintName(e.target.value.toUpperCase())} placeholder="e.g. SHAKIL"/></label>
          <div className="form-grid"><label>{tr("Jersey number","জার্সি নম্বর")}<input type="number" min={1} max={99} value={jerseyNum} required onChange={e=>setJerseyNum(Number(e.target.value))}/></label><label>{tr("Quantity","পরিমাণ")}<input type="number" min={1} max={10} value={quantity} onChange={e=>setQuantity(Number(e.target.value))}/></label></div>
          <div className="jersey-price-note"><ShieldCheck/><div><b>{tr("Unit price","একক মূল্য")}: ৳ {unitPrice}</b><small>{tr("Admin reviews every order before processing.","প্রসেসিংয়ের আগে অ্যাডমিন প্রতিটি অর্ডার যাচাই করেন।")}</small></div></div>
          <FormMessage state={message}/>
          <Button type="submit" disabled={loading} icon={false}><Shirt/>{loading ? tr("Submitting...","জমা হচ্ছে...") : tr("Submit jersey order","জার্সি অর্ডার দিন")}</Button>
        </form>
      </Panel>
    </div>
    {orders.length > 0 && <Panel title={tr("My orders","আমার অর্ডারসমূহ")} className="jersey-orders-table"><table className="data-table"><thead><tr><th>{tr("ORDER","অর্ডার")}</th><th>{tr("SIZE","সাইজ")}</th><th>{tr("PRINT","প্রিন্ট")}</th><th>#</th><th>{tr("QTY","পরিমাণ")}</th><th>{tr("TOTAL","মোট")}</th><th>{tr("STATUS","অবস্থা")}</th></tr></thead><tbody>{orders.map(o=><tr key={o.id}><td><b>{o.id}</b><small className="table-sub">{new Date(o.createdAt).toLocaleDateString()}</small></td><td><span className="size-badge">{o.size}</span></td><td><b>{o.printName}</b></td><td>#{o.jerseyNumber}</td><td>{o.quantity}</td><td><b>৳ {(o.quantity * o.unitPrice).toLocaleString()}</b></td><td><StatusPill status={o.status}/></td></tr>)}</tbody></table></Panel>}
  </>;
}

function ChangePasswordModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { tr } = useI18n();
  const { member } = useMemberSession();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setLoading(true); setMessage(null);
    if (!member) { setMessage({ type: "error", text: tr("Please sign in again.","আবার সাইন ইন করুন।") }); setLoading(false); return; }
    const data = new FormData(e.currentTarget);
    try {
      const res = await fetch("/api/change-password", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ memberCode: member.memberId, currentPassword: data.get("currentPassword"), newPassword: data.get("newPassword"), confirmPassword: data.get("confirmPassword") }) });
      const result = await res.json() as { message: string };
      setMessage({ type: res.ok ? "success" : "error", text: result.message });
      if (res.ok) { e.currentTarget.reset(); setTimeout(onClose, 1500); }
    } catch { setMessage({ type: "error", text: tr("Unable to change password.", "পাসওয়ার্ড পরিবর্তন করা যায়নি।") }); }
    finally { setLoading(false); }
  }

  if (!open) return null;
  return <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && onClose()}><div className="modal-card" role="dialog"><button className="modal-close" onClick={onClose}><X/></button><form className="modal-form" onSubmit={submit}><span className="modal-icon"><Lock/></span><h2>{tr("Change password", "পাসওয়ার্ড পরিবর্তন")}</h2><p>{tr("Enter your current password and choose a strong new one.", "বর্তমান পাসওয়ার্ড দিন এবং শক্তিশালী নতুন পাসওয়ার্ড বাছুন।")}</p>
    <label>{tr("Current password", "বর্তমান পাসওয়ার্ড")}<div className="password-input"><input name="currentPassword" type={showCurrent ? "text" : "password"} required minLength={8}/><button type="button" onClick={() => setShowCurrent(v => !v)}>{showCurrent ? <EyeOff/> : <Eye/>}</button></div></label>
    <label>{tr("New password", "নতুন পাসওয়ার্ড")}<div className="password-input"><input name="newPassword" type={showNew ? "text" : "password"} required minLength={8}/><button type="button" onClick={() => setShowNew(v => !v)}>{showNew ? <EyeOff/> : <Eye/>}</button></div></label>
    <label>{tr("Confirm new password", "নতুন পাসওয়ার্ড নিশ্চিত করুন")}<input name="confirmPassword" type="password" required minLength={8}/></label>
    <FormMessage state={message}/>
    <div className="modal-actions"><Button type="button" variant="outline" icon={false} onClick={onClose}>{tr("Cancel", "বাতিল")}</Button><Button type="submit" disabled={loading} icon={false}><KeyRound/>{loading ? tr("Changing...", "পরিবর্তন হচ্ছে...") : tr("Change password", "পাসওয়ার্ড পরিবর্তন")}</Button></div>
  </form></div></div>;
}

function ContentPage({kind}:{kind:"news"|"announcements"|"notifications"|"documents"|"settings"}){
  const {tr}=useI18n();const [pwModal,setPwModal]=useState(false);const isNotice=kind==="notifications";const liveNotices=useMemberNotices();
  const [newsItems,setNewsItems]=useState<Array<{id:string;title:string;category:string;excerpt:string;coverImage:string|null;createdAt:string}>>([]);
  const [newsLoading,setNewsLoading]=useState(true);
  useEffect(()=>{if(kind!=="news")return;let cancelled=false;(async()=>{setNewsLoading(true);try{const res=await fetch("/api/news",{cache:"no-store"});const data=await res.json() as {posts?:typeof newsItems};if(!cancelled)setNewsItems(data.posts||[])}catch{ /* best-effort */ }finally{if(!cancelled)setNewsLoading(false)}})();return()=>{cancelled=true}},[kind]);
  if(kind==="news")return <><PortalTitle title="Club News" bn="ক্লাব সংবাদ"/>{newsLoading?<div className="empty-table"><RefreshCw className="spin"/><b>{tr("Loading stories...","গল্প লোড হচ্ছে...")}</b></div>:newsItems.length===0?<div className="empty-table"><Newspaper/><b>{tr("No stories published yet","এখনো কোনো সংবাদ প্রকাশিত হয়নি")}</b></div>:<div className="portal-news-grid">{newsItems.map(n=><Panel key={n.id}>{n.coverImage&&<img src={n.coverImage} alt={n.title}/>}<small>{n.category} • {new Date(n.createdAt).toLocaleDateString()}</small><h3>{n.title}</h3><p>{n.excerpt}</p></Panel>)}</div>}</>;
  if(kind==="documents")return <><PortalTitle title="Documents" bn="ডকুমেন্ট" body="Private club files available to active members." bodyBn="সক্রিয় সদস্যদের জন্য ক্লাবের ব্যক্তিগত ফাইল।"/><Panel><div className="document-list">{documents.map(d=><div key={d.title}><span><FileText/></span><div><b>{d.title}</b><small>{d.category} • {d.type} • {d.size} • {d.date}</small></div><StatusPill status="MEMBERS ONLY"/><button><Download/>{tr("Download","ডাউনলোড")}</button></div>)}</div></Panel></>;
  if(kind==="settings")return <><PortalTitle title="Settings" bn="সেটিংস"/><div className="settings-grid"><Panel title={tr("Account security","অ্যাকাউন্ট নিরাপত্তা")}><div className="setting-row"><span><b>{tr("Change password","পাসওয়ার্ড পরিবর্তন")}</b><small>{tr("Enter current password and choose a new one","বর্তমান পাসওয়ার্ড দিন এবং নতুন পাসওয়ার্ড বাছুন")}</small></span><Button variant="outline" icon={false} onClick={()=>setPwModal(true)}><Lock/>{tr("Change","পরিবর্তন")}</Button></div><div className="setting-row"><span><b>{tr("Member PIN","সদস্য পিন")}</b><small>••••••</small></span><Button href="/forgot-pin" variant="outline" icon={false}><KeyRound/>{tr("Reset","রিসেট")}</Button></div></Panel><Panel title={tr("Notification preferences","নোটিফিকেশন পছন্দ")}><div className="toggle-row"><span><b>{tr("Match updates","ম্যাচ আপডেট")}</b><small>{tr("Squad and fixture notices","স্কোয়াড ও ফিক্সচার নোটিশ")}</small></span><input type="checkbox" defaultChecked/></div><div className="toggle-row"><span><b>{tr("Payment updates","পেমেন্ট আপডেট")}</b><small>{tr("Verification and dues","যাচাই ও বকেয়া")}</small></span><input type="checkbox" defaultChecked/></div></Panel></div><ChangePasswordModal open={pwModal} onClose={()=>setPwModal(false)}/></>;
  return <><PortalTitle title={isNotice?"Notifications":"Announcements"} bn={isNotice?"নোটিফিকেশন":"ঘোষণা"} body="Important updates from club administration." bodyBn="ক্লাব প্রশাসনের গুরুত্বপূর্ণ আপডেট।"/><Panel><div className="notification-page-list">{isNotice?(liveNotices.length===0?<p className="empty-inline">{tr("No notifications yet — you'll see updates here as soon as something happens on your account (like a payment being verified).","এখনো কোনো নোটিফিকেশন নেই — আপনার অ্যাকাউন্টে কিছু ঘটলে (যেমন পেমেন্ট যাচাই) এখানে দেখা যাবে।")}</p>:liveNotices.map(n=><Link href="/member/payment-history" key={n.id}><span className="unread"><Bell/></span><div><b>{tr(n.title,n.titleBn)}</b><p>{n.body}</p><small>{n.time}</small></div><ChevronRight/></Link>)):<p className="empty-inline">{tr("No announcements yet.","এখনো কোনো ঘোষণা নেই।")}</p>}</div></Panel></>;
}
function MemberMobileDock() {
  const path = usePathname(); const { tr } = useI18n();
  const links = [
    { href: "/", icon: House, en: "Home", bn: "হোম", public: true },
    { href: "/member", icon: LayoutDashboard, en: "Portal", bn: "পোর্টাল" },
    { href: "/member/payments", icon: CreditCard, en: "Pay", bn: "পেমেন্ট", primary: true },
    { href: "/member/team", icon: Goal, en: "Team", bn: "দল" },
    { href: "/member/profile", icon: UserRound, en: "Profile", bn: "প্রোফাইল" },
  ];
  return <nav className="member-mobile-dock" aria-label="Player member quick navigation">{links.map(link=>{const Icon=link.icon;return <Link href={link.href} key={link.href} className={`${link.primary?"primary ":""}${!link.public&&path===link.href?"active":""}`}><span><Icon/></span><small>{tr(link.en,link.bn)}</small></Link>})}</nav>;
}

function PortalContent(){const path=usePathname();if(path==="/member")return <MemberHome/>;if(path==="/member/profile")return <ProfilePage/>;if(path==="/member/team")return <TeamPage/>;if(path==="/member/members")return <MembersPage/>;if(path==="/member/matches")return <SportsPage kind="matches"/>;if(path==="/member/fixtures")return <SportsPage kind="fixtures"/>;if(path==="/member/tournaments")return <SportsPage kind="tournaments"/>;if(path==="/member/payments")return <PaymentPage/>;if(path==="/member/payment-history")return <PaymentHistory/>;if(path==="/member/finance")return <FinancePage/>;if(path==="/member/fund")return <FinancePage fund/>;if(path==="/member/news")return <ContentPage kind="news"/>;if(path==="/member/announcements")return <ContentPage kind="announcements"/>;if(path==="/member/notifications")return <ContentPage kind="notifications"/>;if(path==="/member/documents")return <ContentPage kind="documents"/>;return <ContentPage kind="settings"/>}

export function MemberPortal(){
  const [open,setOpen]=useState(false);
  const {branding}=useBranding();
  const [member,setMember]=useState<SessionMember|null>(null);
  const [sessionLoading,setSessionLoading]=useState(true);
  useEffect(()=>{(async()=>{try{const res=await fetch("/api/member/auth",{cache:"no-store"});const data=await res.json() as {authenticated:boolean;member?:SessionMember};setMember(data.authenticated&&data.member?data.member:null)}catch{setMember(null)}finally{setSessionLoading(false)}})()},[]);
  return <MemberSessionContext.Provider value={{member,loading:sessionLoading}}><div className="portal-shell"><PortalSidebar open={open} close={()=>setOpen(false)}/>{open&&<button className="sidebar-scrim" onClick={()=>setOpen(false)} aria-label="Close navigation"/>}<div className="portal-main"><PortalHeader openMenu={()=>setOpen(true)}/><main className="portal-content"><PortalContent/></main><footer className="portal-small-footer">© 2025 {branding.siteName} <span>•</span> {branding.portalName}</footer></div><MemberMobileDock/></div></MemberSessionContext.Provider>
}
