"use client";

let audioContext: AudioContext | null = null;

export function playNotificationSound() {
  try {
    if (!audioContext) audioContext = new AudioContext();
    const ctx = audioContext;
    const now = ctx.currentTime;

    // Pleasant two-tone chime
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();

    osc1.type = "sine";
    osc1.frequency.setValueAtTime(880, now);        // A5
    osc1.frequency.setValueAtTime(1174.66, now + 0.12); // D6

    osc2.type = "sine";
    osc2.frequency.setValueAtTime(659.25, now);       // E5
    osc2.frequency.setValueAtTime(880, now + 0.12);    // A5

    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(ctx.destination);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 0.5);
    osc2.stop(now + 0.5);
  } catch {
    // AudioContext not available in this environment
  }
}
