import { createHmac, timingSafeEqual } from "node:crypto";

export const MEMBER_SESSION_COOKIE = "ffc_member_session";
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 7; // 7 days

function secret() {
  return process.env.AUTH_SECRET || "fantastic-fc-dev-secret-change-me";
}

function sign(payload: string) {
  return createHmac("sha256", secret()).update(payload).digest("hex");
}

export function createMemberSessionToken(memberId: string, memberCode: string): string {
  const expires = Date.now() + SESSION_TTL_MS;
  const payload = `${memberId}|${memberCode}|${expires}`;
  const signature = sign(payload);
  return Buffer.from(`${payload}|${signature}`).toString("base64url");
}

export function verifyMemberSessionToken(token: string | undefined | null): { memberId: string; memberCode: string } | null {
  if (!token) return null;
  try {
    const decoded = Buffer.from(token, "base64url").toString("utf8");
    const parts = decoded.split("|");
    if (parts.length !== 4) return null;
    const [memberId, memberCode, expiresRaw, signature] = parts;
    const payload = `${memberId}|${memberCode}|${expiresRaw}`;
    const expected = sign(payload);
    const expectedBuffer = Buffer.from(expected);
    const signatureBuffer = Buffer.from(signature);
    if (expectedBuffer.length !== signatureBuffer.length || !timingSafeEqual(expectedBuffer, signatureBuffer)) return null;
    const expires = Number(expiresRaw);
    if (!Number.isFinite(expires) || Date.now() > expires) return null;
    return { memberId, memberCode };
  } catch {
    return null;
  }
}
