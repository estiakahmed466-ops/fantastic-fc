import { images } from "./club-data";

export type ClubBanner = {
  id: string;
  title: string;
  subtitle: string;
  eyebrow: string;
  imageUrl: string;
  imagePosition?: string;
  mobileImageUrl?: string | null;
  mobileImagePosition?: string;
  buttonText: string;
  buttonLink: string;
  isActive: boolean;
  displayOrder: number;
  createdAt?: string;
  updatedAt?: string;
};

export const fallbackBanner: ClubBanner = {
  id: "fallback",
  title: "BUILT BY PASSION.\nUNITED BY FOOTBALL.",
  subtitle: "One badge. One family. One fearless pursuit of greatness—from the heart of Kulanandapur.",
  eyebrow: "KULANANDAPUR'S FOOTBALL LEGACY",
  imageUrl: images.hero,
  imagePosition: "center 40%",
  mobileImagePosition: "65% center",
  buttonText: "Explore match centre",
  buttonLink: "/matches",
  isActive: true,
  displayOrder: 1,
};
